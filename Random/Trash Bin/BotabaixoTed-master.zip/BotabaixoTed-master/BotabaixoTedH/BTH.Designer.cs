﻿namespace BotabaixoTedH
{
    partial class BTH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox_ip = new System.Windows.Forms.TextBox();
            this.label_ip = new System.Windows.Forms.Label();
            this.button_executarcmd = new System.Windows.Forms.Button();
            this.textBox_string = new System.Windows.Forms.TextBox();
            this.label_cmd = new System.Windows.Forms.Label();
            this.button_enviarmsg = new System.Windows.Forms.Button();
            this.button_call = new System.Windows.Forms.Button();
            this.label_localIp = new System.Windows.Forms.Label();
            this.textBox_localIp = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox_ip
            // 
            this.textBox_ip.Location = new System.Drawing.Point(66, 38);
            this.textBox_ip.Name = "textBox_ip";
            this.textBox_ip.Size = new System.Drawing.Size(473, 20);
            this.textBox_ip.TabIndex = 0;
            // 
            // label_ip
            // 
            this.label_ip.AutoSize = true;
            this.label_ip.Location = new System.Drawing.Point(40, 41);
            this.label_ip.Name = "label_ip";
            this.label_ip.Size = new System.Drawing.Size(20, 13);
            this.label_ip.TabIndex = 4;
            this.label_ip.Text = "IP:";
            // 
            // button_executarcmd
            // 
            this.button_executarcmd.Location = new System.Drawing.Point(450, 142);
            this.button_executarcmd.Name = "button_executarcmd";
            this.button_executarcmd.Size = new System.Drawing.Size(89, 22);
            this.button_executarcmd.TabIndex = 2;
            this.button_executarcmd.Text = "Execute Cmd";
            this.button_executarcmd.UseVisualStyleBackColor = true;
            this.button_executarcmd.Click += new System.EventHandler(this.button_executarcmd_Click);
            // 
            // textBox_string
            // 
            this.textBox_string.Location = new System.Drawing.Point(66, 116);
            this.textBox_string.Name = "textBox_string";
            this.textBox_string.Size = new System.Drawing.Size(473, 20);
            this.textBox_string.TabIndex = 1;
            // 
            // label_cmd
            // 
            this.label_cmd.AutoSize = true;
            this.label_cmd.Location = new System.Drawing.Point(23, 119);
            this.label_cmd.Name = "label_cmd";
            this.label_cmd.Size = new System.Drawing.Size(37, 13);
            this.label_cmd.TabIndex = 5;
            this.label_cmd.Text = "String:";
            // 
            // button_enviarmsg
            // 
            this.button_enviarmsg.Location = new System.Drawing.Point(355, 142);
            this.button_enviarmsg.Name = "button_enviarmsg";
            this.button_enviarmsg.Size = new System.Drawing.Size(89, 22);
            this.button_enviarmsg.TabIndex = 3;
            this.button_enviarmsg.Text = "Send Msg";
            this.button_enviarmsg.UseVisualStyleBackColor = true;
            this.button_enviarmsg.Click += new System.EventHandler(this.button_enviarmsg_Click);
            // 
            // button_call
            // 
            this.button_call.Enabled = false;
            this.button_call.Location = new System.Drawing.Point(450, 64);
            this.button_call.Name = "button_call";
            this.button_call.Size = new System.Drawing.Size(89, 22);
            this.button_call.TabIndex = 6;
            this.button_call.Text = "Call IPs";
            this.button_call.UseVisualStyleBackColor = true;
            this.button_call.Click += new System.EventHandler(this.button_call_Click);
            // 
            // label_localIp
            // 
            this.label_localIp.AutoSize = true;
            this.label_localIp.Location = new System.Drawing.Point(11, 15);
            this.label_localIp.Name = "label_localIp";
            this.label_localIp.Size = new System.Drawing.Size(49, 13);
            this.label_localIp.TabIndex = 8;
            this.label_localIp.Text = "Local IP:";
            // 
            // textBox_localIp
            // 
            this.textBox_localIp.Enabled = false;
            this.textBox_localIp.Location = new System.Drawing.Point(66, 12);
            this.textBox_localIp.Name = "textBox_localIp";
            this.textBox_localIp.Size = new System.Drawing.Size(473, 20);
            this.textBox_localIp.TabIndex = 7;
            // 
            // BTH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(551, 174);
            this.Controls.Add(this.label_localIp);
            this.Controls.Add(this.textBox_localIp);
            this.Controls.Add(this.button_call);
            this.Controls.Add(this.button_enviarmsg);
            this.Controls.Add(this.button_executarcmd);
            this.Controls.Add(this.textBox_string);
            this.Controls.Add(this.label_cmd);
            this.Controls.Add(this.label_ip);
            this.Controls.Add(this.textBox_ip);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "BTH";
            this.Text = "BotabaixoTed";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox_ip;
        private System.Windows.Forms.Label label_ip;
        private System.Windows.Forms.Button button_executarcmd;
        private System.Windows.Forms.TextBox textBox_string;
        private System.Windows.Forms.Label label_cmd;
        private System.Windows.Forms.Button button_enviarmsg;
        private System.Windows.Forms.Button button_call;
        private System.Windows.Forms.Label label_localIp;
        private System.Windows.Forms.TextBox textBox_localIp;
    }
}

