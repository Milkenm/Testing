﻿#region Usings
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ScriptsLib.nNetwork.Packets;
#endregion Usings

// # = #
// PingHost(): https://stackoverflow.com/a/11804416
// # = #

namespace BotabaixoTedH
{
    public partial class BTH : Form
    {
        public BTH()
        {
            InitializeComponent();
        }

        private void button_executarcmd_Click(object sender, EventArgs e)
        {
            SendUdpPacket(textBox_ip.Text, 1800, "cmd|" + textBox_string.Text);
        }

        private void button_enviarmsg_Click(object sender, EventArgs e)
        {
            SendUdpPacket(textBox_ip.Text, 1800, "msg|" + textBox_string.Text);
        }

        private void button_call_Click(object sender, EventArgs e)
        {
            new Task(new Action(() =>
            {
                List<string> ips = new List<string>();

                for (int a = 0; a <= 255; a++)
                {
                    for (int b = 0; a <= 255; b++)
                    {
                        string ip = $"192.168.{a}.{b}";
                        if (PingHost(ip) == true)
                        {
                            ips.Add(ip);
                        }
                    }
                }

                foreach (string ip in ips)
                {
                    MessageBox.Show(ip);
                }
            })).Start();
        }
        
        public static bool PingHost(string nameOrAddress)
        {
            bool pingable = false;
            Ping pinger = null;

            try
            {
                pinger = new Ping();
                PingReply reply = pinger.Send(nameOrAddress);
                pingable = reply.Status == IPStatus.Success;
            }
            catch { }
            finally
            {
                if (pinger != null)
                {
                    pinger.Dispose();
                }
            }

            return pingable;
        }
    }
}
