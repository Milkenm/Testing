﻿#region Usings
using System;
using System.Threading.Tasks;
using System.Windows.Forms;

using NetworkChat.Properties;

using static ScriptsLib.nNetwork.Packets;
#endregion Usings



namespace NetworkChat
{
	public partial class Main : Form
	{
		public Main()
		{
			InitializeComponent();
		}

		private void Main_Load(object sender, EventArgs e)
		{
			new Task(new Action(() =>
			{
				while (true)
				{
					listBox_chat.Items.Add(WaitUdpPacket(new Settings().Port));
				}
			})).Start();
		}

		private void menu_settings_Click(object sender, EventArgs e)
		{
			new Options().Show();
		}

		private void textBox_message_KeyDown(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Enter && textBox_message.Text.Length > 0)
			{
				string _Message = $"{new Settings().Username}: {textBox_message.Text}";

				listBox_chat.Items.Add(_Message);
				SendUdpPacket(textBox_remoteIp.Text, (int)numeric_remotePort.Value, _Message);

				textBox_message.Clear();
			}
		}
	}
}
