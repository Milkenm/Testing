﻿#region Usings
using System;
using System.Windows.Forms;

using NetworkChat.Properties;
#endregion Usings



namespace NetworkChat
{
	public partial class Options : Form
	{
		static string _Username;
		static int _Port;

		Settings _Settings = new Settings();

		public Options()
		{
			InitializeComponent();
		}

		private void Settings_Load(object sender, EventArgs e)
		{
			textBox_username.Text = _Username = _Settings.Username;
			numeric_port.Value = _Port = _Settings.Port;
		}

		private void button_confirm_Click(object sender, EventArgs e)
		{
			if (textBox_username.Text != _Username)
			{
				_Settings.Username = textBox_username.Text;
			}
			if (numeric_port.Value != _Port)
			{
				_Settings.Port = (int)numeric_port.Value;
			}

			_Settings.Save();
			this.Close();
		}

		private void textBox_username_TextChanged(object sender, EventArgs e)
		{
			button_confirm.Enabled = textBox_username.Text.Length >= 3;
		}

		private void button_cancel_Click(object sender, EventArgs e)
		{
			this.Close();
		}
	}
}
