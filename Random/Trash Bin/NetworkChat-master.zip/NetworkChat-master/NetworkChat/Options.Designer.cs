﻿namespace NetworkChat
{
	partial class Options
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Options));
			this.textBox_username = new System.Windows.Forms.TextBox();
			this.label_username = new System.Windows.Forms.Label();
			this.label_port = new System.Windows.Forms.Label();
			this.numeric_port = new System.Windows.Forms.NumericUpDown();
			this.button_confirm = new System.Windows.Forms.Button();
			this.button_cancel = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.numeric_port)).BeginInit();
			this.SuspendLayout();
			// 
			// textBox_username
			// 
			this.textBox_username.Location = new System.Drawing.Point(72, 12);
			this.textBox_username.Name = "textBox_username";
			this.textBox_username.Size = new System.Drawing.Size(258, 20);
			this.textBox_username.TabIndex = 0;
			this.textBox_username.TextChanged += new System.EventHandler(this.textBox_username_TextChanged);
			// 
			// label_username
			// 
			this.label_username.AutoSize = true;
			this.label_username.Location = new System.Drawing.Point(8, 15);
			this.label_username.Name = "label_username";
			this.label_username.Size = new System.Drawing.Size(58, 13);
			this.label_username.TabIndex = 1;
			this.label_username.Text = "Username:";
			// 
			// label_port
			// 
			this.label_port.AutoSize = true;
			this.label_port.Location = new System.Drawing.Point(37, 41);
			this.label_port.Name = "label_port";
			this.label_port.Size = new System.Drawing.Size(29, 13);
			this.label_port.TabIndex = 3;
			this.label_port.Text = "Port:";
			// 
			// numeric_port
			// 
			this.numeric_port.Location = new System.Drawing.Point(72, 38);
			this.numeric_port.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
			this.numeric_port.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
			this.numeric_port.Name = "numeric_port";
			this.numeric_port.Size = new System.Drawing.Size(93, 20);
			this.numeric_port.TabIndex = 4;
			this.numeric_port.Value = new decimal(new int[] {
            4369,
            0,
            0,
            0});
			// 
			// button_confirm
			// 
			this.button_confirm.Enabled = false;
			this.button_confirm.Location = new System.Drawing.Point(168, 91);
			this.button_confirm.Name = "button_confirm";
			this.button_confirm.Size = new System.Drawing.Size(78, 23);
			this.button_confirm.TabIndex = 5;
			this.button_confirm.Text = "OK";
			this.button_confirm.UseVisualStyleBackColor = true;
			this.button_confirm.Click += new System.EventHandler(this.button_confirm_Click);
			// 
			// button_cancel
			// 
			this.button_cancel.Location = new System.Drawing.Point(252, 91);
			this.button_cancel.Name = "button_cancel";
			this.button_cancel.Size = new System.Drawing.Size(78, 23);
			this.button_cancel.TabIndex = 6;
			this.button_cancel.Text = "Cancel";
			this.button_cancel.UseVisualStyleBackColor = true;
			this.button_cancel.Click += new System.EventHandler(this.button_cancel_Click);
			// 
			// Options
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(342, 126);
			this.Controls.Add(this.button_cancel);
			this.Controls.Add(this.button_confirm);
			this.Controls.Add(this.numeric_port);
			this.Controls.Add(this.label_port);
			this.Controls.Add(this.label_username);
			this.Controls.Add(this.textBox_username);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Options";
			this.Text = "Options";
			this.Load += new System.EventHandler(this.Settings_Load);
			((System.ComponentModel.ISupportInitialize)(this.numeric_port)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox textBox_username;
		private System.Windows.Forms.Label label_username;
		private System.Windows.Forms.Label label_port;
		private System.Windows.Forms.NumericUpDown numeric_port;
		private System.Windows.Forms.Button button_confirm;
		private System.Windows.Forms.Button button_cancel;
	}
}