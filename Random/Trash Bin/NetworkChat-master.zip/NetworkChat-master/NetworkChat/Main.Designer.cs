﻿namespace NetworkChat
{
	partial class Main
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
			this.menu = new System.Windows.Forms.MenuStrip();
			this.menu_settings = new System.Windows.Forms.ToolStripMenuItem();
			this.panel = new System.Windows.Forms.Panel();
			this.numeric_remotePort = new System.Windows.Forms.NumericUpDown();
			this.textBox_remoteIp = new System.Windows.Forms.TextBox();
			this.textBox_message = new System.Windows.Forms.TextBox();
			this.listBox_chat = new System.Windows.Forms.ListBox();
			this.menu.SuspendLayout();
			this.panel.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.numeric_remotePort)).BeginInit();
			this.SuspendLayout();
			// 
			// menu
			// 
			this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_settings});
			this.menu.Location = new System.Drawing.Point(0, 0);
			this.menu.Name = "menu";
			this.menu.Size = new System.Drawing.Size(536, 24);
			this.menu.TabIndex = 4;
			this.menu.Text = "menuStrip1";
			// 
			// menu_settings
			// 
			this.menu_settings.Name = "menu_settings";
			this.menu_settings.Size = new System.Drawing.Size(61, 20);
			this.menu_settings.Text = "Settings";
			this.menu_settings.Click += new System.EventHandler(this.menu_settings_Click);
			// 
			// panel
			// 
			this.panel.Controls.Add(this.numeric_remotePort);
			this.panel.Controls.Add(this.textBox_remoteIp);
			this.panel.Controls.Add(this.textBox_message);
			this.panel.Controls.Add(this.listBox_chat);
			this.panel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.panel.Location = new System.Drawing.Point(0, 24);
			this.panel.Name = "panel";
			this.panel.Size = new System.Drawing.Size(536, 272);
			this.panel.TabIndex = 5;
			// 
			// numeric_remotePort
			// 
			this.numeric_remotePort.Location = new System.Drawing.Point(141, 249);
			this.numeric_remotePort.Maximum = new decimal(new int[] {
            9999,
            0,
            0,
            0});
			this.numeric_remotePort.Minimum = new decimal(new int[] {
            100,
            0,
            0,
            0});
			this.numeric_remotePort.Name = "numeric_remotePort";
			this.numeric_remotePort.Size = new System.Drawing.Size(74, 20);
			this.numeric_remotePort.TabIndex = 8;
			this.numeric_remotePort.Value = new decimal(new int[] {
            4369,
            0,
            0,
            0});
			// 
			// textBox_remoteIp
			// 
			this.textBox_remoteIp.Location = new System.Drawing.Point(3, 249);
			this.textBox_remoteIp.Name = "textBox_remoteIp";
			this.textBox_remoteIp.Size = new System.Drawing.Size(132, 20);
			this.textBox_remoteIp.TabIndex = 7;
			// 
			// textBox_message
			// 
			this.textBox_message.Location = new System.Drawing.Point(3, 203);
			this.textBox_message.Name = "textBox_message";
			this.textBox_message.Size = new System.Drawing.Size(530, 20);
			this.textBox_message.TabIndex = 5;
			this.textBox_message.KeyDown += new System.Windows.Forms.KeyEventHandler(this.textBox_message_KeyDown);
			// 
			// listBox_chat
			// 
			this.listBox_chat.FormattingEnabled = true;
			this.listBox_chat.Location = new System.Drawing.Point(3, 3);
			this.listBox_chat.Name = "listBox_chat";
			this.listBox_chat.Size = new System.Drawing.Size(530, 199);
			this.listBox_chat.TabIndex = 4;
			// 
			// Main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(536, 296);
			this.Controls.Add(this.panel);
			this.Controls.Add(this.menu);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MainMenuStrip = this.menu;
			this.Name = "Main";
			this.Text = "Network Chat";
			this.Load += new System.EventHandler(this.Main_Load);
			this.menu.ResumeLayout(false);
			this.menu.PerformLayout();
			this.panel.ResumeLayout(false);
			this.panel.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.numeric_remotePort)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion
		private System.Windows.Forms.MenuStrip menu;
		private System.Windows.Forms.ToolStripMenuItem menu_settings;
		private System.Windows.Forms.Panel panel;
		private System.Windows.Forms.TextBox textBox_message;
		private System.Windows.Forms.ListBox listBox_chat;
		private System.Windows.Forms.TextBox textBox_remoteIp;
		private System.Windows.Forms.NumericUpDown numeric_remotePort;
	}
}

