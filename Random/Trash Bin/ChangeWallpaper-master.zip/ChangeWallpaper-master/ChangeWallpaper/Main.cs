﻿#region Usings
using System;
using System.Drawing;
using System.Reflection;
using System.Windows.Forms;
using static ScriptsLib.Tools;
#endregion Usings

// # = #
// ScriptsLib: https://www.github.com/Milkenm/ScriptsLib
// Background Image: https://www.google.pt/search?q=gradient+wallpaper&client=opera-gx&hs=cFn&sxsrf=ACYBGNQT5KYCd37YVW6KZ3WlJ0LCthdfZA:1569090252056&tbm=isch&source=iu&ictx=1&fir=VNUtPtYQVLr6QM%253A%252Cr5U1PraCYrxPlM%252C_&vet=1&usg=AI4_-kTSikNFxaBNR0XRBvVdK9X6jwVFpQ&sa=X&ved=2ahUKEwi3neDYxOLkAhWEyoUKHbCiBLEQ9QEwAXoECAcQBg#imgrc=NUGxb0KA7xIovM:&vet=1
// # = #

namespace ChangeWallpaper
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void button_exit_Click(object sender, EventArgs e)
        {
            Environment.Exit(0);
        }

        private void button_minimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void Main_Load(object sender, EventArgs e)
        {
            label_version.Text = "v" + Assembly.GetEntryAssembly().GetName().Version;

            comboBox_type.SelectedIndex = 0;
        }

        private void button_search_Click(object sender, EventArgs e)
        {
            fileDialog.ShowDialog();
        }

        private void fileDialog_FileOk(object sender, System.ComponentModel.CancelEventArgs e)
        {
            if (!string.IsNullOrEmpty(fileDialog.FileName))
            {
                pictureBox_wallpaper.Image = Image.FromFile(fileDialog.FileName);
                textBox_fileName.Text = fileDialog.FileName;
            }
        }

        private void button_custom_Click(object sender, EventArgs e)
        {
            if (comboBox_type.Text == "Stretched")
            {
                SetDesktopWallpaper(pictureBox_wallpaper.Image, WallpaperStyle.Stretched);
            }
            else if (comboBox_type.Text == "Centered")
            {
                SetDesktopWallpaper(pictureBox_wallpaper.Image, WallpaperStyle.Centered);
            }
            else if (comboBox_type.Text == "Tiled")
            {
                SetDesktopWallpaper(pictureBox_wallpaper.Image, WallpaperStyle.Tiled);
            }            
        }
    }
}
