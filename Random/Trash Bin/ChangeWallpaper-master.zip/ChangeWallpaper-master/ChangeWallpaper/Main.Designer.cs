﻿namespace ChangeWallpaper
{
    partial class Main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
            this.pictureBox_wallpaper = new System.Windows.Forms.PictureBox();
            this.button_search = new System.Windows.Forms.Button();
            this.textBox_fileName = new System.Windows.Forms.TextBox();
            this.comboBox_type = new System.Windows.Forms.ComboBox();
            this.label_wallpaper = new System.Windows.Forms.Label();
            this.label_type = new System.Windows.Forms.Label();
            this.button_custom = new System.Windows.Forms.Button();
            this.button_exit = new System.Windows.Forms.Button();
            this.button_minimize = new System.Windows.Forms.Button();
            this.fileDialog = new System.Windows.Forms.OpenFileDialog();
            this.label_version = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_wallpaper)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_wallpaper
            // 
            this.pictureBox_wallpaper.BackColor = System.Drawing.Color.Snow;
            this.pictureBox_wallpaper.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox_wallpaper.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pictureBox_wallpaper.Location = new System.Drawing.Point(12, 12);
            this.pictureBox_wallpaper.Name = "pictureBox_wallpaper";
            this.pictureBox_wallpaper.Size = new System.Drawing.Size(128, 128);
            this.pictureBox_wallpaper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_wallpaper.TabIndex = 0;
            this.pictureBox_wallpaper.TabStop = false;
            // 
            // button_search
            // 
            this.button_search.BackColor = System.Drawing.SystemColors.Control;
            this.button_search.Location = new System.Drawing.Point(381, 39);
            this.button_search.Name = "button_search";
            this.button_search.Size = new System.Drawing.Size(75, 22);
            this.button_search.TabIndex = 1;
            this.button_search.Text = "Search...";
            this.button_search.UseVisualStyleBackColor = false;
            this.button_search.Click += new System.EventHandler(this.button_search_Click);
            // 
            // textBox_fileName
            // 
            this.textBox_fileName.BackColor = System.Drawing.Color.Snow;
            this.textBox_fileName.Location = new System.Drawing.Point(146, 40);
            this.textBox_fileName.Name = "textBox_fileName";
            this.textBox_fileName.ReadOnly = true;
            this.textBox_fileName.Size = new System.Drawing.Size(229, 20);
            this.textBox_fileName.TabIndex = 2;
            // 
            // comboBox_type
            // 
            this.comboBox_type.BackColor = System.Drawing.Color.Snow;
            this.comboBox_type.FormattingEnabled = true;
            this.comboBox_type.Items.AddRange(new object[] {
            "Stretched",
            "Centered",
            "Tiled"});
            this.comboBox_type.Location = new System.Drawing.Point(146, 93);
            this.comboBox_type.Name = "comboBox_type";
            this.comboBox_type.Size = new System.Drawing.Size(180, 21);
            this.comboBox_type.TabIndex = 3;
            // 
            // label_wallpaper
            // 
            this.label_wallpaper.AutoSize = true;
            this.label_wallpaper.BackColor = System.Drawing.Color.Transparent;
            this.label_wallpaper.ForeColor = System.Drawing.Color.White;
            this.label_wallpaper.Location = new System.Drawing.Point(146, 24);
            this.label_wallpaper.Name = "label_wallpaper";
            this.label_wallpaper.Size = new System.Drawing.Size(58, 13);
            this.label_wallpaper.TabIndex = 4;
            this.label_wallpaper.Text = "Wallpaper:";
            // 
            // label_type
            // 
            this.label_type.AutoSize = true;
            this.label_type.BackColor = System.Drawing.Color.Transparent;
            this.label_type.ForeColor = System.Drawing.Color.White;
            this.label_type.Location = new System.Drawing.Point(146, 77);
            this.label_type.Name = "label_type";
            this.label_type.Size = new System.Drawing.Size(33, 13);
            this.label_type.TabIndex = 5;
            this.label_type.Text = "Style:";
            // 
            // button_custom
            // 
            this.button_custom.BackColor = System.Drawing.SystemColors.Control;
            this.button_custom.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_custom.Location = new System.Drawing.Point(367, 127);
            this.button_custom.Name = "button_custom";
            this.button_custom.Size = new System.Drawing.Size(114, 23);
            this.button_custom.TabIndex = 6;
            this.button_custom.Text = "Set Wallpaper";
            this.button_custom.UseVisualStyleBackColor = false;
            this.button_custom.Click += new System.EventHandler(this.button_custom_Click);
            // 
            // button_exit
            // 
            this.button_exit.BackColor = System.Drawing.Color.IndianRed;
            this.button_exit.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_exit.Location = new System.Drawing.Point(471, -1);
            this.button_exit.Name = "button_exit";
            this.button_exit.Size = new System.Drawing.Size(23, 23);
            this.button_exit.TabIndex = 8;
            this.button_exit.Text = "X";
            this.button_exit.UseVisualStyleBackColor = false;
            this.button_exit.Click += new System.EventHandler(this.button_exit_Click);
            // 
            // button_minimize
            // 
            this.button_minimize.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button_minimize.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button_minimize.Location = new System.Drawing.Point(449, -1);
            this.button_minimize.Name = "button_minimize";
            this.button_minimize.Size = new System.Drawing.Size(23, 23);
            this.button_minimize.TabIndex = 9;
            this.button_minimize.Text = "_";
            this.button_minimize.UseVisualStyleBackColor = false;
            this.button_minimize.Click += new System.EventHandler(this.button_minimize_Click);
            // 
            // fileDialog
            // 
            this.fileDialog.Filter = "Image Files|*.png;*.jpeg;*.jpg";
            this.fileDialog.FileOk += new System.ComponentModel.CancelEventHandler(this.fileDialog_FileOk);
            // 
            // label_version
            // 
            this.label_version.AutoSize = true;
            this.label_version.BackColor = System.Drawing.Color.Transparent;
            this.label_version.ForeColor = System.Drawing.Color.White;
            this.label_version.Location = new System.Drawing.Point(11, 142);
            this.label_version.Name = "label_version";
            this.label_version.Size = new System.Drawing.Size(53, 13);
            this.label_version.TabIndex = 10;
            this.label_version.Text = "<version>";
            // 
            // Main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(493, 156);
            this.Controls.Add(this.label_version);
            this.Controls.Add(this.button_minimize);
            this.Controls.Add(this.button_exit);
            this.Controls.Add(this.button_custom);
            this.Controls.Add(this.label_type);
            this.Controls.Add(this.label_wallpaper);
            this.Controls.Add(this.comboBox_type);
            this.Controls.Add(this.textBox_fileName);
            this.Controls.Add(this.button_search);
            this.Controls.Add(this.pictureBox_wallpaper);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Main";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Change Wallpaper";
            this.Load += new System.EventHandler(this.Main_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_wallpaper)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_wallpaper;
        private System.Windows.Forms.Button button_search;
        private System.Windows.Forms.TextBox textBox_fileName;
        private System.Windows.Forms.ComboBox comboBox_type;
        private System.Windows.Forms.Label label_wallpaper;
        private System.Windows.Forms.Label label_type;
        private System.Windows.Forms.Button button_custom;
        private System.Windows.Forms.Button button_exit;
        private System.Windows.Forms.Button button_minimize;
        private System.Windows.Forms.OpenFileDialog fileDialog;
        private System.Windows.Forms.Label label_version;
    }
}

