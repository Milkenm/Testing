﻿#region Usings
using static HtmlEditor.Editor.Functions;
using static HtmlEditor.Editor.Static;
using static HtmlEditor.Launcher.Static;
using static HtmlEditor.Optimizer.Static;
#endregion Usings



namespace HtmlEditor.Launcher
{
	internal static class Functions
	{
		internal static void LoadEditor(string[] args)
		{
			HeForm = new Editor.HtmlEditor();
			HoForm = new Optimizer.HtmlOptimizer();

			if (args.Length > 0)
			{
				HtmlPath = args[0];
				LoadHtmlFile(args[0]);
			}

			HeForm.Show();
			LauncherForm.Hide();
		}
	}
}
