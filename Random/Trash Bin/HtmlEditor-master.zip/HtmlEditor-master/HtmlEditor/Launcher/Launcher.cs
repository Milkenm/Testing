﻿#region Usings
using System;
using System.Windows.Forms;

using static HtmlEditor.Launcher.Functions;
#endregion Usings



namespace HtmlEditor.Launcher
{
	public partial class Launcher : Form
	{
		string[] args;

		public Launcher(string[] args)
		{
			InitializeComponent();

			this.args = args;
		}

		private void Launcher_Load(object sender, EventArgs e) => LoadEditor(args);
	}
}
