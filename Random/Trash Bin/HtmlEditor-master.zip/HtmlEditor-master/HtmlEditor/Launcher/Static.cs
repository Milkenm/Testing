﻿namespace HtmlEditor.Launcher
{
	internal static class Static
	{
		internal static Launcher LauncherForm;
	}
}
