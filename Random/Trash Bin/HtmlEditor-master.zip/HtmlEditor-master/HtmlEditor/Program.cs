﻿#region Usings
using System;
using System.Windows.Forms;

using static HtmlEditor.Launcher.Static;
#endregion Usings



namespace HtmlEditor.Editor
{
	static class Program
	{
		[STAThread]
		static void Main(string[] args)
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			LauncherForm = new Launcher.Launcher(args);
			Application.Run(LauncherForm);
		}
	}
}