﻿#region Usings
using System;
using System.IO;
using System.Windows.Forms;

using static HtmlEditor.Editor.Static;
#endregion Usings



namespace HtmlEditor.Editor
{
	internal static partial class Functions
	{
		internal static void LoadHtmlFile(string _FilePath)
		{
			try
			{
				HeForm.textBox_html.Text = File.ReadAllText(_FilePath);
			}
			catch (Exception _Exception) { MessageBox.Show(_Exception.Message); }
		}
	}
}
