﻿namespace HtmlEditor.Editor
{
	partial class HtmlEditor
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HtmlEditor));
			this.webBrowser = new System.Windows.Forms.WebBrowser();
			this.textBox_html = new FastColoredTextBoxNS.FastColoredTextBox();
			this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
			this.menu = new System.Windows.Forms.MenuStrip();
			this.menu_optimizeHtml = new System.Windows.Forms.ToolStripMenuItem();
			((System.ComponentModel.ISupportInitialize)(this.textBox_html)).BeginInit();
			this.tableLayoutPanel.SuspendLayout();
			this.menu.SuspendLayout();
			this.SuspendLayout();
			// 
			// webBrowser
			// 
			this.webBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
			this.webBrowser.Location = new System.Drawing.Point(515, 4);
			this.webBrowser.MinimumSize = new System.Drawing.Size(20, 20);
			this.webBrowser.Name = "webBrowser";
			this.webBrowser.Size = new System.Drawing.Size(405, 516);
			this.webBrowser.TabIndex = 1;
			// 
			// textBox_html
			// 
			this.textBox_html.AutoCompleteBracketsList = new char[] {
        '(',
        ')',
        '{',
        '}',
        '[',
        ']',
        '\"',
        '\"',
        '\'',
        '\''};
			this.textBox_html.AutoScrollMinSize = new System.Drawing.Size(27, 14);
			this.textBox_html.BackBrush = null;
			this.textBox_html.BackColor = System.Drawing.Color.Silver;
			this.textBox_html.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox_html.CaretColor = System.Drawing.Color.Transparent;
			this.textBox_html.ChangedLineColor = System.Drawing.Color.PeachPuff;
			this.textBox_html.CharHeight = 14;
			this.textBox_html.CharWidth = 8;
			this.textBox_html.CommentPrefix = "<--!";
			this.textBox_html.CurrentLineColor = System.Drawing.Color.PeachPuff;
			this.textBox_html.Cursor = System.Windows.Forms.Cursors.IBeam;
			this.textBox_html.DescriptionFile = "C:\\Users\\migcampos\\Desktop\\GitHub\\HtmlEditor\\HtmlEditor\\Resources\\HtmlHightlight." +
    "xml";
			this.textBox_html.DisabledColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))), ((int)(((byte)(180)))));
			this.textBox_html.Dock = System.Windows.Forms.DockStyle.Fill;
			this.textBox_html.IndentBackColor = System.Drawing.Color.Gainsboro;
			this.textBox_html.IsReplaceMode = false;
			this.textBox_html.Location = new System.Drawing.Point(4, 4);
			this.textBox_html.Name = "textBox_html";
			this.textBox_html.Paddings = new System.Windows.Forms.Padding(0);
			this.textBox_html.SelectionColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(255)))));
			this.textBox_html.ServiceColors = ((FastColoredTextBoxNS.ServiceColors)(resources.GetObject("textBox_html.ServiceColors")));
			this.textBox_html.ServiceLinesColor = System.Drawing.Color.Black;
			this.textBox_html.Size = new System.Drawing.Size(504, 516);
			this.textBox_html.TabIndex = 0;
			this.textBox_html.Zoom = 100;
			// 
			// tableLayoutPanel
			// 
			this.tableLayoutPanel.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
			this.tableLayoutPanel.ColumnCount = 2;
			this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 55.47129F));
			this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 44.52871F));
			this.tableLayoutPanel.Controls.Add(this.webBrowser, 1, 0);
			this.tableLayoutPanel.Controls.Add(this.textBox_html, 0, 0);
			this.tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tableLayoutPanel.Location = new System.Drawing.Point(0, 24);
			this.tableLayoutPanel.Name = "tableLayoutPanel";
			this.tableLayoutPanel.RowCount = 1;
			this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50F));
			this.tableLayoutPanel.Size = new System.Drawing.Size(924, 524);
			this.tableLayoutPanel.TabIndex = 3;
			// 
			// menu
			// 
			this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_optimizeHtml});
			this.menu.Location = new System.Drawing.Point(0, 0);
			this.menu.Name = "menu";
			this.menu.Size = new System.Drawing.Size(924, 24);
			this.menu.TabIndex = 4;
			this.menu.Text = "menuStrip1";
			// 
			// menu_optimizeHtml
			// 
			this.menu_optimizeHtml.Name = "menu_optimizeHtml";
			this.menu_optimizeHtml.Size = new System.Drawing.Size(97, 20);
			this.menu_optimizeHtml.Text = "Optimize Html";
			this.menu_optimizeHtml.Click += new System.EventHandler(this.menu_optimizeHtml_Click);
			// 
			// HtmlEditor
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(924, 548);
			this.Controls.Add(this.tableLayoutPanel);
			this.Controls.Add(this.menu);
			this.MainMenuStrip = this.menu;
			this.Name = "HtmlEditor";
			this.Text = "HTML Editor";
			((System.ComponentModel.ISupportInitialize)(this.textBox_html)).EndInit();
			this.tableLayoutPanel.ResumeLayout(false);
			this.menu.ResumeLayout(false);
			this.menu.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.WebBrowser webBrowser;
        internal FastColoredTextBoxNS.FastColoredTextBox textBox_html;
        internal System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
		private System.Windows.Forms.MenuStrip menu;
		private System.Windows.Forms.ToolStripMenuItem menu_optimizeHtml;
	}
}

