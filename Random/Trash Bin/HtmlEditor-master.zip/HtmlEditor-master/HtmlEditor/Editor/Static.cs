﻿#region Usings
#endregion Usings



namespace HtmlEditor.Editor
{
	internal static partial class Static
	{
		internal static HtmlEditor HeForm;

		internal static string HtmlPath;
	}
}
