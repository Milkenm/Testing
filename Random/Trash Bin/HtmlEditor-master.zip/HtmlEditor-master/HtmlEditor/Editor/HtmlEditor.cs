﻿#region Usings
using System;
using System.IO;
using System.Windows.Forms;

using static HtmlEditor.Editor.Static;
using static HtmlEditor.Optimizer.Static;
#endregion Usings



namespace HtmlEditor.Editor
{
	public partial class HtmlEditor : Form
	{
		public HtmlEditor()
		{
			InitializeComponent();
			textBox_html.TextChanged += this.TextBox_html_TextChanged;
		}

		private void TextBox_html_TextChanged(object sender, FastColoredTextBoxNS.TextChangedEventArgs e)
		{
			File.WriteAllLines(HtmlPath, textBox_html.Lines);

			webBrowser.Url = new Uri("file:///" + HtmlPath);
		}

		private void menu_optimizeHtml_Click(object sender, EventArgs e) => HoForm.Show();
	}
}