﻿#region Usings
using System.IO;
using System.Windows.Forms;

using static HtmlEditor.Optimizer.Static;
#endregion Usings



namespace HtmlEditor.Optimizer
{
	internal static partial class Functions
	{
		internal static void Optimize()
		{
			if (string.IsNullOrEmpty(HoForm.textBox_path.Text) || !File.Exists(HoForm.textBox_path.Text)) MessageBox.Show("File not found.");
			else
			{
				string _Html = string.Empty;

				foreach (string _Line in File.ReadAllLines(HoForm.textBox_path.Text))
				{
					bool _Write = false;
					foreach (char _Char in _Line.ToCharArray())
					{
						if (_Char == '<') _Write = true;
						if (_Write) _Html = $"{_Html}{_Char}";
					}
				}

				File.WriteAllText(HoForm.textBox_path.Text, _Html);
				MessageBox.Show("Your HTML file has been optimized!");
			}
		}
	}
}
