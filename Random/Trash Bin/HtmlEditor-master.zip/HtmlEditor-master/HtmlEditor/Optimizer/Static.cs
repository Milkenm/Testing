﻿namespace HtmlEditor.Optimizer
{
	internal static class Static
	{
		internal static HtmlOptimizer HoForm;
	}
}
