﻿#region Usings
using System;
using System.Windows.Forms;

using static HtmlEditor.Optimizer.Functions;
#endregion Usings



namespace HtmlEditor.Optimizer
{
	public partial class HtmlOptimizer : Form
	{
		public HtmlOptimizer() => InitializeComponent();

		private void button_search_Click(object sender, EventArgs e) => SearchFile();

		private void button_optimize_Click(object sender, EventArgs e) => Optimize();
	}
}