﻿#region Usings
using System.Windows.Forms;

using static HtmlEditor.Optimizer.Static;
#endregion Usings



namespace HtmlEditor.Optimizer
{
	internal static partial class Functions
	{
		internal static void SearchFile()
		{
			OpenFileDialog fileDialog = new OpenFileDialog();
			DialogResult result = fileDialog.ShowDialog();

			if (result == DialogResult.OK) HoForm.textBox_path.Text = fileDialog.FileName;
		}
	}
}
