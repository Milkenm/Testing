﻿namespace HtmlEditor.Optimizer
{
	partial class HtmlOptimizer
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.textBox_path = new System.Windows.Forms.TextBox();
			this.button_optimize = new System.Windows.Forms.Button();
			this.button_search = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// textBox_path
			// 
			this.textBox_path.Location = new System.Drawing.Point(12, 12);
			this.textBox_path.Name = "textBox_path";
			this.textBox_path.ReadOnly = true;
			this.textBox_path.Size = new System.Drawing.Size(468, 20);
			this.textBox_path.TabIndex = 0;
			// 
			// button_optimize
			// 
			this.button_optimize.Location = new System.Drawing.Point(555, 11);
			this.button_optimize.Name = "button_optimize";
			this.button_optimize.Size = new System.Drawing.Size(75, 22);
			this.button_optimize.TabIndex = 1;
			this.button_optimize.Text = "Optimize!";
			this.button_optimize.UseVisualStyleBackColor = true;
			this.button_optimize.Click += new System.EventHandler(this.button_optimize_Click);
			// 
			// button_search
			// 
			this.button_search.Location = new System.Drawing.Point(486, 11);
			this.button_search.Name = "button_search";
			this.button_search.Size = new System.Drawing.Size(40, 22);
			this.button_search.TabIndex = 2;
			this.button_search.Text = "...";
			this.button_search.UseVisualStyleBackColor = true;
			this.button_search.Click += new System.EventHandler(this.button_search_Click);
			// 
			// HtmlOptimizer
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(643, 45);
			this.Controls.Add(this.button_search);
			this.Controls.Add(this.button_optimize);
			this.Controls.Add(this.textBox_path);
			this.Name = "HtmlOptimizer";
			this.Text = "Html Optimizer";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		internal System.Windows.Forms.TextBox textBox_path;
		internal System.Windows.Forms.Button button_optimize;
		internal System.Windows.Forms.Button button_search;
	}
}

