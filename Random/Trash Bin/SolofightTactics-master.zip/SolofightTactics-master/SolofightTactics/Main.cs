﻿#region Usings
using System.Windows.Forms;
#endregion Usings



namespace SolofightTactics
{
	internal partial class Main : Form
	{
		// # ################################################################################################ #
		public Main()
		{
			InitializeComponent();
		}
		// # ################################################################################################ #
	}
}