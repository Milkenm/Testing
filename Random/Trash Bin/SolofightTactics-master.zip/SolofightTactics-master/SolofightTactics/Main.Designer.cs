﻿#region Usings
using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;

using static SolofightTactics.Functions;
#endregion Usings



namespace SolofightTactics
{
	partial class Main
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
			this.flow_baseItems = new System.Windows.Forms.FlowLayoutPanel();
			this.pictureBox_baseItem1 = new System.Windows.Forms.PictureBox();
			this.pictureBox_baseItem2 = new System.Windows.Forms.PictureBox();
			this.label_plus = new System.Windows.Forms.Label();
			this.label_equal = new System.Windows.Forms.Label();
			this.pictureBox_result = new System.Windows.Forms.PictureBox();
			this.flow_comboItems = new System.Windows.Forms.FlowLayoutPanel();
			this.label_clear = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_baseItem1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_baseItem2)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_result)).BeginInit();
			this.SuspendLayout();
			// 
			// flow_baseItems
			// 
			this.flow_baseItems.BackColor = System.Drawing.Color.Transparent;
			this.flow_baseItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.flow_baseItems.Location = new System.Drawing.Point(1, 1);
			this.flow_baseItems.Name = "flow_baseItems";
			this.flow_baseItems.Size = new System.Drawing.Size(632, 72);
			this.flow_baseItems.TabIndex = 0;
			// 
			// pictureBox_baseItem1
			// 
			this.pictureBox_baseItem1.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox_baseItem1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pictureBox_baseItem1.Location = new System.Drawing.Point(175, 79);
			this.pictureBox_baseItem1.Name = "pictureBox_baseItem1";
			this.pictureBox_baseItem1.Size = new System.Drawing.Size(64, 64);
			this.pictureBox_baseItem1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_baseItem1.TabIndex = 1;
			this.pictureBox_baseItem1.TabStop = false;
			this.pictureBox_baseItem1.Click += new System.EventHandler(this.Crafting1Click);
			// 
			// pictureBox_baseItem2
			// 
			this.pictureBox_baseItem2.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox_baseItem2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pictureBox_baseItem2.Location = new System.Drawing.Point(271, 78);
			this.pictureBox_baseItem2.Name = "pictureBox_baseItem2";
			this.pictureBox_baseItem2.Size = new System.Drawing.Size(64, 64);
			this.pictureBox_baseItem2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_baseItem2.TabIndex = 2;
			this.pictureBox_baseItem2.TabStop = false;
			this.pictureBox_baseItem2.Click += new System.EventHandler(this.Crafting2Click);
			// 
			// label_plus
			// 
			this.label_plus.AutoSize = true;
			this.label_plus.BackColor = System.Drawing.Color.Transparent;
			this.label_plus.Font = new System.Drawing.Font("Ravie", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label_plus.ForeColor = System.Drawing.Color.White;
			this.label_plus.Location = new System.Drawing.Point(245, 101);
			this.label_plus.Name = "label_plus";
			this.label_plus.Size = new System.Drawing.Size(21, 21);
			this.label_plus.TabIndex = 3;
			this.label_plus.Text = "+";
			// 
			// label_equal
			// 
			this.label_equal.AutoSize = true;
			this.label_equal.BackColor = System.Drawing.Color.Transparent;
			this.label_equal.Font = new System.Drawing.Font("Ravie", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label_equal.ForeColor = System.Drawing.Color.White;
			this.label_equal.Location = new System.Drawing.Point(341, 100);
			this.label_equal.Name = "label_equal";
			this.label_equal.Size = new System.Drawing.Size(18, 21);
			this.label_equal.TabIndex = 4;
			this.label_equal.Text = "=";
			// 
			// pictureBox_result
			// 
			this.pictureBox_result.BackColor = System.Drawing.Color.Transparent;
			this.pictureBox_result.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.pictureBox_result.Location = new System.Drawing.Point(365, 78);
			this.pictureBox_result.Name = "pictureBox_result";
			this.pictureBox_result.Size = new System.Drawing.Size(64, 64);
			this.pictureBox_result.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_result.TabIndex = 5;
			this.pictureBox_result.TabStop = false;
			// 
			// flow_comboItems
			// 
			this.flow_comboItems.AutoScroll = true;
			this.flow_comboItems.BackColor = System.Drawing.Color.Transparent;
			this.flow_comboItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.flow_comboItems.Location = new System.Drawing.Point(1, 149);
			this.flow_comboItems.Name = "flow_comboItems";
			this.flow_comboItems.Size = new System.Drawing.Size(632, 141);
			this.flow_comboItems.TabIndex = 1;
			// 
			// label_clear
			// 
			this.label_clear.AutoSize = true;
			this.label_clear.BackColor = System.Drawing.Color.Transparent;
			this.label_clear.Font = new System.Drawing.Font("Arial", 6.5F, System.Drawing.FontStyle.Bold);
			this.label_clear.ForeColor = System.Drawing.Color.White;
			this.label_clear.Location = new System.Drawing.Point(430, 79);
			this.label_clear.Name = "label_clear";
			this.label_clear.Size = new System.Drawing.Size(29, 11);
			this.label_clear.TabIndex = 6;
			this.label_clear.Text = "Clear";
			this.label_clear.Click += new System.EventHandler(this.LabelClearCraftingClick);
			// 
			// Main
			// 
			this.BackgroundImage = global::SolofightTactics.Properties.Resources.Baron;
			this.ClientSize = new System.Drawing.Size(634, 291);
			this.Controls.Add(this.label_clear);
			this.Controls.Add(this.flow_comboItems);
			this.Controls.Add(this.pictureBox_result);
			this.Controls.Add(this.label_equal);
			this.Controls.Add(this.label_plus);
			this.Controls.Add(this.pictureBox_baseItem2);
			this.Controls.Add(this.pictureBox_baseItem1);
			this.Controls.Add(this.flow_baseItems);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Main";
			this.StartPosition = System.Windows.Forms.FormStartPosition.Manual;
			this.Text = "Solofight Tactics";
			this.TransparencyKey = System.Drawing.SystemColors.Control;
			this.Load += new System.EventHandler(this.Loader);
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_baseItem1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_baseItem2)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_result)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		internal FlowLayoutPanel flow_baseItems;
		internal PictureBox pictureBox_baseItem1;
		internal PictureBox pictureBox_baseItem2;
		internal Label label_plus;
		internal Label label_equal;
		internal PictureBox pictureBox_result;
		internal FlowLayoutPanel flow_comboItems;
		internal Label label_clear;
	}
}

