﻿#region Usings
using System.Drawing;
using System.Windows.Forms;
#endregion Usings



namespace SolofightTactics
{
	internal partial class Functions
	{
		/// <summary>Generates a nice frame.</summary>
		internal static PictureBox GenerateFrame()
		{
			PictureBox _Frame = new PictureBox();
			_Frame.Size = new Size(64, 64);
			_Frame.BorderStyle = BorderStyle.Fixed3D;
			_Frame.SizeMode = PictureBoxSizeMode.StretchImage;
			return _Frame;
		}
	}
}
