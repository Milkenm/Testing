﻿#region Usings
using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;

using static SolofightTactics.Properties.Variables;
#endregion Usings



namespace SolofightTactics
{
	internal partial class Functions
	{
		/// <summary>Load stuff when the application starts.</summary>
		internal static void Loader(object sender, EventArgs e)
		{
			// Set Window Position
			_Main.Top = 10;
			_Main.Left = 0;

			// Load Base Items to Flow Panel
			foreach (DictionaryEntry _Resource in _BaseItems)
			{
				PictureBox _BaseItemsPictureBox = GenerateFrame();
				_BaseItemsPictureBox.Image = (Image)_Resource.Value;
				_BaseItemsPictureBox.Click += new EventHandler((_Sender, _Event) => BaseItemsClick(_Resource));
				_Main.flow_baseItems.Controls.Add(_BaseItemsPictureBox);
			}

			// Load Combo Items to Flow Panel
			foreach (DictionaryEntry _Resource in _ComboItems)
			{
				PictureBox _ComboItemsPictureBox = Functions.GenerateFrame();
				_ComboItemsPictureBox.Image = (Image)_Resource.Value;
				_ComboItemsPictureBox.Click += new EventHandler((_Sender, _Event) => ComboItemsClick(_Resource));
				_Main.flow_comboItems.Controls.Add(_ComboItemsPictureBox);
			}
		}
	}
}
