﻿#region Usings
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SolofightTactics.Properties.Variables;
using static SolofightTactics.Functions;
#endregion Usings



namespace SolofightTactics
{
	internal partial class Functions
	{
		internal static void LabelClearCraftingClick(object sender, EventArgs e)
		{
			if (_Main.pictureBox_baseItem1.Image != null)
			{
				Crafting1Click(null, null);
			}
			if (_Main.pictureBox_baseItem2 != null)
			{
				Crafting2Click(null, null);
			}
		}
	}
}
