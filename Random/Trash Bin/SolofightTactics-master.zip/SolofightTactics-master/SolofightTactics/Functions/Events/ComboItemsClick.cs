﻿#region Usings
using System;
using System.Collections;
using System.Drawing;

using static SolofightTactics.Properties.Variables;
#endregion Usings



namespace SolofightTactics
{
	internal partial class Functions
	{
		/// <summary>Event for when the user clicks on a combo item.</summary>
		internal static void ComboItemsClick(DictionaryEntry _Resource)
		{
			bool _UpdateCrafting = false;

			if (_Main.pictureBox_result.Image != (Image)_Resource.Value)
			{
				_UpdateCrafting = true;
			}

			if (_UpdateCrafting == true)
			{
				_Main.pictureBox_result.Image = (Image)_Resource.Value;

				int _Item1 = Convert.ToInt32(Math.Round(Convert.ToDecimal(GetResourceId(_Resource) / 10), 0, MidpointRounding.ToEven));
				int _Item2 = (Convert.ToInt32(GetResourceId(_Resource)) - _Item1 * 10);

				foreach (DictionaryEntry _EntryItem in _BaseItems)
				{
					bool _FoundItem1 = false, _FoundItem2 = false;
					if (GetResourceId(_EntryItem) == _Item1)
					{
						_Main.pictureBox_baseItem1.Image = (Image)_EntryItem.Value;
						_Pic1Id = _EntryItem;
						_FoundItem1 = true;
					}
					if (GetResourceId(_EntryItem) == _Item2)
					{
						_Main.pictureBox_baseItem2.Image = (Image)_EntryItem.Value;
						_Pic2Id = _EntryItem;
						_FoundItem2 = true;
					}

					if (_FoundItem1 == true && _FoundItem2 == true)
					{
						break;
					}
				}
			}
		}
	}
}
