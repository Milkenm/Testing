﻿#region Usings
using System;
using System.Collections;
using System.Drawing;

using static SolofightTactics.Properties.Variables;
#endregion Usings



namespace SolofightTactics
{
	internal partial class Functions
	{
		/// <summary>Event for when the user clicks on a base item.</summary>
		internal static void BaseItemsClick(DictionaryEntry _Resource)
		{
			bool _CraftingUpdated = false;
			#region Change the Item
			// # ################################################################################################ #
			if (_Main.pictureBox_baseItem1.Image == null)
			{
				_Main.pictureBox_baseItem1.Image = (Image)_Resource.Value;
				_Pic1Id = _Resource;
				_CraftingUpdated = true;
			}
			else if (_Main.pictureBox_baseItem2.Image != (Image)_Resource.Value)
			{
				_Main.pictureBox_baseItem2.Image = (Image)_Resource.Value;
				_Pic2Id = _Resource;
				_CraftingUpdated = true;
			}
			// # ################################################################################################ #
			#endregion Change the Item

			#region Calculate Craft
			// # ################################################################################################ #
			if (_Pic1Id.Key != null && _Pic2Id.Key != null && _CraftingUpdated == true)
			{
				int _CraftItemId = Convert.ToInt32($"{GetResourceId(_Pic1Id)}{GetResourceId(_Pic2Id)}");
				foreach (DictionaryEntry _EntryItem in _ComboItems)
				{
					int _EntryItemId = Convert.ToInt32(GetResourceId(_EntryItem));
					if (_EntryItemId == _CraftItemId || _EntryItemId == FlipNumber(_CraftItemId))
					{
						_Main.pictureBox_result.Image = (Image)_EntryItem.Value;
						break;
					}
				}
			}
			// # ################################################################################################ #
			#endregion Calculate Craft
		}
	}
}
