﻿#region Usings
using System;
using System.Collections;

using static SolofightTactics.Properties.Variables;
#endregion Usings



namespace SolofightTactics
{
	internal partial class Functions
	{
		internal static void Crafting2Click(object sender, EventArgs e)
		{
			_Main.pictureBox_baseItem2.Image = null;
			_Pic2Id = new DictionaryEntry();
			_Main.pictureBox_result.Image = null;
		}
	}
}
