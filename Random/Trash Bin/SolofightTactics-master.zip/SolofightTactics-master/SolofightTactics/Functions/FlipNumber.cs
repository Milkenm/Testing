﻿#region Usings
using System;
#endregion Usings



namespace SolofightTactics
{
	internal partial class Functions
	{
		/// <summary>Turns 12 into 21.</summary>
		internal static int FlipNumber(int _Number)
		{
			int _Num1 = Convert.ToInt32(Math.Round(Convert.ToDecimal(_Number / 10), 0, MidpointRounding.ToEven));
			int _Num2 = (_Number - _Num1 * 10) * 10;

			return _Num1 + _Num2;
		}
	}
}