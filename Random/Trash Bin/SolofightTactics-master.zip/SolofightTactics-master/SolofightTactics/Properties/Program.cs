﻿#region Usings
using System;
using System.Windows.Forms;
using static SolofightTactics.Properties.Variables;
#endregion Usings



namespace SolofightTactics.Properties
{
	internal class Program
	{
		[STAThread] static void Main()
		{
			Application.Run(_Main);
		}
	}
}
