﻿#region Usings
using System.Collections;
using System.Globalization;
using System.Resources;

using SolofightTacticsUI.Resources.Champs;
using SolofightTacticsUI.Resources.Items;
#endregion Usings



namespace SolofightTacticsUI.Properties
{
	internal class Variables
	{
		// Application Main Window
		internal static MainWindow _Main;

		// Item/Champ Resource Files
		internal static ResourceSet _BaseItems = new ResourceManager(typeof(BaseItems)).GetResourceSet(CultureInfo.CurrentCulture, true, true);
		internal static ResourceSet _ComboItems = new ResourceManager(typeof(ComboItems)).GetResourceSet(CultureInfo.CurrentCulture, true, true);
		internal static ResourceSet _T1Champs = new ResourceManager(typeof(T1Champs)).GetResourceSet(CultureInfo.CurrentCulture, true, true);
		internal static ResourceSet _T2Champs = new ResourceManager(typeof(T2Champs)).GetResourceSet(CultureInfo.CurrentCulture, true, true);
		internal static ResourceSet _T3Champs = new ResourceManager(typeof(T3Champs)).GetResourceSet(CultureInfo.CurrentCulture, true, true);
		internal static ResourceSet _T4Champs = new ResourceManager(typeof(T4Champs)).GetResourceSet(CultureInfo.CurrentCulture, true, true);
		internal static ResourceSet _T5Champs = new ResourceManager(typeof(T5Champs)).GetResourceSet(CultureInfo.CurrentCulture, true, true);

		// Main Variables
		internal static DictionaryEntry _Pic1Id, _Pic2Id;
	}
}
