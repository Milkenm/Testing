﻿#region Usings
using System.Collections;
using System.Drawing;
using System.Drawing.Imaging;
using System.Globalization;
using System.IO;
using System.Resources;
using System.Windows;
using System.Windows.Media.Imaging;
using SolofightTacticsUI.Resources.Items;
using static SolofightTacticsUI.Functions;
#endregion Usings



namespace SolofightTacticsUI
{
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();

			// Events
			this.Loaded += new RoutedEventHandler((_Sender, _Event) => Loader(this));
		}
	}
}
