﻿#region Usings
using System;
using System.Collections;
using System.Drawing;

using static SolofightTacticsUI.Properties.Variables;
using static SolofightTacticsUI.Functions;
#endregion Usings



namespace SolofightTacticsUI
{
	internal partial class Functions
	{
		/// <summary>Event for when the user clicks on a base item.</summary>
		internal static void BaseItemsClick(DictionaryEntry _Resource)
		{
			bool _CraftingUpdated = false;
			#region Change the Item
			// # ################################################################################################ #
			if (_Main.pictureBox_crafting1.Source == null)
			{
				_Main.pictureBox_crafting1.Source = GetBitmapFromResource(_Resource);
				_Pic1Id = _Resource;
				_CraftingUpdated = true;
			}
			else if (_Main.pictureBox_crafting2.Source != GetBitmapFromResource(_Resource))
			{
				_Main.pictureBox_crafting2.Source = GetBitmapFromResource(_Resource);
				_Pic2Id = _Resource;
				_CraftingUpdated = true;
			}
			// # ################################################################################################ #
			#endregion Change the Item

			#region Calculate Craft
			// # ################################################################################################ #
			if (_Pic1Id.Key != null && _Pic2Id.Key != null && _CraftingUpdated == true)
			{
				int _CraftItemId = Convert.ToInt32($"{GetResourceId(_Pic1Id)}{GetResourceId(_Pic2Id)}");
				foreach (DictionaryEntry _EntryItem in _ComboItems)
				{
					int _EntryItemId = Convert.ToInt32(GetResourceId(_EntryItem));
					if (_EntryItemId == _CraftItemId || _EntryItemId == FlipNumber(_CraftItemId))
					{
						_Main.pictureBox_result.Source = GetBitmapFromResource(_EntryItem);
						break;
					}
				}
			}
			// # ################################################################################################ #
			#endregion Calculate Craft
		}
	}
}
