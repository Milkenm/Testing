﻿#region Usings
using System;
using System.Collections;

using static SolofightTacticsUI.Properties.Variables;
#endregion Usings



namespace SolofightTacticsUI
{
	internal partial class Functions
	{
		internal static void Crafting1Click(object sender, EventArgs e)
		{
			_Main.pictureBox_crafting1.Source = null;
			_Pic1Id = new DictionaryEntry();
			_Main.pictureBox_result.Source = null;
		}
	}
}
