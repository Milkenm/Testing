﻿#region Usings
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static SolofightTacticsUI.Properties.Variables;
using static SolofightTacticsUI.Functions;
#endregion Usings



namespace SolofightTacticsUI
{
	internal partial class Functions
	{
		internal static void LabelClearCraftingClick(object sender, EventArgs e)
		{
			if (_Main.pictureBox_crafting1.Source != null)
			{
				Crafting1Click(null, null);
			}
			if (_Main.pictureBox_crafting2 != null)
			{
				Crafting2Click(null, null);
			}
		}
	}
}
