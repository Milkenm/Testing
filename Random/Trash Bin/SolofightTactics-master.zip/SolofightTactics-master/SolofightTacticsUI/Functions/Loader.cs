﻿#region Usings
using System;
using System.Collections;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Input;
using static SolofightTacticsUI.Properties.Variables;
#endregion Usings



namespace SolofightTacticsUI
{
	internal partial class Functions
	{
		/// <summary>Load stuff when the application starts.</summary>
		internal static void Loader(MainWindow _MainWindow)
		{
			// Defines the variable
			_Main = _MainWindow;

			// Set Window Position
			_Main.Top = 10;
			_Main.Left = 0;

			// Load Base Items to Flow Panel
			foreach (DictionaryEntry _Resource in _BaseItems)
			{
				System.Windows.Controls.Image _PictureBox = new System.Windows.Controls.Image();
				_PictureBox.Source = GetBitmapFromResource(_Resource);
				_PictureBox.MouseDown += new MouseButtonEventHandler((_Sender, _Event) => BaseItemsClick(_Resource));
				_Main.flow_baseItems.Children.Add(_PictureBox);
			}

			// Load Combo Items to Flow Panel
			foreach (DictionaryEntry _Resource in _ComboItems)
			{
				System.Windows.Controls.Image _PictureBox = new System.Windows.Controls.Image();
				_PictureBox.Source = GetBitmapFromResource(_Resource);
				_PictureBox.MouseDown += new MouseButtonEventHandler((_Sender, _Event) => ComboItemsClick(_Resource));
				_Main.flow_comboItems.Children.Add(_PictureBox);
			}
		}
	}
}
