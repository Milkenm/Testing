﻿#region Usings
using System;
using System.Collections;

using ScriptsLib.Tools;
#endregion Usings



namespace SolofightTacticsUI
{
	internal partial class Functions
	{
		/// <summary>Returns the 'key' from the DictionaryEntry well formated.</summary>
		internal static int GetResourceId(DictionaryEntry _Resource)
		{
			return Convert.ToInt32(new Tools().ReplaceString(_Resource.Key.ToString(), "Item", ""));
		}
	}
}