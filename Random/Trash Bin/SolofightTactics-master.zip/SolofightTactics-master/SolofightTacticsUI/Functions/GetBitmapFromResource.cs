﻿#region Usings
using System.Collections;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Media.Imaging;
#endregion Usings



namespace SolofightTacticsUI
{
	internal partial class Functions
	{
		internal static BitmapFrame GetBitmapFromResource(DictionaryEntry _ImageResource)
		{
			Image _Image = new Bitmap((Image)_ImageResource.Value);

			MemoryStream _Stream = new MemoryStream();
			_Image.Save(_Stream, ImageFormat.Png);
			_Stream.Position = 0;

			BitmapFrame _Bitmap = BitmapFrame.Create(_Stream, BitmapCreateOptions.None, BitmapCacheOption.OnLoad);
			_Bitmap.Freeze();

			return _Bitmap;
		}
	}
}
