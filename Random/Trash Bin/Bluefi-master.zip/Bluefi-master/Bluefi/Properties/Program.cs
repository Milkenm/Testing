﻿#region Usings
using System;
using System.Windows.Forms;
#endregion Usings



namespace Bluefi
{
	internal static partial class Internal
	{
		[STAThread]
		internal static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new Main());
		}
	}
}
