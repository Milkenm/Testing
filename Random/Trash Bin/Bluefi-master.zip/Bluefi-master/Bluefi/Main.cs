﻿#region Usings
using System;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using static ScriptsLib.nNetwork.Packets;
using static Bluefi.Events;
using static Bluefi.Internal;
using static Bluefi.Functions;
using System.Net.Sockets;
using System.Net;
#endregion Usings



namespace Bluefi
{
	public partial class Main : Form
	{
		// # ###########################
		// # === > Load



		public Main()
		{
			InitializeComponent();
			Values._MainForm = this;
		}

		private void Event_Main_Load(object sender, System.EventArgs e)
		{
			MainLoad();
		}













		// # ###########################
		// # === > Events



		private void Event_ButtonSendFile_Click(object sender, System.EventArgs e)
		{
			SendFile();
		}

		private void Event_ButtonReceiveFile_Click(object sender, System.EventArgs e)
		{
			ReceiveFile();
		}

		private void Event_ButtonSearchFile_Click(object sender, System.EventArgs e)
		{
			SearchFile();
		}

		private void button_getFileBytes_Click(object sender, System.EventArgs e)
		{
			Testing();
		}
	}
}
