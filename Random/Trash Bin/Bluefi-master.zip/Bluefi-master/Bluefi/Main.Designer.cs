﻿namespace Bluefi
{
	partial class Main
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
			this.button_sendFile = new System.Windows.Forms.Button();
			this.button_receiveFile = new System.Windows.Forms.Button();
			this.textBox_searchFile = new System.Windows.Forms.TextBox();
			this.label_searchFile = new System.Windows.Forms.Label();
			this.button_searchFile = new System.Windows.Forms.Button();
			this.fileDialog = new System.Windows.Forms.OpenFileDialog();
			this.label_fileSize = new System.Windows.Forms.Label();
			this.textBox_receiveLocation = new System.Windows.Forms.TextBox();
			this.label_receiveLocation = new System.Windows.Forms.Label();
			this.textBox_receiverIp = new System.Windows.Forms.TextBox();
			this.label_receiverIp = new System.Windows.Forms.Label();
			this.button_getFileBytes = new System.Windows.Forms.Button();
			this.listBox_byteTesting = new System.Windows.Forms.ListBox();
			this.label_progressTesting = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// button_sendFile
			// 
			this.button_sendFile.Location = new System.Drawing.Point(141, 74);
			this.button_sendFile.Name = "button_sendFile";
			this.button_sendFile.Size = new System.Drawing.Size(106, 46);
			this.button_sendFile.TabIndex = 0;
			this.button_sendFile.Text = "Send File";
			this.button_sendFile.UseVisualStyleBackColor = true;
			this.button_sendFile.Click += new System.EventHandler(this.Event_ButtonSendFile_Click);
			// 
			// button_receiveFile
			// 
			this.button_receiveFile.Location = new System.Drawing.Point(410, 247);
			this.button_receiveFile.Name = "button_receiveFile";
			this.button_receiveFile.Size = new System.Drawing.Size(94, 31);
			this.button_receiveFile.TabIndex = 1;
			this.button_receiveFile.Text = "Receive File";
			this.button_receiveFile.UseVisualStyleBackColor = true;
			this.button_receiveFile.Click += new System.EventHandler(this.Event_ButtonReceiveFile_Click);
			// 
			// textBox_searchFile
			// 
			this.textBox_searchFile.Location = new System.Drawing.Point(44, 12);
			this.textBox_searchFile.Name = "textBox_searchFile";
			this.textBox_searchFile.Size = new System.Drawing.Size(394, 20);
			this.textBox_searchFile.TabIndex = 2;
			// 
			// label_searchFile
			// 
			this.label_searchFile.AutoSize = true;
			this.label_searchFile.Location = new System.Drawing.Point(12, 15);
			this.label_searchFile.Name = "label_searchFile";
			this.label_searchFile.Size = new System.Drawing.Size(26, 13);
			this.label_searchFile.TabIndex = 3;
			this.label_searchFile.Text = "File:";
			// 
			// button_searchFile
			// 
			this.button_searchFile.Location = new System.Drawing.Point(444, 11);
			this.button_searchFile.Name = "button_searchFile";
			this.button_searchFile.Size = new System.Drawing.Size(55, 22);
			this.button_searchFile.TabIndex = 4;
			this.button_searchFile.Text = "Search";
			this.button_searchFile.UseVisualStyleBackColor = true;
			this.button_searchFile.Click += new System.EventHandler(this.Event_ButtonSearchFile_Click);
			// 
			// label_fileSize
			// 
			this.label_fileSize.AutoSize = true;
			this.label_fileSize.Location = new System.Drawing.Point(41, 35);
			this.label_fileSize.Name = "label_fileSize";
			this.label_fileSize.Size = new System.Drawing.Size(52, 13);
			this.label_fileSize.TabIndex = 6;
			this.label_fileSize.Text = "<fileSize>";
			// 
			// textBox_receiveLocation
			// 
			this.textBox_receiveLocation.Location = new System.Drawing.Point(102, 221);
			this.textBox_receiveLocation.Name = "textBox_receiveLocation";
			this.textBox_receiveLocation.Size = new System.Drawing.Size(402, 20);
			this.textBox_receiveLocation.TabIndex = 7;
			// 
			// label_receiveLocation
			// 
			this.label_receiveLocation.AutoSize = true;
			this.label_receiveLocation.Location = new System.Drawing.Point(17, 224);
			this.label_receiveLocation.Name = "label_receiveLocation";
			this.label_receiveLocation.Size = new System.Drawing.Size(79, 13);
			this.label_receiveLocation.TabIndex = 8;
			this.label_receiveLocation.Text = "Save Location:";
			// 
			// textBox_receiverIp
			// 
			this.textBox_receiverIp.Location = new System.Drawing.Point(253, 100);
			this.textBox_receiverIp.Name = "textBox_receiverIp";
			this.textBox_receiverIp.Size = new System.Drawing.Size(185, 20);
			this.textBox_receiverIp.TabIndex = 9;
			// 
			// label_receiverIp
			// 
			this.label_receiverIp.AutoSize = true;
			this.label_receiverIp.Location = new System.Drawing.Point(253, 84);
			this.label_receiverIp.Name = "label_receiverIp";
			this.label_receiverIp.Size = new System.Drawing.Size(73, 13);
			this.label_receiverIp.TabIndex = 10;
			this.label_receiverIp.Text = "Receiver\'s IP:";
			// 
			// button_getFileBytes
			// 
			this.button_getFileBytes.Location = new System.Drawing.Point(141, 126);
			this.button_getFileBytes.Name = "button_getFileBytes";
			this.button_getFileBytes.Size = new System.Drawing.Size(106, 46);
			this.button_getFileBytes.TabIndex = 11;
			this.button_getFileBytes.Text = "Get File Bytes";
			this.button_getFileBytes.UseVisualStyleBackColor = true;
			this.button_getFileBytes.Click += new System.EventHandler(this.button_getFileBytes_Click);
			// 
			// listBox_byteTesting
			// 
			this.listBox_byteTesting.FormattingEnabled = true;
			this.listBox_byteTesting.Location = new System.Drawing.Point(12, 64);
			this.listBox_byteTesting.Name = "listBox_byteTesting";
			this.listBox_byteTesting.Size = new System.Drawing.Size(120, 95);
			this.listBox_byteTesting.TabIndex = 12;
			// 
			// label_progressTesting
			// 
			this.label_progressTesting.AutoSize = true;
			this.label_progressTesting.Location = new System.Drawing.Point(9, 162);
			this.label_progressTesting.Name = "label_progressTesting";
			this.label_progressTesting.Size = new System.Drawing.Size(59, 13);
			this.label_progressTesting.TabIndex = 13;
			this.label_progressTesting.Text = "<progress>";
			// 
			// Main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(516, 290);
			this.Controls.Add(this.label_progressTesting);
			this.Controls.Add(this.listBox_byteTesting);
			this.Controls.Add(this.button_getFileBytes);
			this.Controls.Add(this.label_receiverIp);
			this.Controls.Add(this.textBox_receiverIp);
			this.Controls.Add(this.label_receiveLocation);
			this.Controls.Add(this.textBox_receiveLocation);
			this.Controls.Add(this.label_fileSize);
			this.Controls.Add(this.button_searchFile);
			this.Controls.Add(this.label_searchFile);
			this.Controls.Add(this.textBox_searchFile);
			this.Controls.Add(this.button_receiveFile);
			this.Controls.Add(this.button_sendFile);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Main";
			this.Text = "BlueFi";
			this.Load += new System.EventHandler(this.Event_Main_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		internal System.Windows.Forms.Button button_sendFile;
		internal System.Windows.Forms.Button button_receiveFile;
		internal System.Windows.Forms.Button button_searchFile;
		internal System.Windows.Forms.TextBox textBox_searchFile;
		internal System.Windows.Forms.Label label_searchFile;
		internal System.Windows.Forms.OpenFileDialog fileDialog;
		internal System.Windows.Forms.Label label_fileSize;
		internal System.Windows.Forms.TextBox textBox_receiveLocation;
		internal System.Windows.Forms.Label label_receiveLocation;
		internal System.Windows.Forms.TextBox textBox_receiverIp;
		internal System.Windows.Forms.Label label_receiverIp;
		internal System.Windows.Forms.Label label_progressTesting;
		internal System.Windows.Forms.Button button_getFileBytes;
		internal System.Windows.Forms.ListBox listBox_byteTesting;
	}
}

