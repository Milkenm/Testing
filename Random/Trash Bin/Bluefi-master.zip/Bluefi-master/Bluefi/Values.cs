﻿namespace Bluefi
{
	internal static class Values
	{
		internal static readonly string _PacketEndString = @"\.\packetEnd\.\";

		internal static Main _MainForm { get; set; }
		internal static byte[] _FileBytes { get; set; }
	}
}