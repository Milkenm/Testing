﻿#region Usings
using System;

using static Bluefi.Values;
#endregion Usings



namespace Bluefi
{
	internal static partial class Internal
	{
		internal static void MainLoad()
		{
			// Labels
			_MainForm.label_fileSize.Text = "";
			_MainForm.label_progressTesting.Text = "";

			// TextBoxes
			_MainForm.textBox_receiveLocation.Text = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + @"\";
		}
	}
}
