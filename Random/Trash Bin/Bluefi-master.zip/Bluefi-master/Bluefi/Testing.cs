﻿#region Usings
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using static ScriptsLib.nNetwork.Packets;
using static Bluefi.Values;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using System.Net;
using static ScriptsLib.Tools;
#endregion Usings



namespace Bluefi
{
	internal static partial class Functions
	{
		internal static void Testing()
		{
			int _Port = 1300;

			new Task(new Action(() =>
			{
				Server(_Port);
			})).Start();
			Client("127.0.0.1", _Port);
		}


		internal static void Client(string _ServerHostname, int _Port, string _Message = "")
		{
			try
			{
				// Create a TcpClient.
				// Note, for this client to work you need to have a TcpServer 
				// connected to the same address as specified by the server, port
				// combination.
				TcpClient _Client = new TcpClient(_ServerHostname, _Port);

				// Translate the passed message into ASCII and store it as a Byte array.
				byte[] _Data = Encoding.ASCII.GetBytes(_Message);

				// Get a client stream for reading and writing.
				//  Stream stream = client.GetStream();
				NetworkStream _Stream = _Client.GetStream();

				// Send the message to the connected TcpServer. 
				_Stream.Write(_Data, 0, _Data.Length);
				Console.WriteLine("Sent: {0}", _Message);

				// Receive the TcpServer.response.

				// Buffer to store the response bytes.
				_Data = new byte[256];

				// String to store the response ASCII representation.
				string _ServerResponse = "";

				// Read the first batch of the TcpServer response bytes.
				int _Bytes = _Stream.Read(_Data, 0, _Data.Length);
				_ServerResponse = Encoding.ASCII.GetString(_Data, 0, _Bytes);
				Console.WriteLine("Received: {0}", _ServerResponse);

				// Close everything.
				_Stream.Close();
				_Client.Close();
			}
			catch (Exception e)
			{
				ShowException(e);
			}
		}

		internal static void Server(int _Port)
		{
			try
			{
				// TcpListener server = new TcpListener(port);
				TcpListener _Server = new TcpListener(IPAddress.Parse("127.0.0.1"), _Port);


				// Start listening for client requests.
				_Server.Start();

				// Buffer for reading data
				byte[] _Buffer = new byte[256];
				string _Data = null;

				// Enter the listening loop.
				while (true)
				{
					Console.Write("Waiting for a connection... ");

					// Perform a blocking call to accept requests.
					// You could also user server.AcceptSocket() here.
					TcpClient _Client = _Server.AcceptTcpClient();
					Console.WriteLine("Connected!");

					_Data = null;

					// Get a stream object for reading and writing
					NetworkStream _Stream = _Client.GetStream();

					int i;

					// Loop to receive all the data sent by the client.
					while ((i = _Stream.Read(_Buffer, 0, _Buffer.Length)) != 0)
					{
						// Translate data bytes to a ASCII string.
						_Data = Encoding.ASCII.GetString(_Buffer, 0, i);
						Console.WriteLine("Received: {0}", _Data);

						// Process the data sent by the client.
						_Data = _Data.ToUpper();

						byte[] _Message = Encoding.ASCII.GetBytes(_Data);

						// Send back a response.
						_Stream.Write(_Message, 0, _Message.Length);
						Console.WriteLine("Sent: {0}", _Data);
					}

					// Shutdown and end connection
					_Client.Close();
				}
			}
			catch (Exception e)
			{
				ShowException(e);
			}
		}
	}
}