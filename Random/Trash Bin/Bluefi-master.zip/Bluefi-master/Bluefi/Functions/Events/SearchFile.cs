﻿#region Usings
using System;
using System.ComponentModel;
using System.IO;
using System.Windows.Forms;

using static Bluefi.Functions;
using static Bluefi.Values;
#endregion Usings



namespace Bluefi
{
	internal static partial class Events
	{
		internal static void SearchFile()
		{
			_MainForm.fileDialog.FileOk += new CancelEventHandler((_Sender, _Event) => FileOk());
			_MainForm.fileDialog.ShowDialog();
		}

		private static void FileOk()
		{
			if (!string.IsNullOrEmpty(_MainForm.fileDialog.FileName))
			{
				_MainForm.textBox_searchFile.Text = _MainForm.fileDialog.FileName;

				_FileBytes = File.ReadAllBytes(_MainForm.textBox_searchFile.Text);
				_MainForm.label_fileSize.Text = "Size: " + GetFormatedFileSizeFromFileBytes(_FileBytes);
			}
		}
	}
}
