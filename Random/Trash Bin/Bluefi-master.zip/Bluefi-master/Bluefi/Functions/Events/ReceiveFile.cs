﻿#region Usings
using System;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;
using System.Windows.Forms;
using static Bluefi.Values;
using static ScriptsLib.nNetwork.Packets;
#endregion Usings



namespace Bluefi
{
	internal static partial class Events
	{
		internal static List<byte> _FileByteData = new List<byte>();
		internal static string _FilePath { get; set; }

		internal static void ReceiveFile()
		{
			_MainForm.button_receiveFile.Enabled = false;
			new Task(new Action(() =>
			{
				while (true)
				{
					String _UdpPacket = WaitUdpPacket(4269);

					if (!_UdpPacket.Contains(_PacketEndString))
					{
						new Task(new Action(() =>
						{
							MessageBox.Show("receive");
						})).Start();

						string[] _Packet = _UdpPacket.Split(',');

						_FilePath = _MainForm.textBox_receiveLocation.Text;
						if (!_FilePath.EndsWith(@"\"))
						{
							_FilePath = _FilePath + @"\";
						}
						_FilePath = _FilePath + _Packet[0];

						_FileByteData.Add(Convert.ToByte(_Packet[1]));
					}
					else
					{
						Stream _WriteStream = File.OpenWrite(_FilePath);
						
						foreach (byte _WriteByte in _FileByteData)
						{
							_WriteStream.WriteByte(_WriteByte);
							new Task(new Action(() =>
							{
								MessageBox.Show("write");
							})).Start();
						}

						_WriteStream.Dispose();

						MessageBox.Show("File received!");
						break;
					}
				}
				_MainForm.button_receiveFile.Enabled = true;
			})).Start();
		}
	}
}