﻿#region Usings
using System;
using System.IO;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

using static Bluefi.Values;
using static ScriptsLib.nNetwork.Packets;
#endregion Usings



namespace Bluefi
{
	internal static partial class Events
	{
		internal static void SendFile()
		{
			if (File.Exists(_MainForm.textBox_searchFile.Text))
			{
				new Task(new Action(() =>
				{
					foreach (byte _SendByte in _FileBytes)
					{
						
						SendUdpPacket(_MainForm.textBox_receiverIp.Text, 4269, $"{Path.GetFileName(_MainForm.textBox_searchFile.Text)},{_SendByte}");
						Thread.Sleep(1);
					}
					SendUdpPacket(_MainForm.textBox_receiverIp.Text, 4269, _PacketEndString);
				})).Start();
			}
			else
			{
				MessageBox.Show($"The file \"{_MainForm.textBox_searchFile.Text}\" was not found.", "File not found", MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}
	}
}