﻿#region Usings
using System;
#endregion Usings



namespace Bluefi
{
	internal static partial class Functions
	{
		internal static string GetFormatedFileSizeFromFileBytes(byte[] _FileBytes)
		{
			decimal _ParsedFileSize;
			Unit _ParseUnit;

			decimal _FileSizeGB = GetFileSizeFromBytes(_FileBytes, Unit.GB);
			if (decimal.Round(_FileSizeGB, 0, MidpointRounding.ToEven) > 0)
			{
				_ParsedFileSize = _FileSizeGB;
				_ParseUnit = Unit.GB;
			}
			else
			{
				decimal _FileSizeMB = GetFileSizeFromBytes(_FileBytes, Unit.MB);
				if (decimal.Round(_FileSizeMB, 0, MidpointRounding.ToEven) > 0)
				{
					_ParsedFileSize = _FileSizeMB;
					_ParseUnit = Unit.MB;
				}
				else
				{
					decimal _FileSizeKB = GetFileSizeFromBytes(_FileBytes, Unit.KB);
					if (decimal.Round(_FileSizeKB, 0, MidpointRounding.ToEven) > 0)
					{
						_ParsedFileSize = _FileSizeKB;
						_ParseUnit = Unit.KB;
					}
					else
					{
						_ParsedFileSize = GetFileSizeFromBytes(_FileBytes, Unit.B);
						_ParseUnit = Unit.B;
					}
				}
			}

			return $"{_ParsedFileSize} {_ParseUnit}";
		}
	}
}