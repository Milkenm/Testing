﻿#region Usings
using System;
using System.IO;
#endregion Usings



namespace Bluefi
{
	internal static partial class Functions
	{
		internal static decimal GetFileSize(string _FilePath, Unit _Unit, int _DecimalHouses = 2)
		{
			if (File.Exists(_FilePath))
			{
				byte[] _FileBytes = File.ReadAllBytes(_FilePath);
				decimal _ByteSize = _FileBytes.Length;

				decimal _Size;
				switch (_Unit)
				{
					case Unit.B:
						_Size = _ByteSize; break;
					case Unit.KB:
						_Size = _ByteSize / 1024; break;
					case Unit.MB:
						_Size = _ByteSize / 1024 / 1024; break;
					case Unit.GB:
						_Size = _ByteSize / 1024 / 1024 / 1024; break;
					default:
						throw new Exception();
				}
				if (_DecimalHouses > -1)
				{
					_Size = decimal.Round(_Size, _DecimalHouses);
				}

				return _Size;
			}
			else
			{
				throw new Exception("The file was not found.");
			}
		}



		internal enum Unit
		{
			B,
			KB,
			MB,
			GB,
		}
	}
}