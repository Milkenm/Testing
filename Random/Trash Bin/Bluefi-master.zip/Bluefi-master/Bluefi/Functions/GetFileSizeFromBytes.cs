﻿#region Usings
using System;
#endregion Usings



namespace Bluefi
{
	internal static partial class Functions
	{
		internal static decimal GetFileSizeFromBytes(byte[] _FileBytes, Unit _Unit, int _DecimalHouses = 2)
		{
			if (_FileBytes != null)
			{
				decimal _ByteSize = _FileBytes.Length;

				decimal _Size;
				switch (_Unit)
				{
					case Unit.B:
						_Size = _ByteSize; break;
					case Unit.KB:
						_Size = _ByteSize / 1024; break;
					case Unit.MB:
						_Size = _ByteSize / 1024 / 1024; break;
					case Unit.GB:
						_Size = _ByteSize / 1024 / 1024 / 1024; break;
					default:
						throw new Exception();
				}
				if (_DecimalHouses > -1)
				{
					_Size = decimal.Round(_Size, _DecimalHouses);
				}

				return _Size;
			}
			else
			{
				throw new Exception("There are no bytes to convert.");
			}
		}
	}
}