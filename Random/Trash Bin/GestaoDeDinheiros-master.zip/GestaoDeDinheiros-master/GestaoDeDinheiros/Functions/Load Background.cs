﻿using System.Drawing;
using System.IO;

using static GestaoDeDinheiros.Static;

namespace GestaoDeDinheiros
{
	internal static partial class Functions
	{
		internal static void LoadBackground()
		{
			if (WallpaperImage != null)
			{
				WallpaperImage.Dispose();
			}
			File.Delete(WallpaperPath + ".lock");

			if (File.Exists(WallpaperPath))
			{
				File.Copy(WallpaperPath, WallpaperPath + ".lock");
				WallpaperImage = Image.FromFile(WallpaperPath + ".lock");
			}
			else
			{
				WallpaperImage = null;
			}

			LoginForm.p_background.BackgroundImage = WallpaperImage;
			MainForm.p_background.BackgroundImage = WallpaperImage;
		}
	}
}