﻿using GestaoDeDinheiros.Forms;

using System;

using static GestaoDeDinheiros.Static;
using static ScriptsLib.nDatabases.AccessDatabase;

namespace GestaoDeDinheiros
{
	internal static partial class Functions
	{
		internal static void MainLoad()
		{
			_DatabasePath = AppContext.BaseDirectory + @"\DB_GestaoDeDinheiros.mdb";

			MainForm = new Main();
			OptionsForm = new Options();

			LoadBackground();
		}
	}
}