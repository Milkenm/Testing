﻿using System;
using System.Windows.Forms;

using static GestaoDeDinheiros.Functions;
using static GestaoDeDinheiros.Static;

namespace GestaoDeDinheiros.Forms
{
	public partial class Main : Form
	{
		public Main()
		{
			InitializeComponent();
		}

		private void FormLoad(object sender, EventArgs e)
		{
			p_titleBar.MouseDown += new MouseEventHandler((_send, _env) => AllowDrag(_env, this));
		}

		private void CloseForm(object sender, EventArgs e)
		{
			Close();
		}

		private void MinimizeForm(object sender, EventArgs e)
		{
			WindowState = FormWindowState.Minimized;
		}

		private void OpenSettings(object sender, EventArgs e)
		{
			OptionsForm.Show();
		}
	}
}