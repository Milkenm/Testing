﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;

using static GestaoDeDinheiros.Functions;
using static GestaoDeDinheiros.Static;

namespace GestaoDeDinheiros.Forms
{
	public partial class Options : Form
	{
		public Options()
		{
			InitializeComponent();
		}

		private void FormLoad(object sender, EventArgs e)
		{
			p_titleBar.MouseDown += new MouseEventHandler((_send, _env) => AllowDrag(_env, this));

			pb_wallpaper.Image = WallpaperImage;

			if (File.Exists(WallpaperPath))
			{
				l_semWallpaper.Visible = false;
			}
		}

		private void CloseForm(object sender, EventArgs e)
		{
			Hide();
		}

		private void ProcurarWallpaper(object sender, EventArgs e)
		{
			fd_searchWallpaper.ShowDialog();
		}

		private void OK_ProcurarWallpaper(object sender, CancelEventArgs e)
		{
			try
			{
				if (!string.IsNullOrEmpty(fd_searchWallpaper.FileName))
				{
					l_semWallpaper.Visible = false;

					pb_wallpaper.Image = Image.FromFile(fd_searchWallpaper.FileName);
					File.Delete(WallpaperPath);
					pb_wallpaper.Image.Save(WallpaperPath, ImageFormat.Png);

					LoadBackground();
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void RemoverWallpaper(object sender, EventArgs e)
		{
			l_semWallpaper.Visible = true;

			pb_wallpaper.Image = null;
			File.Delete(WallpaperPath);
			LoadBackground();
		}
	}
}