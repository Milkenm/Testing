﻿namespace GestaoDeDinheiros.Forms
{
				partial class Options
				{
								/// <summary>
								/// Required designer variable.
								/// </summary>
								private System.ComponentModel.IContainer components = null;

								/// <summary>
								/// Clean up any resources being used.
								/// </summary>
								/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
								protected override void Dispose(bool disposing)
								{
												if (disposing && (components != null))
												{
																components.Dispose();
												}
												base.Dispose(disposing);
								}

								#region Windows Form Designer generated code

								/// <summary>
								/// Required method for Designer support - do not modify
								/// the contents of this method with the code editor.
								/// </summary>
								private void InitializeComponent()
								{
												this.p_background = new System.Windows.Forms.Panel();
												this.gb_wallpaper = new System.Windows.Forms.GroupBox();
												this.b_removerWallpaper = new System.Windows.Forms.Button();
												this.p_wallpaper = new System.Windows.Forms.Panel();
												this.l_semWallpaper = new System.Windows.Forms.Label();
												this.b_procurarWallpaper = new System.Windows.Forms.Button();
												this.p_titleBar = new System.Windows.Forms.Panel();
												this.l_title = new System.Windows.Forms.Label();
												this.fd_searchWallpaper = new System.Windows.Forms.OpenFileDialog();
												this.pb_wallpaper = new System.Windows.Forms.PictureBox();
												this.b_close = new System.Windows.Forms.Button();
												this.p_background.SuspendLayout();
												this.gb_wallpaper.SuspendLayout();
												this.p_wallpaper.SuspendLayout();
												this.p_titleBar.SuspendLayout();
												((System.ComponentModel.ISupportInitialize)(this.pb_wallpaper)).BeginInit();
												this.SuspendLayout();
												// 
												// p_background
												// 
												this.p_background.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
												this.p_background.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
												this.p_background.Controls.Add(this.p_titleBar);
												this.p_background.Controls.Add(this.gb_wallpaper);
												this.p_background.Dock = System.Windows.Forms.DockStyle.Fill;
												this.p_background.Location = new System.Drawing.Point(0, 0);
												this.p_background.Name = "p_background";
												this.p_background.Size = new System.Drawing.Size(634, 357);
												this.p_background.TabIndex = 12;
												// 
												// gb_wallpaper
												// 
												this.gb_wallpaper.Controls.Add(this.b_removerWallpaper);
												this.gb_wallpaper.Controls.Add(this.p_wallpaper);
												this.gb_wallpaper.Controls.Add(this.b_procurarWallpaper);
												this.gb_wallpaper.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
												this.gb_wallpaper.ForeColor = System.Drawing.Color.Snow;
												this.gb_wallpaper.Location = new System.Drawing.Point(320, 38);
												this.gb_wallpaper.Name = "gb_wallpaper";
												this.gb_wallpaper.Size = new System.Drawing.Size(300, 217);
												this.gb_wallpaper.TabIndex = 17;
												this.gb_wallpaper.TabStop = false;
												this.gb_wallpaper.Text = "Wallpaper";
												// 
												// b_removerWallpaper
												// 
												this.b_removerWallpaper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
												this.b_removerWallpaper.FlatAppearance.BorderSize = 0;
												this.b_removerWallpaper.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_removerWallpaper.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
												this.b_removerWallpaper.ForeColor = System.Drawing.Color.Snow;
												this.b_removerWallpaper.Location = new System.Drawing.Point(138, 187);
												this.b_removerWallpaper.Name = "b_removerWallpaper";
												this.b_removerWallpaper.Size = new System.Drawing.Size(64, 23);
												this.b_removerWallpaper.TabIndex = 16;
												this.b_removerWallpaper.Text = "Remover";
												this.b_removerWallpaper.UseVisualStyleBackColor = false;
												this.b_removerWallpaper.Click += new System.EventHandler(this.RemoverWallpaper);
												// 
												// p_wallpaper
												// 
												this.p_wallpaper.Controls.Add(this.l_semWallpaper);
												this.p_wallpaper.Controls.Add(this.pb_wallpaper);
												this.p_wallpaper.Location = new System.Drawing.Point(6, 19);
												this.p_wallpaper.Name = "p_wallpaper";
												this.p_wallpaper.Size = new System.Drawing.Size(288, 162);
												this.p_wallpaper.TabIndex = 14;
												// 
												// l_semWallpaper
												// 
												this.l_semWallpaper.AutoSize = true;
												this.l_semWallpaper.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
												this.l_semWallpaper.ForeColor = System.Drawing.SystemColors.ButtonFace;
												this.l_semWallpaper.Location = new System.Drawing.Point(10, 67);
												this.l_semWallpaper.Name = "l_semWallpaper";
												this.l_semWallpaper.Size = new System.Drawing.Size(268, 22);
												this.l_semWallpaper.TabIndex = 9;
												this.l_semWallpaper.Text = "Nenhum wallpaper definido";
												// 
												// b_procurarWallpaper
												// 
												this.b_procurarWallpaper.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
												this.b_procurarWallpaper.FlatAppearance.BorderSize = 0;
												this.b_procurarWallpaper.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_procurarWallpaper.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
												this.b_procurarWallpaper.ForeColor = System.Drawing.Color.Snow;
												this.b_procurarWallpaper.Location = new System.Drawing.Point(208, 187);
												this.b_procurarWallpaper.Name = "b_procurarWallpaper";
												this.b_procurarWallpaper.Size = new System.Drawing.Size(86, 23);
												this.b_procurarWallpaper.TabIndex = 15;
												this.b_procurarWallpaper.Text = "Procurar";
												this.b_procurarWallpaper.UseVisualStyleBackColor = false;
												this.b_procurarWallpaper.Click += new System.EventHandler(this.ProcurarWallpaper);
												// 
												// p_titleBar
												// 
												this.p_titleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
												this.p_titleBar.Controls.Add(this.l_title);
												this.p_titleBar.Controls.Add(this.b_close);
												this.p_titleBar.Dock = System.Windows.Forms.DockStyle.Top;
												this.p_titleBar.Location = new System.Drawing.Point(0, 0);
												this.p_titleBar.Name = "p_titleBar";
												this.p_titleBar.Size = new System.Drawing.Size(632, 32);
												this.p_titleBar.TabIndex = 16;
												// 
												// l_title
												// 
												this.l_title.AutoSize = true;
												this.l_title.BackColor = System.Drawing.Color.Transparent;
												this.l_title.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
												this.l_title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(193)))), ((int)(((byte)(193)))));
												this.l_title.Location = new System.Drawing.Point(5, 7);
												this.l_title.Name = "l_title";
												this.l_title.Size = new System.Drawing.Size(86, 18);
												this.l_title.TabIndex = 13;
												this.l_title.Text = "Definições";
												// 
												// fd_searchWallpaper
												// 
												this.fd_searchWallpaper.Filter = "PNG Files|*.png|JPG Files|*.jpg";
												this.fd_searchWallpaper.FileOk += new System.ComponentModel.CancelEventHandler(this.OK_ProcurarWallpaper);
												// 
												// pb_wallpaper
												// 
												this.pb_wallpaper.BackColor = System.Drawing.Color.Transparent;
												this.pb_wallpaper.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
												this.pb_wallpaper.Dock = System.Windows.Forms.DockStyle.Fill;
												this.pb_wallpaper.Location = new System.Drawing.Point(0, 0);
												this.pb_wallpaper.Name = "pb_wallpaper";
												this.pb_wallpaper.Size = new System.Drawing.Size(288, 162);
												this.pb_wallpaper.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
												this.pb_wallpaper.TabIndex = 8;
												this.pb_wallpaper.TabStop = false;
												// 
												// b_close
												// 
												this.b_close.BackColor = System.Drawing.Color.Transparent;
												this.b_close.FlatAppearance.BorderSize = 0;
												this.b_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_close.Image = global::GestaoDeDinheiros.Properties.Resources.Close_PNG;
												this.b_close.Location = new System.Drawing.Point(551, 0);
												this.b_close.Name = "b_close";
												this.b_close.Size = new System.Drawing.Size(70, 23);
												this.b_close.TabIndex = 12;
												this.b_close.UseVisualStyleBackColor = false;
												this.b_close.Click += new System.EventHandler(this.CloseForm);
												// 
												// Options
												// 
												this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
												this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
												this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
												this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
												this.ClientSize = new System.Drawing.Size(634, 357);
												this.Controls.Add(this.p_background);
												this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
												this.Name = "Options";
												this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
												this.Text = "Settings";
												this.Load += new System.EventHandler(this.FormLoad);
												this.p_background.ResumeLayout(false);
												this.gb_wallpaper.ResumeLayout(false);
												this.p_wallpaper.ResumeLayout(false);
												this.p_wallpaper.PerformLayout();
												this.p_titleBar.ResumeLayout(false);
												this.p_titleBar.PerformLayout();
												((System.ComponentModel.ISupportInitialize)(this.pb_wallpaper)).EndInit();
												this.ResumeLayout(false);

								}

								#endregion

								private System.Windows.Forms.Panel p_background;
								private System.Windows.Forms.Label l_title;
								private System.Windows.Forms.Button b_close;
								private System.Windows.Forms.Button b_procurarWallpaper;
								private System.Windows.Forms.Panel p_wallpaper;
								private System.Windows.Forms.Label l_semWallpaper;
								private System.Windows.Forms.PictureBox pb_wallpaper;
								private System.Windows.Forms.OpenFileDialog fd_searchWallpaper;
								private System.Windows.Forms.Panel p_titleBar;
								private System.Windows.Forms.GroupBox gb_wallpaper;
								private System.Windows.Forms.Button b_removerWallpaper;
				}
}