﻿namespace GestaoDeDinheiros.Forms
{
				partial class Login
				{
								/// <summary>
								/// Required designer variable.
								/// </summary>
								private System.ComponentModel.IContainer components = null;

								/// <summary>
								/// Clean up any resources being used.
								/// </summary>
								/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
								protected override void Dispose(bool disposing)
								{
												if (disposing && (components != null))
												{
																components.Dispose();
												}
												base.Dispose(disposing);
								}

								#region Windows Form Designer generated code

								/// <summary>
								/// Required method for Designer support - do not modify
								/// the contents of this method with the code editor.
								/// </summary>
								private void InitializeComponent()
								{
												this.p_background = new System.Windows.Forms.Panel();
												this.p_titleBar = new System.Windows.Forms.Panel();
												this.l_title = new System.Windows.Forms.Label();
												this.b_close = new System.Windows.Forms.Button();
												this.b_login = new System.Windows.Forms.Button();
												this.tb_password = new System.Windows.Forms.TextBox();
												this.p_background.SuspendLayout();
												this.p_titleBar.SuspendLayout();
												this.SuspendLayout();
												// 
												// p_background
												// 
												this.p_background.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
												this.p_background.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
												this.p_background.Controls.Add(this.p_titleBar);
												this.p_background.Controls.Add(this.b_login);
												this.p_background.Controls.Add(this.tb_password);
												this.p_background.Dock = System.Windows.Forms.DockStyle.Fill;
												this.p_background.Location = new System.Drawing.Point(0, 0);
												this.p_background.Name = "p_background";
												this.p_background.Size = new System.Drawing.Size(480, 270);
												this.p_background.TabIndex = 0;
												// 
												// p_titleBar
												// 
												this.p_titleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
												this.p_titleBar.Controls.Add(this.l_title);
												this.p_titleBar.Controls.Add(this.b_close);
												this.p_titleBar.Dock = System.Windows.Forms.DockStyle.Top;
												this.p_titleBar.Location = new System.Drawing.Point(0, 0);
												this.p_titleBar.Name = "p_titleBar";
												this.p_titleBar.Size = new System.Drawing.Size(478, 32);
												this.p_titleBar.TabIndex = 20;
												// 
												// l_title
												// 
												this.l_title.AutoSize = true;
												this.l_title.BackColor = System.Drawing.Color.Transparent;
												this.l_title.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
												this.l_title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(193)))), ((int)(((byte)(193)))));
												this.l_title.Location = new System.Drawing.Point(5, 7);
												this.l_title.Name = "l_title";
												this.l_title.Size = new System.Drawing.Size(48, 18);
												this.l_title.TabIndex = 13;
												this.l_title.Text = "Login";
												// 
												// b_close
												// 
												this.b_close.BackColor = System.Drawing.Color.Transparent;
												this.b_close.FlatAppearance.BorderSize = 0;
												this.b_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_close.Image = global::GestaoDeDinheiros.Properties.Resources.Close_PNG;
												this.b_close.Location = new System.Drawing.Point(398, 0);
												this.b_close.Name = "b_close";
												this.b_close.Size = new System.Drawing.Size(70, 23);
												this.b_close.TabIndex = 12;
												this.b_close.UseVisualStyleBackColor = false;
												this.b_close.Click += new System.EventHandler(this.CloseForm);
												// 
												// b_login
												// 
												this.b_login.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(80)))), ((int)(((byte)(80)))), ((int)(((byte)(80)))));
												this.b_login.FlatAppearance.BorderSize = 0;
												this.b_login.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_login.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
												this.b_login.ForeColor = System.Drawing.Color.Snow;
												this.b_login.Location = new System.Drawing.Point(175, 178);
												this.b_login.Name = "b_login";
												this.b_login.Size = new System.Drawing.Size(130, 27);
												this.b_login.TabIndex = 22;
												this.b_login.Text = "Login";
												this.b_login.UseVisualStyleBackColor = false;
												this.b_login.Click += new System.EventHandler(this.Auth);
												// 
												// tb_password
												// 
												this.tb_password.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(100)))), ((int)(((byte)(100)))), ((int)(((byte)(100)))));
												this.tb_password.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
												this.tb_password.Font = new System.Drawing.Font("Century Gothic", 50.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
												this.tb_password.ForeColor = System.Drawing.Color.Snow;
												this.tb_password.Location = new System.Drawing.Point(27, 63);
												this.tb_password.MaxLength = 6;
												this.tb_password.Name = "tb_password";
												this.tb_password.PasswordChar = '●';
												this.tb_password.Size = new System.Drawing.Size(424, 90);
												this.tb_password.TabIndex = 21;
												this.tb_password.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
												this.tb_password.KeyDown += new System.Windows.Forms.KeyEventHandler(this.TextBoxEnter);
												// 
												// Login
												// 
												this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
												this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
												this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
												this.ClientSize = new System.Drawing.Size(480, 270);
												this.Controls.Add(this.p_background);
												this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
												this.Name = "Login";
												this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
												this.Text = "Login";
												this.Load += new System.EventHandler(this.FormLoad);
												this.p_background.ResumeLayout(false);
												this.p_background.PerformLayout();
												this.p_titleBar.ResumeLayout(false);
												this.p_titleBar.PerformLayout();
												this.ResumeLayout(false);

								}

								#endregion
								private System.Windows.Forms.Panel p_titleBar;
								private System.Windows.Forms.Label l_title;
								private System.Windows.Forms.Button b_close;
								private System.Windows.Forms.Button b_login;
								private System.Windows.Forms.TextBox tb_password;
								internal System.Windows.Forms.Panel p_background;
				}
}