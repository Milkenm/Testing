﻿namespace GestaoDeDinheiros.Forms
{
				partial class Main
				{
								/// <summary>
								/// Required designer variable.
								/// </summary>
								private System.ComponentModel.IContainer components = null;

								/// <summary>
								/// Clean up any resources being used.
								/// </summary>
								/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
								protected override void Dispose(bool disposing)
								{
												if (disposing && (components != null))
												{
																components.Dispose();
												}
												base.Dispose(disposing);
								}

								#region Windows Form Designer generated code

								/// <summary>
								/// Required method for Designer support - do not modify
								/// the contents of this method with the code editor.
								/// </summary>
								private void InitializeComponent()
								{
												this.p_background = new System.Windows.Forms.Panel();
												this.p_titleBar = new System.Windows.Forms.Panel();
												this.b_close = new System.Windows.Forms.Button();
												this.l_title = new System.Windows.Forms.Label();
												this.b_minimize = new System.Windows.Forms.Button();
												this.b_settings = new System.Windows.Forms.Button();
												this.p_background.SuspendLayout();
												this.p_titleBar.SuspendLayout();
												this.SuspendLayout();
												// 
												// p_background
												// 
												this.p_background.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
												this.p_background.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
												this.p_background.Controls.Add(this.p_titleBar);
												this.p_background.Dock = System.Windows.Forms.DockStyle.Fill;
												this.p_background.Location = new System.Drawing.Point(0, 0);
												this.p_background.Name = "p_background";
												this.p_background.Size = new System.Drawing.Size(960, 540);
												this.p_background.TabIndex = 5;
												// 
												// p_titleBar
												// 
												this.p_titleBar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(60)))), ((int)(((byte)(60)))), ((int)(((byte)(60)))));
												this.p_titleBar.Controls.Add(this.b_close);
												this.p_titleBar.Controls.Add(this.l_title);
												this.p_titleBar.Controls.Add(this.b_minimize);
												this.p_titleBar.Controls.Add(this.b_settings);
												this.p_titleBar.Dock = System.Windows.Forms.DockStyle.Top;
												this.p_titleBar.Location = new System.Drawing.Point(0, 0);
												this.p_titleBar.Name = "p_titleBar";
												this.p_titleBar.Size = new System.Drawing.Size(958, 32);
												this.p_titleBar.TabIndex = 5;
												// 
												// b_close
												// 
												this.b_close.BackColor = System.Drawing.Color.Transparent;
												this.b_close.FlatAppearance.BorderSize = 0;
												this.b_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_close.Image = global::GestaoDeDinheiros.Properties.Resources.Close_PNG;
												this.b_close.Location = new System.Drawing.Point(877, 0);
												this.b_close.Name = "b_close";
												this.b_close.Size = new System.Drawing.Size(70, 23);
												this.b_close.TabIndex = 0;
												this.b_close.UseVisualStyleBackColor = false;
												this.b_close.Click += new System.EventHandler(this.CloseForm);
												// 
												// l_title
												// 
												this.l_title.AutoSize = true;
												this.l_title.BackColor = System.Drawing.Color.Transparent;
												this.l_title.Font = new System.Drawing.Font("Century Gothic", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
												this.l_title.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(193)))), ((int)(((byte)(193)))), ((int)(((byte)(193)))));
												this.l_title.Location = new System.Drawing.Point(5, 7);
												this.l_title.Name = "l_title";
												this.l_title.Size = new System.Drawing.Size(157, 18);
												this.l_title.TabIndex = 3;
												this.l_title.Text = "Gestão de Dinheiros";
												// 
												// b_minimize
												// 
												this.b_minimize.BackColor = System.Drawing.Color.Transparent;
												this.b_minimize.FlatAppearance.BorderSize = 0;
												this.b_minimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_minimize.Image = global::GestaoDeDinheiros.Properties.Resources.Minimize_PNG;
												this.b_minimize.Location = new System.Drawing.Point(836, 0);
												this.b_minimize.Name = "b_minimize";
												this.b_minimize.Size = new System.Drawing.Size(40, 23);
												this.b_minimize.TabIndex = 1;
												this.b_minimize.UseVisualStyleBackColor = false;
												this.b_minimize.Click += new System.EventHandler(this.MinimizeForm);
												// 
												// b_settings
												// 
												this.b_settings.BackColor = System.Drawing.Color.Transparent;
												this.b_settings.FlatAppearance.BorderSize = 0;
												this.b_settings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_settings.Image = global::GestaoDeDinheiros.Properties.Resources.Settings_PNG;
												this.b_settings.Location = new System.Drawing.Point(787, 0);
												this.b_settings.Name = "b_settings";
												this.b_settings.Size = new System.Drawing.Size(40, 23);
												this.b_settings.TabIndex = 2;
												this.b_settings.UseVisualStyleBackColor = false;
												this.b_settings.Click += new System.EventHandler(this.OpenSettings);
												// 
												// Main
												// 
												this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
												this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
												this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(45)))), ((int)(((byte)(45)))), ((int)(((byte)(45)))));
												this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
												this.ClientSize = new System.Drawing.Size(960, 540);
												this.Controls.Add(this.p_background);
												this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
												this.Name = "Main";
												this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
												this.Text = "Gestão de Dinheiros";
												this.Load += new System.EventHandler(this.FormLoad);
												this.p_background.ResumeLayout(false);
												this.p_titleBar.ResumeLayout(false);
												this.p_titleBar.PerformLayout();
												this.ResumeLayout(false);

								}

								#endregion
								private System.Windows.Forms.Panel p_titleBar;
								private System.Windows.Forms.Button b_close;
								private System.Windows.Forms.Label l_title;
								private System.Windows.Forms.Button b_minimize;
								private System.Windows.Forms.Button b_settings;
								internal System.Windows.Forms.Panel p_background;
				}
}

