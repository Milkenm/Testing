﻿using System;
using System.Windows.Forms;

using static GestaoDeDinheiros.Functions;
using static GestaoDeDinheiros.Static;

namespace GestaoDeDinheiros.Forms
{
	public partial class Login : Form
	{
		public Login()
		{
			InitializeComponent();
		}

		private void FormLoad(object sender, EventArgs e)
		{
			LoginForm = this;
			MainLoad();
		}

		private void Auth(object sender, EventArgs e)
		{
			if (tb_password.Text == Settings.Password)
			{
				MainForm.Show();
				Hide();
			}
		}

		private void TextBoxEnter(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Enter)
			{
				b_login.PerformClick();
			}
		}

		private void CloseForm(object sender, EventArgs e)
		{
			Hide();
		}
	}
}