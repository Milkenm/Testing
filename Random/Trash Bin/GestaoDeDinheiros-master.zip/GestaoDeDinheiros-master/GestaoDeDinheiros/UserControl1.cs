﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace GestaoDeDinheiros
{
	public partial class UserControl1 : UserControl
	{
		private TextBox textBox = new TextBox();

		public UserControl1()
		{
			InitializeComponent();
			Paint += new PaintEventHandler(UserControl1_Paint);
			Resize += new EventHandler(UserControl1_Resize);
			textBox.Multiline = true;
			textBox.BorderStyle = BorderStyle.None;
			Controls.Add(textBox);
		}

		private void UserControl1_Resize(object sender, EventArgs e)
		{
			textBox.Size = new Size(Width - 3, Height - 2);
			textBox.Location = new Point(2, 1);
		}

		private void UserControl1_Paint(object sender, PaintEventArgs e)
		{
			ControlPaint.DrawBorder(e.Graphics, ClientRectangle, Color.Red, ButtonBorderStyle.Solid);
		}
	}
}