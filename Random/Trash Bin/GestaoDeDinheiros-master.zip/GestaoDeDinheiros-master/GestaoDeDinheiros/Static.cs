﻿using GestaoDeDinheiros.Forms;
using GestaoDeDinheiros.Properties;

using System;
using System.Drawing;

namespace GestaoDeDinheiros
{
	internal static class Static
	{
		// READ-ONLY
		internal static readonly string DatabasePath = AppContext.BaseDirectory + @"\DB_GestaoDeDinheiros.mdb";

		internal static readonly string WallpaperPath = AppContext.BaseDirectory + @"\Wallpaper.png";

		// PROJECT ITEMS
		internal static Settings Settings = new Settings();

		// FORMS
		internal static Login LoginForm;

		internal static Main MainForm;
		internal static Options OptionsForm;

		// TEMP
		internal static Image WallpaperImage = null;
	}
}