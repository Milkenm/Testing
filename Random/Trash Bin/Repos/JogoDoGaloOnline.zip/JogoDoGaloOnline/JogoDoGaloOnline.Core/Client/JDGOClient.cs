﻿
using JDGO.Core.Requests;

using JogoDoGaloOnline.Core.Extensions;

using ScriptsLib.Network;

using System;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace JDGO.Core.Client
{
	public class JDGOClient
	{
		public JDGOClient()
		{
			Security.OpenFirewallPort(Settings.GamePort, Security.PortType.UDP, "JDGO Client");

			Client.Connect(ServerEP);
			ListenToServer().FAF();
		}

		public delegate void ServerResponse(string msg);
		public event ServerResponse OnServerResponse;

		private static IPEndPoint ServerEP = new IPEndPoint(Settings.ServerIP, Settings.GamePort);

		private static readonly UdpClient Client = new UdpClient();

		private async Task ListenToServer()
		{
			while (true)
			{
				UdpReceiveResult data = await Client.ReceiveAsync().ConfigureAwait(false);

				Request request = Utils.ConvertByteArrayToObject<Request>(data.Buffer);
				OnServerResponse(request.Data.ToString());
			}
		}

		private async Task SendRequestAsync(RequestCode code, object data)
		{
			Request req = new Request(code, Convert.ToString(data));
			await req.SendRequestAsync(Client);
		}

		public async Task RequestLobbies()
		{
			await SendRequestAsync(RequestCode.CLIENT_RequestLobbies, null);
		}

		public async Task CreateLobby(string lobbyName)
		{
			await SendRequestAsync(RequestCode.CLIENT_CreateLobby, lobbyName);
		}

		public async Task JoinLobby(string lobbyName)
		{
			await SendRequestAsync(RequestCode.CLIENT_JoinLobby, lobbyName);
		}

		public async Task MakePlay(int slot)
		{
			await SendRequestAsync(RequestCode.CLIENT_MakePlay, slot);
		}
	}
}
