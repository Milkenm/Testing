﻿using System;
using System.Threading.Tasks;

namespace JogoDoGaloOnline.Core.Extensions
{
	// https://stackoverflow.com/a/22630057
	public static class TaskExtensions
	{
		/// <summary>
		/// Fire-and-forget!
		/// </summary>
		public static void FAF(this Task task)
		{
			task.ContinueWith(t => { Console.WriteLine(t.Exception); }, TaskContinuationOptions.OnlyOnFaulted);
		}
	}
}
