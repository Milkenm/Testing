﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace JDGO.Core.Requests
{
	public enum RequestCode
	{
		// CLIENT CODES
		CLIENT_CreateLobby,     // string
		CLIENT_RequestLobbies,  // #NULL
		CLIENT_JoinLobby,       // string
		CLIENT_LeaveLobby,      // #NULL
		CLIENT_MakePlay,        // int

		// SERVER CODES
		SERVER_LobbiesList,		// List<string>
		SERVER_Error,           // string
		SERVER_ForceRequest,		// Action
	}

	[Serializable]
	public class Request
	{
		public Request(RequestCode code, object data)
		{
			RequestCode = code;
			Data = data;
		}

		public RequestCode RequestCode { get; private set; }
		private object _Data;
		public object Data
		{
			get
			{
				return _Data ?? "#NULL";
			}
			private set
			{
				_Data = value;
			}
		}

		public async Task SendRequestAsync(UdpClient client, IPEndPoint endpoint)
		{
			byte[] data = Utils.ConvertObjectToByteArray(this);

			if (endpoint != null)
			{
				await client.SendAsync(data, data.Length, endpoint);
			}
			else
			{
				await client.SendAsync(data, data.Length);
			}
		}

		public async Task SendRequestAsync(UdpClient client)
		{
			await SendRequestAsync(client, null);
		}
	}
}
