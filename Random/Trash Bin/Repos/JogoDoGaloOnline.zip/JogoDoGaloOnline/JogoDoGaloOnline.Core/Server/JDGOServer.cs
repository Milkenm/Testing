﻿using JDGO.Core.Requests;

using JogoDoGaloOnline.Core.Extensions;
using JogoDoGaloOnline.Core.Server;

using ScriptsLib.Network;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;

namespace JDGO.Core.Server
{
	public class JDGOServer
	{
		public JDGOServer()
		{
			Security.OpenFirewallPort(Settings.GamePort, Security.PortType.UDP, "JDGO Server");
		}

		public delegate void JDGOServerCallBack(string log);
		public event JDGOServerCallBack Log;

		private static readonly UdpClient Server = new UdpClient(Settings.GamePort);

		public async Task StartAsync()
		{
			while (true)
			{
				try
				{
					UdpReceiveResult data = await Server.ReceiveAsync().ConfigureAwait(false);
					Log("Received data from: " + data.RemoteEndPoint.Address.ToString());

					Request request = Utils.ConvertByteArrayToObject<Request>(data.Buffer);
					ProcessClientRequest(request, data.RemoteEndPoint).FAF();
				}
				catch (Exception ex)
				{
					Log("ERROR: " + ex.Message);
				}
			}
		}

		private readonly List<Lobby> Lobbies = new List<Lobby>();

		private Lobby FindLobby(string lobbyName)
		{
			return ReturnLobby(Lobbies.Where(lobby => lobby.LobbyName == lobbyName));
		}

		private Lobby FindLobby(IPEndPoint player)
		{
			return ReturnLobby(Lobbies.Where(lobby => lobby.Players.Contains(player)));
		}

		private Lobby ReturnLobby(IEnumerable<Lobby> lobbies)
		{
			if (lobbies.Count() > 0)
			{
				return lobbies.First();
			}
			return null;
		}

		private async Task ProcessClientRequest(Request request, IPEndPoint playerEndpoint)
		{
			try
			{
				if (request.RequestCode == RequestCode.CLIENT_CreateLobby)
				{
					if (FindLobby((string)request.Data) == null)
					{
						Lobbies.Add(new Lobby((string)request.Data, playerEndpoint));
					}
					else
					{
						Request req = new Request(RequestCode.SERVER_Error, "A lobby named " + request.Data + " already exists.");
						await req.SendRequestAsync(Server, playerEndpoint);
					}
				}
				else if (request.RequestCode == RequestCode.CLIENT_JoinLobby)
				{
					Lobby lobby = FindLobby((string)request.Data);
					if (lobby != null)
					{
						lobby.AddPlayer(playerEndpoint);
					}
				}
				else if (request.RequestCode == RequestCode.CLIENT_LeaveLobby)
				{
					Lobby lobby = FindLobby(playerEndpoint);
					if (lobby != null)
					{
						lobby.RemovePlayer(playerEndpoint);
					}
				}
				else if (request.RequestCode == RequestCode.CLIENT_MakePlay)
				{
					throw new NotImplementedException();
				}
				else if (request.RequestCode == RequestCode.CLIENT_RequestLobbies)
				{
					throw new NotImplementedException();
				}

				Log(request.RequestCode.ToString() + " :: " + request.Data);
			}
			catch (Exception ex)
			{
				Log("ERROR: " + ex.Message);
			}
		}
	}
}
