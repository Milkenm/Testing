﻿using System.Collections.Generic;
using System.Net;

namespace JogoDoGaloOnline.Core.Server
{
	internal class Lobby
	{
		public Lobby(string name, IPEndPoint host)
		{
			LobbyName = name;
			Host = host;

			Players = new List<IPEndPoint>();
		}

		public string LobbyName { get; private set; }
		public IPEndPoint Host { get; private set; }

		public List<IPEndPoint> Players { get; private set; }

		public void AddPlayer(IPEndPoint ip)
		{
			Players.Add(ip);
		}

		public void RemovePlayer(IPEndPoint ip)
		{
			Players.Remove(ip);
		}
	}
}
