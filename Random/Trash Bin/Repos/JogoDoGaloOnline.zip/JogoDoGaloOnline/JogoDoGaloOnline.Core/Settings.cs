﻿using System.Linq;
using System.Net;

namespace JDGO.Core
{
	internal static class Settings
	{
		internal static readonly IPAddress ServerIP = Dns.GetHostEntry("fs.dserver.tk").AddressList.First(addr => addr.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork);
		internal static readonly int GamePort = 6969;
	}
}
