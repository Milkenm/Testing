﻿using JDGO.Core.Client;

namespace JDGO.Client
{
	internal class GlobalData
	{
		internal static readonly JDGOClient Client = new JDGOClient();
	}
}
