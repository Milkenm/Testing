﻿using System;
using System.Windows.Forms;

namespace JDGO.Client.Forms
{
	public partial class Game : Form
	{
		public Game()
		{
			InitializeComponent();
		}

		private async void HandlePlay(object sender, EventArgs e)
		{
			int slot = Convert.ToInt32(((Button)sender).Name.Replace("button", ""));
			await GlobalData.Client.MakePlay(slot).ConfigureAwait(false);
		}
	}
}
 