﻿namespace JDGO.Client.Forms
{
	partial class Lobby
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.listBox_lobbies = new System.Windows.Forms.ListBox();
			this.button_join = new System.Windows.Forms.Button();
			this.button_createLobby = new System.Windows.Forms.Button();
			this.textBox_lobbyName = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// listBox_lobbies
			// 
			this.listBox_lobbies.FormattingEnabled = true;
			this.listBox_lobbies.Location = new System.Drawing.Point(12, 12);
			this.listBox_lobbies.Name = "listBox_lobbies";
			this.listBox_lobbies.Size = new System.Drawing.Size(271, 290);
			this.listBox_lobbies.TabIndex = 0;
			// 
			// button_join
			// 
			this.button_join.Enabled = false;
			this.button_join.Location = new System.Drawing.Point(289, 12);
			this.button_join.Name = "button_join";
			this.button_join.Size = new System.Drawing.Size(36, 290);
			this.button_join.TabIndex = 1;
			this.button_join.Text = "Join";
			this.button_join.UseVisualStyleBackColor = true;
			this.button_join.Click += new System.EventHandler(this.JoinLobby);
			// 
			// button_createLobby
			// 
			this.button_createLobby.Enabled = false;
			this.button_createLobby.Location = new System.Drawing.Point(250, 332);
			this.button_createLobby.Name = "button_createLobby";
			this.button_createLobby.Size = new System.Drawing.Size(75, 22);
			this.button_createLobby.TabIndex = 2;
			this.button_createLobby.Text = "Criar Lobby";
			this.button_createLobby.UseVisualStyleBackColor = true;
			this.button_createLobby.Click += new System.EventHandler(this.CreateLobby);
			// 
			// textBox_lobbyName
			// 
			this.textBox_lobbyName.Location = new System.Drawing.Point(12, 333);
			this.textBox_lobbyName.Name = "textBox_lobbyName";
			this.textBox_lobbyName.Size = new System.Drawing.Size(232, 20);
			this.textBox_lobbyName.TabIndex = 3;
			this.textBox_lobbyName.TextChanged += new System.EventHandler(this.LobbyNameTextChanged);
			// 
			// Lobby
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(338, 371);
			this.Controls.Add(this.listBox_lobbies);
			this.Controls.Add(this.button_join);
			this.Controls.Add(this.button_createLobby);
			this.Controls.Add(this.textBox_lobbyName);
			this.Name = "Lobby";
			this.Text = "Lobby";
			this.Load += new System.EventHandler(this.Lobby_Load);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ListBox listBox_lobbies;
		private System.Windows.Forms.Button button_join;
		private System.Windows.Forms.Button button_createLobby;
		private System.Windows.Forms.TextBox textBox_lobbyName;
	}
}