﻿using System;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace JDGO.Client.Forms
{
	public partial class Lobby : Form
	{
		public Lobby()
		{
			InitializeComponent();
		}

		private void Lobby_Load(object sender, EventArgs e)
		{
			GlobalData.Client.OnServerResponse += OnServerResponse;

			RequestLobbies();
		}

		private void OnServerResponse(string msg)
		{
			MessageBox.Show(msg);
		}

		private async void RequestLobbies()
		{
			await GlobalData.Client.RequestLobbies();
		}

		private async void CreateLobby(object sender, EventArgs e)
		{
			await GlobalData.Client.CreateLobby(textBox_lobbyName.Text);
			RequestLobbies();
		}

		private void LobbyNameTextChanged(object sender, EventArgs e)
		{
			if (textBox_lobbyName.Text.Length >= 3)
			{
				button_createLobby.Enabled = true;
			}
		}

		private async void JoinLobby(object sender, EventArgs e)
		{
			if (listBox_lobbies.SelectedItem != null)
			{
				await GlobalData.Client.JoinLobby(listBox_lobbies.SelectedItem.ToString());
			}
		}
	}
}
