﻿using JDGO.Core.Server;

using System;

namespace JDGO.Server
{
	internal static class Server
	{
		private static void Main()
		{
			Log("Initializing...");
			JDGOServer server = new JDGOServer();
			Log("Initialized!");

			Log("Starting server...");
			server.StartAsync().ConfigureAwait(false);
			server.Log += Log;
			Log("Server running!");

			Console.ReadLine();
		}

		private static void Log(string data)
		{
			Console.WriteLine(" » " + data);
		}
	}
}
