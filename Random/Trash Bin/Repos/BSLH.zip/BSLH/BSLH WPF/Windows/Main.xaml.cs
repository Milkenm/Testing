﻿using BSLH.Assets;
using BSLH.Core;

using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Media;

namespace BSLH.WPF.Windows
{
	/// <summary>
	/// Interaction logic for Main.xaml
	/// </summary>
	public partial class Main : Window
	{
		private List<Keys> PressingKeys = new List<Keys>();
		private Timer Timer;

		public Main()
		{
			InitializeComponent();

			KeyboardHook kh = new KeyboardHook(true);
			kh.KeyDown += Keyboard_KeyDown;
			kh.KeyUp += Keyboard_KeyUp;

			Timer = new Timer();
			Timer.Interval = 1000 / 60;
			Timer.Tick += Timer_Tick;
			Timer.Start();
		}

		private void Timer_Tick(object sender, System.EventArgs e)
		{
			Assassin.Move(PressingKeys);
		}

		private void Keyboard_KeyDown(Keys key, bool shift, bool ctrl, bool alt)
		{
			if (!PressingKeys.Contains(key))
			{
				PressingKeys.Add(key);
			}
		}

		private void Keyboard_KeyUp(Keys key, bool shift, bool ctrl, bool alt)
		{
			PressingKeys.Remove(key);
			DetectCollisions(Assassin);
		}

		private bool DetectCollisions(FrameworkElement element)
		{
			Rect r1 = new Rect(Canvas.GetLeft(element), Canvas.GetTop(element), element.ActualWidth, element.ActualHeight);

			foreach (Visual visual in EnumVisual(this))
			{
				FrameworkElement v = ((FrameworkElement)visual);

				if (v.Tag?.ToString() == "wall")
				{
					Rect r2 = new Rect(Canvas.GetLeft(v), Canvas.GetTop(v), v.ActualWidth, v.ActualHeight);

					if (r1.IntersectsWith(r2))
					{
						return true;
					}
				}
			}

			return false;
		}

		public static List<Visual> EnumVisual(Visual myVisual)
		{
			List<Visual> visualList = new List<Visual>();

			for (int i = 0; i < VisualTreeHelper.GetChildrenCount(myVisual); i++)
			{
				Visual childVisual = (Visual)VisualTreeHelper.GetChild(myVisual, i);
				visualList.Add(childVisual);
				visualList.AddRange(EnumVisual(childVisual));
			}

			return visualList;
		}
	}
}
