﻿using System.Collections.Generic;
using System.ComponentModel;
using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Media;

namespace BSLH.Assets
{
	/// <summary>
	/// Interaction logic for Assassin.xaml
	/// </summary>
	public partial class Assassin : System.Windows.Controls.UserControl
	{
		private readonly TranslateTransform TT = new TranslateTransform();
		private readonly int MoveSpeed = 5;

		[Category("Flash"), Description("The ending color of the bar.")]
		public Image Sprite { get; set; }

		public Assassin()
		{
			InitializeComponent();

			RenderTransform = TT;
		}

		public void Move(List<Keys> keys)
		{
			if (keys.Contains(Keys.W))
			{
				TT.Y -= MoveSpeed;
			}
			if (keys.Contains(Keys.A))
			{
				TT.X -= MoveSpeed;
			}
			if (keys.Contains(Keys.S))
			{
				TT.Y += MoveSpeed;
			}
			if (keys.Contains(Keys.D))
			{
				TT.X += MoveSpeed;
			}
		}
	}
}
