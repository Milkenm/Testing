﻿using System;
using System.Runtime.InteropServices;
using System.Windows.Forms;

using static BSLH.Core.PInvoke.Kernel32;
using static BSLH.Core.PInvoke.User32;

namespace BSLH.Core
{
	// » https://stackoverflow.com/a/34290332 «
	public class KeyboardHook : IDisposable
	{
		private readonly bool Global;

		public delegate void KeyEventHandler(Keys key, bool shift, bool ctrl, bool alt);

		public event KeyEventHandler KeyDown;
		public event KeyEventHandler KeyUp;

		[StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
		public struct KBDLLHookStruct
		{
			public int vkCode;
			public int scanCode;
			public int flags;
			public int time;
			public int dwExtraInfo;
		}

		private readonly int HookID;

		public KeyboardHook(bool global)
		{
			Global = global;
			TheHookCB = new CallbackDelegate(KeybHookProc);

			if (Global)
			{
				HookID = SetWindowsHookEx(HookType.WH_KEYBOARD_LL, TheHookCB, 0, 0);
			}
			else
			{
				HookID = SetWindowsHookEx(HookType.WH_KEYBOARD, TheHookCB, 0, GetCurrentThreadId());
			}
		}

		private bool IsFinalized;

		~KeyboardHook()
		{
			Dispose();
		}

		public void Dispose()
		{
			if (!IsFinalized)
			{
				UnhookWindowsHookEx(HookID);
				IsFinalized = true;
			}
		}

		private int KeybHookProc(int code, int w, int l)
		{
			if (code < 0)
			{
				return CallNextHookEx(HookID, code, w, l);
			}
			try
			{
				if (!Global)
				{
					if (code == 3)
					{
						IntPtr ptr = IntPtr.Zero;

						int keydownup = l >> 30;
						if (keydownup == 0)
						{
							KeyDown?.Invoke((Keys)w, GetShiftPressed(), GetCtrlPressed(), GetAltPressed());
						}
						if (keydownup == -1)
						{
							KeyUp?.Invoke((Keys)w, GetShiftPressed(), GetCtrlPressed(), GetAltPressed());
						}
					}
				}
				else
				{
					KeyEvents kEvent = (KeyEvents)w;

					int vkCode = Marshal.ReadInt32((IntPtr)l);

					if (kEvent != KeyEvents.KeyDown && kEvent != KeyEvents.KeyUp && kEvent != KeyEvents.SKeyDown && kEvent != KeyEvents.SKeyUp)
					{
					}
					if (kEvent == KeyEvents.KeyDown || kEvent == KeyEvents.SKeyDown)
					{
						KeyDown?.Invoke((Keys)vkCode, GetShiftPressed(), GetCtrlPressed(), GetAltPressed());
					}
					if (kEvent == KeyEvents.KeyUp || kEvent == KeyEvents.SKeyUp)
					{
						KeyUp?.Invoke((Keys)vkCode, GetShiftPressed(), GetCtrlPressed(), GetAltPressed());
					}
				}
			}
			catch { }

			return CallNextHookEx(HookID, code, w, l);
		}

		public enum KeyEvents
		{
			KeyDown = 0x0100,
			KeyUp = 0x0101,
			SKeyDown = 0x0104,
			SKeyUp = 0x0105
		}

		public static bool GetCapslock()
		{
			return Convert.ToBoolean(GetKeyState(Keys.CapsLock));
		}

		public static bool GetNumlock()
		{
			return Convert.ToBoolean(GetKeyState(Keys.NumLock));
		}

		public static bool GetScrollLock()
		{
			return Convert.ToBoolean(GetKeyState(Keys.Scroll));
		}

		public static bool GetShiftPressed()
		{
			int state = GetKeyState(Keys.ShiftKey);
			return state < -1 || state > 1;
		}

		public static bool GetCtrlPressed()
		{
			int state = GetKeyState(Keys.ControlKey);
			return state < -1 || state > 1;
		}

		public static bool GetAltPressed()
		{
			int state = GetKeyState(Keys.Menu);
			return state < -1 || state > 1;
		}
	}
}
