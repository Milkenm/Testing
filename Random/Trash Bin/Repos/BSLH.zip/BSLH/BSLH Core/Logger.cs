﻿using System;
using System.IO;

namespace BSLH.Core
{
	public class Logger : IDisposable
	{
		private readonly StreamWriter sw;

		public Logger(string logFilePath)
		{
			Directory.CreateDirectory(Path.GetDirectoryName(logFilePath));

			sw = File.AppendText(logFilePath);
			sw.AutoFlush = true;
		}

		~Logger()
		{
			Dispose();
		}

		public void Dispose()
		{
			if (sw.BaseStream != null)
			{
				sw.Close();
			}
			sw.Dispose();
		}

		public void WriteEntry(LogType type, string message, bool printDate = true)
		{
			string date = "";
			if (printDate)
			{
				date = DateTime.Now.ToString("[dd#MM#yyyy - HH:mm:ss]").Replace('#', '/');
			}

			sw.WriteLine($"{date}[{type}] » {message}");
		}

		public enum LogType
		{
			Info,
			Warning,
			Error,
		}
	}
}
