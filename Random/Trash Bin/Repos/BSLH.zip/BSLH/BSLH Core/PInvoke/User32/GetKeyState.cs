﻿using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace BSLH.Core.PInvoke
{
	internal static partial class User32
	{
		[DllImport("user32.dll")]
		internal static extern short GetKeyState(Keys nVirtKey);
	}
}