﻿using System.Runtime.InteropServices;

namespace BSLH.Core.PInvoke
{
	internal static partial class User32
	{
		[DllImport("user32", CallingConvention = CallingConvention.StdCall)]
		internal static extern bool UnhookWindowsHookEx(int idHook);
	}
}