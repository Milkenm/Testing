﻿using System.Runtime.InteropServices;

namespace BSLH.Core.PInvoke
{
	internal static partial class Kernel32
	{
		[DllImport("kernel32.dll", CallingConvention = CallingConvention.StdCall)]
		internal static extern int GetCurrentThreadId();
	}
}