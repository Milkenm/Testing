﻿using System.Windows.Forms;

namespace JogoDoGalo
{
	internal static partial class Functions
	{
		internal static void AIPlay(Button button)
		{
			PlayHandler(button, "O");
		}
	}
}