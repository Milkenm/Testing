﻿namespace CSUi
{
	partial class Installer
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Installer));
			this.progressBar_installing = new System.Windows.Forms.ProgressBar();
			this.label_installing = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// progressBar_installing
			// 
			this.progressBar_installing.Location = new System.Drawing.Point(53, 42);
			this.progressBar_installing.Name = "progressBar_installing";
			this.progressBar_installing.Size = new System.Drawing.Size(368, 23);
			this.progressBar_installing.TabIndex = 0;
			// 
			// label_installing
			// 
			this.label_installing.AutoSize = true;
			this.label_installing.Location = new System.Drawing.Point(50, 26);
			this.label_installing.Name = "label_installing";
			this.label_installing.Size = new System.Drawing.Size(57, 13);
			this.label_installing.TabIndex = 1;
			this.label_installing.Text = "Installing...";
			// 
			// Installer
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(475, 106);
			this.Controls.Add(this.label_installing);
			this.Controls.Add(this.progressBar_installing);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "Installer";
			this.Text = "CS:GO Server Installer";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ProgressBar progressBar_installing;
		private System.Windows.Forms.Label label_installing;
	}
}