﻿namespace CSUi
{
	partial class Server
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Server));
			this.button_start = new System.Windows.Forms.Button();
			this.listBox_console = new System.Windows.Forms.ListBox();
			this.textBox_command = new System.Windows.Forms.TextBox();
			this.button_execute = new System.Windows.Forms.Button();
			this.panel_start = new System.Windows.Forms.Panel();
			this.label_cpu = new System.Windows.Forms.Label();
			this.progressBar_cpu = new System.Windows.Forms.ProgressBar();
			this.label_ram = new System.Windows.Forms.Label();
			this.progressBar_ram = new System.Windows.Forms.ProgressBar();
			this.tabs = new System.Windows.Forms.TabControl();
			this.tab_console = new System.Windows.Forms.TabPage();
			this.tab_settings = new System.Windows.Forms.TabPage();
			this.groupBox_gameMode = new System.Windows.Forms.GroupBox();
			this.comboBox_gameModes = new System.Windows.Forms.ComboBox();
			this.groupBox_map = new System.Windows.Forms.GroupBox();
			this.radio_clientMap = new System.Windows.Forms.RadioButton();
			this.comboBox_clientMaps = new System.Windows.Forms.ComboBox();
			this.radio_oldMapWorkshop = new System.Windows.Forms.RadioButton();
			this.comboBox_oldMapWorkshops = new System.Windows.Forms.ComboBox();
			this.radio_workshopMap = new System.Windows.Forms.RadioButton();
			this.textBox_workshopMap = new System.Windows.Forms.TextBox();
			this.link_helpWorkshop = new System.Windows.Forms.LinkLabel();
			this.groupBox_authKeys = new System.Windows.Forms.GroupBox();
			this.link_gslt = new System.Windows.Forms.LinkLabel();
			this.textBox_gslt = new System.Windows.Forms.TextBox();
			this.link_apiKey = new System.Windows.Forms.LinkLabel();
			this.textBox_apiKey = new System.Windows.Forms.TextBox();
			this.groupBox_serverSettings = new System.Windows.Forms.GroupBox();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label_password = new System.Windows.Forms.Label();
			this.textBox_password = new System.Windows.Forms.TextBox();
			this.button_password = new System.Windows.Forms.Button();
			this.label_rcon = new System.Windows.Forms.Label();
			this.textBox_rcon = new System.Windows.Forms.TextBox();
			this.button_rcon = new System.Windows.Forms.Button();
			this.label_arguments = new System.Windows.Forms.Label();
			this.textBox_arguments = new System.Windows.Forms.TextBox();
			this.button_save = new System.Windows.Forms.Button();
			this.button_cancel = new System.Windows.Forms.Button();
			this.checkBox_vac = new System.Windows.Forms.CheckBox();
			this.groupBox_vac = new System.Windows.Forms.GroupBox();
			this.panel_start.SuspendLayout();
			this.tabs.SuspendLayout();
			this.tab_console.SuspendLayout();
			this.tab_settings.SuspendLayout();
			this.groupBox_gameMode.SuspendLayout();
			this.groupBox_map.SuspendLayout();
			this.groupBox_authKeys.SuspendLayout();
			this.groupBox_serverSettings.SuspendLayout();
			this.groupBox_vac.SuspendLayout();
			this.SuspendLayout();
			// 
			// button_start
			// 
			this.button_start.Location = new System.Drawing.Point(419, 28);
			this.button_start.Name = "button_start";
			this.button_start.Size = new System.Drawing.Size(101, 44);
			this.button_start.TabIndex = 15;
			this.button_start.Text = "Start";
			this.button_start.UseVisualStyleBackColor = true;
			this.button_start.Click += new System.EventHandler(this.button_start_Click);
			// 
			// listBox_console
			// 
			this.listBox_console.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.listBox_console.FormattingEnabled = true;
			this.listBox_console.Location = new System.Drawing.Point(6, 112);
			this.listBox_console.Name = "listBox_console";
			this.listBox_console.Size = new System.Drawing.Size(588, 238);
			this.listBox_console.TabIndex = 16;
			// 
			// textBox_command
			// 
			this.textBox_command.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.textBox_command.Location = new System.Drawing.Point(6, 360);
			this.textBox_command.Name = "textBox_command";
			this.textBox_command.Size = new System.Drawing.Size(488, 20);
			this.textBox_command.TabIndex = 17;
			// 
			// button_execute
			// 
			this.button_execute.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
			this.button_execute.Location = new System.Drawing.Point(500, 359);
			this.button_execute.Name = "button_execute";
			this.button_execute.Size = new System.Drawing.Size(94, 22);
			this.button_execute.TabIndex = 18;
			this.button_execute.Text = "Execute";
			this.button_execute.UseVisualStyleBackColor = true;
			this.button_execute.Click += new System.EventHandler(this.button_execute_Click);
			// 
			// panel_start
			// 
			this.panel_start.Controls.Add(this.label_cpu);
			this.panel_start.Controls.Add(this.progressBar_cpu);
			this.panel_start.Controls.Add(this.label_ram);
			this.panel_start.Controls.Add(this.progressBar_ram);
			this.panel_start.Controls.Add(this.button_start);
			this.panel_start.Location = new System.Drawing.Point(6, 6);
			this.panel_start.Name = "panel_start";
			this.panel_start.Size = new System.Drawing.Size(588, 100);
			this.panel_start.TabIndex = 19;
			// 
			// label_cpu
			// 
			this.label_cpu.AutoSize = true;
			this.label_cpu.Location = new System.Drawing.Point(63, 28);
			this.label_cpu.Name = "label_cpu";
			this.label_cpu.Size = new System.Drawing.Size(32, 13);
			this.label_cpu.TabIndex = 18;
			this.label_cpu.Text = "CPU:";
			// 
			// progressBar_cpu
			// 
			this.progressBar_cpu.Location = new System.Drawing.Point(103, 24);
			this.progressBar_cpu.Name = "progressBar_cpu";
			this.progressBar_cpu.Size = new System.Drawing.Size(246, 23);
			this.progressBar_cpu.TabIndex = 16;
			// 
			// label_ram
			// 
			this.label_ram.AutoSize = true;
			this.label_ram.Location = new System.Drawing.Point(63, 59);
			this.label_ram.Name = "label_ram";
			this.label_ram.Size = new System.Drawing.Size(34, 13);
			this.label_ram.TabIndex = 19;
			this.label_ram.Text = "RAM:";
			// 
			// progressBar_ram
			// 
			this.progressBar_ram.Location = new System.Drawing.Point(103, 53);
			this.progressBar_ram.Name = "progressBar_ram";
			this.progressBar_ram.Size = new System.Drawing.Size(246, 23);
			this.progressBar_ram.TabIndex = 17;
			// 
			// tabs
			// 
			this.tabs.Controls.Add(this.tab_console);
			this.tabs.Controls.Add(this.tab_settings);
			this.tabs.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabs.Location = new System.Drawing.Point(0, 0);
			this.tabs.Name = "tabs";
			this.tabs.SelectedIndex = 0;
			this.tabs.Size = new System.Drawing.Size(612, 414);
			this.tabs.TabIndex = 20;
			// 
			// tab_console
			// 
			this.tab_console.Controls.Add(this.panel_start);
			this.tab_console.Controls.Add(this.listBox_console);
			this.tab_console.Controls.Add(this.textBox_command);
			this.tab_console.Controls.Add(this.button_execute);
			this.tab_console.Location = new System.Drawing.Point(4, 22);
			this.tab_console.Name = "tab_console";
			this.tab_console.Padding = new System.Windows.Forms.Padding(3);
			this.tab_console.Size = new System.Drawing.Size(604, 388);
			this.tab_console.TabIndex = 0;
			this.tab_console.Text = "📊 Console";
			this.tab_console.UseVisualStyleBackColor = true;
			// 
			// tab_settings
			// 
			this.tab_settings.Controls.Add(this.groupBox_gameMode);
			this.tab_settings.Controls.Add(this.groupBox_vac);
			this.tab_settings.Controls.Add(this.groupBox_map);
			this.tab_settings.Controls.Add(this.groupBox_authKeys);
			this.tab_settings.Controls.Add(this.groupBox_serverSettings);
			this.tab_settings.Controls.Add(this.button_save);
			this.tab_settings.Controls.Add(this.button_cancel);
			this.tab_settings.Location = new System.Drawing.Point(4, 22);
			this.tab_settings.Name = "tab_settings";
			this.tab_settings.Padding = new System.Windows.Forms.Padding(3);
			this.tab_settings.Size = new System.Drawing.Size(604, 388);
			this.tab_settings.TabIndex = 1;
			this.tab_settings.Text = "⚙️ Settings";
			this.tab_settings.UseVisualStyleBackColor = true;
			// 
			// groupBox_gameMode
			// 
			this.groupBox_gameMode.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.groupBox_gameMode.Controls.Add(this.comboBox_gameModes);
			this.groupBox_gameMode.Location = new System.Drawing.Point(43, 12);
			this.groupBox_gameMode.Name = "groupBox_gameMode";
			this.groupBox_gameMode.Size = new System.Drawing.Size(163, 48);
			this.groupBox_gameMode.TabIndex = 12;
			this.groupBox_gameMode.TabStop = false;
			this.groupBox_gameMode.Text = "Game Mode";
			// 
			// comboBox_gameModes
			// 
			this.comboBox_gameModes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_gameModes.FormattingEnabled = true;
			this.comboBox_gameModes.Location = new System.Drawing.Point(21, 17);
			this.comboBox_gameModes.Name = "comboBox_gameModes";
			this.comboBox_gameModes.Size = new System.Drawing.Size(121, 21);
			this.comboBox_gameModes.Sorted = true;
			this.comboBox_gameModes.TabIndex = 0;
			// 
			// groupBox_map
			// 
			this.groupBox_map.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.groupBox_map.Controls.Add(this.radio_clientMap);
			this.groupBox_map.Controls.Add(this.comboBox_clientMaps);
			this.groupBox_map.Controls.Add(this.radio_oldMapWorkshop);
			this.groupBox_map.Controls.Add(this.comboBox_oldMapWorkshops);
			this.groupBox_map.Controls.Add(this.radio_workshopMap);
			this.groupBox_map.Controls.Add(this.textBox_workshopMap);
			this.groupBox_map.Controls.Add(this.link_helpWorkshop);
			this.groupBox_map.Location = new System.Drawing.Point(267, 12);
			this.groupBox_map.Name = "groupBox_map";
			this.groupBox_map.Size = new System.Drawing.Size(294, 100);
			this.groupBox_map.TabIndex = 13;
			this.groupBox_map.TabStop = false;
			this.groupBox_map.Text = "Map";
			// 
			// radio_clientMap
			// 
			this.radio_clientMap.AutoSize = true;
			this.radio_clientMap.Checked = true;
			this.radio_clientMap.Location = new System.Drawing.Point(6, 19);
			this.radio_clientMap.Name = "radio_clientMap";
			this.radio_clientMap.Size = new System.Drawing.Size(75, 17);
			this.radio_clientMap.TabIndex = 5;
			this.radio_clientMap.TabStop = true;
			this.radio_clientMap.Text = "Client Map";
			this.radio_clientMap.UseVisualStyleBackColor = true;
			this.radio_clientMap.CheckedChanged += new System.EventHandler(this.RefreshGameModes);
			// 
			// comboBox_clientMaps
			// 
			this.comboBox_clientMaps.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_clientMaps.FormattingEnabled = true;
			this.comboBox_clientMaps.Location = new System.Drawing.Point(127, 18);
			this.comboBox_clientMaps.Name = "comboBox_clientMaps";
			this.comboBox_clientMaps.Size = new System.Drawing.Size(161, 21);
			this.comboBox_clientMaps.Sorted = true;
			this.comboBox_clientMaps.TabIndex = 2;
			this.comboBox_clientMaps.SelectedIndexChanged += new System.EventHandler(this.RefreshGameModes);
			// 
			// radio_oldMapWorkshop
			// 
			this.radio_oldMapWorkshop.AutoSize = true;
			this.radio_oldMapWorkshop.Location = new System.Drawing.Point(6, 46);
			this.radio_oldMapWorkshop.Name = "radio_oldMapWorkshop";
			this.radio_oldMapWorkshop.Size = new System.Drawing.Size(117, 17);
			this.radio_oldMapWorkshop.TabIndex = 6;
			this.radio_oldMapWorkshop.Text = "Old Map Workshop";
			this.radio_oldMapWorkshop.UseVisualStyleBackColor = true;
			this.radio_oldMapWorkshop.CheckedChanged += new System.EventHandler(this.RefreshGameModes);
			// 
			// comboBox_oldMapWorkshops
			// 
			this.comboBox_oldMapWorkshops.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.comboBox_oldMapWorkshops.FormattingEnabled = true;
			this.comboBox_oldMapWorkshops.Location = new System.Drawing.Point(127, 45);
			this.comboBox_oldMapWorkshops.Name = "comboBox_oldMapWorkshops";
			this.comboBox_oldMapWorkshops.Size = new System.Drawing.Size(161, 21);
			this.comboBox_oldMapWorkshops.Sorted = true;
			this.comboBox_oldMapWorkshops.TabIndex = 4;
			this.comboBox_oldMapWorkshops.SelectedIndexChanged += new System.EventHandler(this.RefreshGameModes);
			// 
			// radio_workshopMap
			// 
			this.radio_workshopMap.AutoSize = true;
			this.radio_workshopMap.Location = new System.Drawing.Point(6, 73);
			this.radio_workshopMap.Name = "radio_workshopMap";
			this.radio_workshopMap.Size = new System.Drawing.Size(98, 17);
			this.radio_workshopMap.TabIndex = 8;
			this.radio_workshopMap.Text = "Workshop Map";
			this.radio_workshopMap.UseVisualStyleBackColor = true;
			this.radio_workshopMap.CheckedChanged += new System.EventHandler(this.RefreshGameModes);
			// 
			// textBox_workshopMap
			// 
			this.textBox_workshopMap.Location = new System.Drawing.Point(127, 72);
			this.textBox_workshopMap.MaxLength = 15;
			this.textBox_workshopMap.Name = "textBox_workshopMap";
			this.textBox_workshopMap.Size = new System.Drawing.Size(117, 20);
			this.textBox_workshopMap.TabIndex = 9;
			// 
			// link_helpWorkshop
			// 
			this.link_helpWorkshop.AutoSize = true;
			this.link_helpWorkshop.Location = new System.Drawing.Point(250, 77);
			this.link_helpWorkshop.Name = "link_helpWorkshop";
			this.link_helpWorkshop.Size = new System.Drawing.Size(13, 13);
			this.link_helpWorkshop.TabIndex = 10;
			this.link_helpWorkshop.TabStop = true;
			this.link_helpWorkshop.Text = "?";
			this.link_helpWorkshop.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_helpWorkshop_LinkClicked);
			// 
			// groupBox_authKeys
			// 
			this.groupBox_authKeys.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.groupBox_authKeys.Controls.Add(this.link_gslt);
			this.groupBox_authKeys.Controls.Add(this.textBox_gslt);
			this.groupBox_authKeys.Controls.Add(this.link_apiKey);
			this.groupBox_authKeys.Controls.Add(this.textBox_apiKey);
			this.groupBox_authKeys.Location = new System.Drawing.Point(43, 121);
			this.groupBox_authKeys.Name = "groupBox_authKeys";
			this.groupBox_authKeys.Size = new System.Drawing.Size(518, 84);
			this.groupBox_authKeys.TabIndex = 14;
			this.groupBox_authKeys.TabStop = false;
			this.groupBox_authKeys.Text = "Auth Keys";
			// 
			// link_gslt
			// 
			this.link_gslt.AutoSize = true;
			this.link_gslt.Location = new System.Drawing.Point(24, 25);
			this.link_gslt.Name = "link_gslt";
			this.link_gslt.Size = new System.Drawing.Size(135, 13);
			this.link_gslt.TabIndex = 22;
			this.link_gslt.TabStop = true;
			this.link_gslt.Text = "Game Server Login Token:";
			this.link_gslt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_gslt_LinkClicked);
			// 
			// textBox_gslt
			// 
			this.textBox_gslt.Location = new System.Drawing.Point(178, 22);
			this.textBox_gslt.MaxLength = 32;
			this.textBox_gslt.Name = "textBox_gslt";
			this.textBox_gslt.PasswordChar = '●';
			this.textBox_gslt.Size = new System.Drawing.Size(317, 20);
			this.textBox_gslt.TabIndex = 18;
			// 
			// link_apiKey
			// 
			this.link_apiKey.AutoSize = true;
			this.link_apiKey.Location = new System.Drawing.Point(24, 51);
			this.link_apiKey.Name = "link_apiKey";
			this.link_apiKey.Size = new System.Drawing.Size(81, 13);
			this.link_apiKey.TabIndex = 23;
			this.link_apiKey.TabStop = true;
			this.link_apiKey.Text = "Steam API Key:";
			this.link_apiKey.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.link_apiKey_LinkClicked);
			// 
			// textBox_apiKey
			// 
			this.textBox_apiKey.Location = new System.Drawing.Point(178, 48);
			this.textBox_apiKey.MaxLength = 32;
			this.textBox_apiKey.Name = "textBox_apiKey";
			this.textBox_apiKey.PasswordChar = '●';
			this.textBox_apiKey.Size = new System.Drawing.Size(317, 20);
			this.textBox_apiKey.TabIndex = 19;
			// 
			// groupBox_serverSettings
			// 
			this.groupBox_serverSettings.Controls.Add(this.textBox1);
			this.groupBox_serverSettings.Controls.Add(this.label_password);
			this.groupBox_serverSettings.Controls.Add(this.textBox_password);
			this.groupBox_serverSettings.Controls.Add(this.button_password);
			this.groupBox_serverSettings.Controls.Add(this.label_rcon);
			this.groupBox_serverSettings.Controls.Add(this.textBox_rcon);
			this.groupBox_serverSettings.Controls.Add(this.button_rcon);
			this.groupBox_serverSettings.Controls.Add(this.label_arguments);
			this.groupBox_serverSettings.Controls.Add(this.textBox_arguments);
			this.groupBox_serverSettings.Location = new System.Drawing.Point(43, 215);
			this.groupBox_serverSettings.Name = "groupBox_serverSettings";
			this.groupBox_serverSettings.Size = new System.Drawing.Size(518, 133);
			this.groupBox_serverSettings.TabIndex = 15;
			this.groupBox_serverSettings.TabStop = false;
			this.groupBox_serverSettings.Text = "Server Settings";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(6, 122);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(518, 20);
			this.textBox1.TabIndex = 18;
			// 
			// label_password
			// 
			this.label_password.AutoSize = true;
			this.label_password.Location = new System.Drawing.Point(24, 27);
			this.label_password.Name = "label_password";
			this.label_password.Size = new System.Drawing.Size(90, 13);
			this.label_password.TabIndex = 22;
			this.label_password.Text = "Server Password:";
			// 
			// textBox_password
			// 
			this.textBox_password.Location = new System.Drawing.Point(178, 24);
			this.textBox_password.Name = "textBox_password";
			this.textBox_password.PasswordChar = '●';
			this.textBox_password.Size = new System.Drawing.Size(176, 20);
			this.textBox_password.TabIndex = 22;
			// 
			// button_password
			// 
			this.button_password.Location = new System.Drawing.Point(360, 23);
			this.button_password.Name = "button_password";
			this.button_password.Size = new System.Drawing.Size(27, 22);
			this.button_password.TabIndex = 27;
			this.button_password.Text = "👁️";
			this.button_password.UseVisualStyleBackColor = true;
			this.button_password.Click += new System.EventHandler(this.button_password_Click);
			// 
			// label_rcon
			// 
			this.label_rcon.AutoSize = true;
			this.label_rcon.Location = new System.Drawing.Point(24, 53);
			this.label_rcon.Name = "label_rcon";
			this.label_rcon.Size = new System.Drawing.Size(90, 13);
			this.label_rcon.TabIndex = 24;
			this.label_rcon.Text = "RCON Password:";
			// 
			// textBox_rcon
			// 
			this.textBox_rcon.Location = new System.Drawing.Point(178, 50);
			this.textBox_rcon.Name = "textBox_rcon";
			this.textBox_rcon.PasswordChar = '●';
			this.textBox_rcon.Size = new System.Drawing.Size(176, 20);
			this.textBox_rcon.TabIndex = 23;
			// 
			// button_rcon
			// 
			this.button_rcon.Location = new System.Drawing.Point(360, 49);
			this.button_rcon.Name = "button_rcon";
			this.button_rcon.Size = new System.Drawing.Size(27, 22);
			this.button_rcon.TabIndex = 28;
			this.button_rcon.Text = "👁️";
			this.button_rcon.UseVisualStyleBackColor = true;
			this.button_rcon.Click += new System.EventHandler(this.button_rcon_Click);
			// 
			// label_arguments
			// 
			this.label_arguments.AutoSize = true;
			this.label_arguments.Location = new System.Drawing.Point(24, 79);
			this.label_arguments.Name = "label_arguments";
			this.label_arguments.Size = new System.Drawing.Size(112, 13);
			this.label_arguments.TabIndex = 25;
			this.label_arguments.Text = "Advanced Arguments:";
			// 
			// textBox_arguments
			// 
			this.textBox_arguments.Location = new System.Drawing.Point(178, 76);
			this.textBox_arguments.Multiline = true;
			this.textBox_arguments.Name = "textBox_arguments";
			this.textBox_arguments.Size = new System.Drawing.Size(317, 40);
			this.textBox_arguments.TabIndex = 26;
			// 
			// button_save
			// 
			this.button_save.Location = new System.Drawing.Point(405, 354);
			this.button_save.Name = "button_save";
			this.button_save.Size = new System.Drawing.Size(75, 23);
			this.button_save.TabIndex = 17;
			this.button_save.Text = "Save";
			this.button_save.UseVisualStyleBackColor = true;
			this.button_save.Click += new System.EventHandler(this.button_save_Click);
			// 
			// button_cancel
			// 
			this.button_cancel.Location = new System.Drawing.Point(486, 354);
			this.button_cancel.Name = "button_cancel";
			this.button_cancel.Size = new System.Drawing.Size(75, 23);
			this.button_cancel.TabIndex = 16;
			this.button_cancel.Text = "Cancel";
			this.button_cancel.UseVisualStyleBackColor = true;
			// 
			// checkBox_vac
			// 
			this.checkBox_vac.AutoSize = true;
			this.checkBox_vac.Location = new System.Drawing.Point(21, 20);
			this.checkBox_vac.Name = "checkBox_vac";
			this.checkBox_vac.Size = new System.Drawing.Size(83, 17);
			this.checkBox_vac.TabIndex = 18;
			this.checkBox_vac.Text = "Enable VAC";
			this.checkBox_vac.UseVisualStyleBackColor = true;
			// 
			// groupBox_vac
			// 
			this.groupBox_vac.Anchor = System.Windows.Forms.AnchorStyles.Top;
			this.groupBox_vac.Controls.Add(this.checkBox_vac);
			this.groupBox_vac.Location = new System.Drawing.Point(43, 64);
			this.groupBox_vac.Name = "groupBox_vac";
			this.groupBox_vac.Size = new System.Drawing.Size(163, 48);
			this.groupBox_vac.TabIndex = 13;
			this.groupBox_vac.TabStop = false;
			this.groupBox_vac.Text = "Game Mode";
			// 
			// Server
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(612, 414);
			this.Controls.Add(this.tabs);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(628, 283);
			this.Name = "Server";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "CS:GO Server";
			this.panel_start.ResumeLayout(false);
			this.panel_start.PerformLayout();
			this.tabs.ResumeLayout(false);
			this.tab_console.ResumeLayout(false);
			this.tab_console.PerformLayout();
			this.tab_settings.ResumeLayout(false);
			this.groupBox_gameMode.ResumeLayout(false);
			this.groupBox_map.ResumeLayout(false);
			this.groupBox_map.PerformLayout();
			this.groupBox_authKeys.ResumeLayout(false);
			this.groupBox_authKeys.PerformLayout();
			this.groupBox_serverSettings.ResumeLayout(false);
			this.groupBox_serverSettings.PerformLayout();
			this.groupBox_vac.ResumeLayout(false);
			this.groupBox_vac.PerformLayout();
			this.ResumeLayout(false);

		}

		#endregion
		private System.Windows.Forms.Button button_start;
		private System.Windows.Forms.ListBox listBox_console;
		private System.Windows.Forms.TextBox textBox_command;
		private System.Windows.Forms.Button button_execute;
		private System.Windows.Forms.Panel panel_start;
		private System.Windows.Forms.TabControl tabs;
		private System.Windows.Forms.TabPage tab_console;
		private System.Windows.Forms.TabPage tab_settings;
		private System.Windows.Forms.Label label_ram;
		private System.Windows.Forms.Label label_cpu;
		private System.Windows.Forms.ProgressBar progressBar_ram;
		private System.Windows.Forms.ProgressBar progressBar_cpu;
		private System.Windows.Forms.GroupBox groupBox_gameMode;
		private System.Windows.Forms.ComboBox comboBox_gameModes;
		private System.Windows.Forms.GroupBox groupBox_map;
		private System.Windows.Forms.RadioButton radio_clientMap;
		private System.Windows.Forms.ComboBox comboBox_clientMaps;
		private System.Windows.Forms.RadioButton radio_oldMapWorkshop;
		private System.Windows.Forms.ComboBox comboBox_oldMapWorkshops;
		private System.Windows.Forms.RadioButton radio_workshopMap;
		private System.Windows.Forms.TextBox textBox_workshopMap;
		private System.Windows.Forms.GroupBox groupBox_serverSettings;
		private System.Windows.Forms.GroupBox groupBox_authKeys;
		private System.Windows.Forms.TextBox textBox_apiKey;
		private System.Windows.Forms.TextBox textBox_gslt;
		private System.Windows.Forms.Label label_rcon;
		private System.Windows.Forms.TextBox textBox_rcon;
		private System.Windows.Forms.Label label_password;
		private System.Windows.Forms.TextBox textBox_password;
		private System.Windows.Forms.TextBox textBox_arguments;
		private System.Windows.Forms.Label label_arguments;
		private System.Windows.Forms.Button button_rcon;
		private System.Windows.Forms.Button button_password;
		private System.Windows.Forms.LinkLabel link_apiKey;
		private System.Windows.Forms.LinkLabel link_gslt;
		private System.Windows.Forms.LinkLabel link_helpWorkshop;
		private System.Windows.Forms.Button button_save;
		private System.Windows.Forms.Button button_cancel;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.GroupBox groupBox_vac;
		private System.Windows.Forms.CheckBox checkBox_vac;
	}
}