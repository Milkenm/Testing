﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;
using System.Windows.Forms;

using CSCore;
using CSCore.Maps;
using CSCore.Modes;

using CSUi.Properties;

using static CSCore.Modes.Modes;

namespace CSUi
{
	public partial class Server : Form
	{
		private static int mainThreadId;

		public Server()
		{
			this.InitializeComponent();
			this.DataBind();
			this.LoadSettings();

			mainThreadId = Thread.CurrentThread.ManagedThreadId;
		}

		private Process serverProcess = null;

		public static bool IsMainThread => Thread.CurrentThread.ManagedThreadId == mainThreadId;

		private class GameMode
		{
			public GameMode(Mode mode)
			{
				this.Name = mode.Name;
				this.Mode = mode;
			}

			public string Name { get; }
			public Mode Mode { get; }
		}

		private class MapClient
		{
			public MapClient(Map map)
			{
				this.Name = map.Name;
				this.Map = map;
			}

			public string Name { get; }
			public Map Map { get; }
		}


		public static readonly List<Mode> ModesList = new List<Mode>()
		{
			Casual, Competitive, Wingman, WeaponsExpert,
			ArmsRace, Demolition, Deathmatch,
			Training,
			Custom,
			Guardian, CoopStrike,
			WarGames, FlyingScoutsman, Retakes, StabStabZap, FreeForAll, TriggerDiscipline, BoomHeadshot, HunterGatherers, HeavyAssaultSuit,
			DangerZone,
			MapVoting, Scrimmage
		};


		private void DataBind()
		{
			List<GameMode> gameModes = new List<GameMode>();
			foreach (Mode mode in ModesList)
			{
				gameModes.Add(new GameMode(mode));
			}
			this.Bind(comboBox_gameModes, gameModes, "Name", "Mode");

			List<MapClient> clientMaps = new List<MapClient>();
			List<MapClient> workshopMaps = new List<MapClient>();
			foreach (Map map in Maps.MapsList)
			{
				MapClient mapClient = new MapClient(map);
				if (map is ClientMap)
				{
					clientMaps.Add(mapClient);
				}
				else if (map is WorkshopMap)
				{
					workshopMaps.Add(mapClient);
				}
			}
			this.Bind(comboBox_clientMaps, clientMaps, "Name", "Map");
			this.Bind(comboBox_oldMapWorkshops, workshopMaps, "Name", "Map");
		}

		private void Bind(ComboBox cb, object dataSource, string displayMember, string valueMember)
		{
			cb.DataSource = new BindingSource
			{
				DataSource = dataSource,
			};
			cb.DisplayMember = displayMember;
			cb.ValueMember = valueMember;
		}

		private void LoadSettings()
		{
			textBox_gslt.Text = Settings.Default.GSLT;
			textBox_apiKey.Text = Settings.Default.APIKey;
			textBox_password.Text = Settings.Default.ServerPassword;
			textBox_rcon.Text = Settings.Default.RconPassword;
			textBox1.Text = Settings.Default.ServerPath;
		}

		private void textBox_workshopMap_TextChanged(object sender, EventArgs e)
		{
			StringBuilder sb = new StringBuilder();

			List<char> nums = new List<char>() { '1', '2', '3', '4', '5', '6', '7', '8', '9', '0' };
			foreach (char c in textBox_workshopMap.Text)
			{
				if (nums.Contains(c))
				{
					sb.Append(c);
				}
			}

			textBox_workshopMap.Text = sb.ToString();

			textBox_workshopMap.SelectionStart = textBox_workshopMap.Text.Length;
			textBox_workshopMap.SelectionLength = 0;
		}

		private void link_helpWorkshop_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Utils.OpenLink("https://developer.valvesoftware.com/wiki/CS:GO_Workshop_For_Server_Operators");
		}

		private void link_gslt_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Utils.OpenLink("https://steamcommunity.com/dev/managegameservers");
		}

		private void link_apiKey_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
		{
			Utils.OpenLink("https://steamcommunity.com/dev/apikey");
		}

		private void button_password_Click(object sender, EventArgs e)
		{
			Utils.TogglePassword(textBox_password, button_password);
		}

		private void button_rcon_Click(object sender, EventArgs e)
		{
			Utils.TogglePassword(textBox_rcon, button_rcon);
		}

		private void button_start_Click(object sender, EventArgs e)
		{
			// TOGGLE BUTTON TEXT \\
			button_start.Text = button_start.Text == "Start" ? "Stop" : "Start";
			if (serverProcess == null)
			{
				// START SERVER \\
				this.StartServer();
			}
			else
			{
				// STOP SERVER \\
				this.StopServer();
			}
		}

		private void StartServer()
		{
			// GET SERVER PATH \\
			string serverPath = textBox1.Text;
			if (string.IsNullOrEmpty(serverPath))
			{
				MessageBox.Show("Please set a server path.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return;
			}
			// START SERVER PROCESS \\
			serverProcess = new Process()
			{
				StartInfo = new ProcessStartInfo()
				{
					WindowStyle = ProcessWindowStyle.Hidden,
					FileName = serverPath,
					Arguments = this.GetStartArguments(),
					UseShellExecute = false,
					//RedirectStandardInput = true,
					RedirectStandardOutput = true,
					RedirectStandardError = true,
					CreateNoWindow = true,
				},
			};
			serverProcess.OutputDataReceived += new DataReceivedEventHandler(this.OutputHandler);
			serverProcess.ErrorDataReceived += new DataReceivedEventHandler(this.OutputHandler);
			serverProcess.Exited += this.ServerProcess_Exited;
			serverProcess.Start();
			serverProcess.BeginOutputReadLine();
			//serverProcess.BeginErrorReadLine();
			// TOGGLE BUTTON TEXT \\
			button_start.Text = "Stop";
			// HIDE SERVER WINDOW \\
			Thread.Sleep(5000);
			this.HideServerWindow();
		}


		[DllImport("user32.dll")]
		private static extern bool ShowWindow(IntPtr hWnd, int nCmdShow);

		private const int SW_HIDE = 0;
		private const int SW_SHOW = 5;

		private void HideServerWindow()
		{
			// CHECK IF SERVER IS RUNNING \\
			if (serverProcess == null || serverProcess.HasExited)
			{
				return;
			}

			// HIDE WINDOW \\
			ShowWindow(serverProcess.MainWindowHandle, SW_HIDE);
		}

		private void ShowServerWindow()
		{
			// CHECK IF SERVER IS RUNNING \\
			if (serverProcess == null || serverProcess.HasExited)
			{
				return;
			}

			// SHOW WINDOW \\
			ShowWindow(serverProcess.MainWindowHandle, SW_SHOW);
		}

		private void ServerProcess_Exited(object sender, EventArgs e)
		{
			this.StopServer();
		}

		private void StopServer()
		{
			if (serverProcess != null)
			{
				if (!serverProcess.HasExited)
				{
					serverProcess.Kill();
				}
				serverProcess.Dispose();
				serverProcess = null;
			}
			// TOGGLE BUTTON TEXT \\
			button_start.Text = "Start";
		}

		private void OutputHandler(object sender, DataReceivedEventArgs e)
		{
			if (e.Data != null)
			{
				if (IsMainThread)
				{
					this.Log(e.Data);
				}
				else
				{
					this.Invoke(new Action(() =>
					{
						this.Log(e.Data);
					}));
				}
			}
		}

		private void Log(string text)
		{
			listBox_console.Items.Add(text);
			listBox_console.SelectedIndex = listBox_console.Items.Count - 1;
		}

		private string GetStartArguments()
		{
			// GET SELECTED GAME MODE \\
			Mode mode = (Mode)comboBox_gameModes.SelectedValue;
			if (mode == null)
			{
				MessageBox.Show("Please select a valid game mode.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
				return null;
			}
			// FORMAT START ARGUMENTS \\
			StringBuilder sb = new StringBuilder($"-game csgo -console -usercon -port 27015 -ip 127.0.0.1 -maxplayers_override 10 +sv_setsteamaccount {Settings.Default.GSLT} -tickrate 128 -net_port_try 1");
			if (!checkBox_vac.Checked)
			{
				sb.Append(" -insecure");
			}
			if (!string.IsNullOrEmpty(Settings.Default.RconPassword))
			{
				sb.Append($" -rcon_password {Settings.Default.RconPassword}");
			}
			if (!string.IsNullOrEmpty(Settings.Default.ServerPassword))
			{
				sb.Append($" -password {Settings.Default.ServerPassword}");
			}
			// MAP ARGUMENT \\
			Map map = this.GetSelectedMap();
			if (radio_clientMap.Checked)
			{
				sb.Append($" +map {((ClientMap)map).BspName}");
			}
			else if (radio_oldMapWorkshop.Checked)
			{
				sb.Append($" +host_workshop_map {((WorkshopMap)map).FileId}").Append($" -authkey {Settings.Default.APIKey}");
			}
			else if (radio_workshopMap.Checked)
			{
				sb.Append($" +host_workshop_map {textBox_workshopMap.Text}");
			}
			// GAME TYPE/MODE ARGUMENT \\
			sb.Append($" +game_type {(int)mode.GameType} +game_mode {(int)mode.GameMode}");
			// RETURN START ARGUMENTS \\
			return sb.ToString();
		}

		private void button_save_Click(object sender, EventArgs e)
		{
			// SAVE SETTINGS \\
			Settings.Default.GSLT = textBox_gslt.Text;
			Settings.Default.APIKey = textBox_apiKey.Text;
			Settings.Default.ServerPassword = textBox_password.Text;
			Settings.Default.RconPassword = textBox_rcon.Text;
			Settings.Default.ServerPath = textBox1.Text;
			Settings.Default.Save();
			// SHOW SUCCESS MESSAGE AND CLOSE FORM \\
			MessageBox.Show("Settings saved.");
			tabs.SelectedIndex = 0;
		}

		private void RefreshGameModes(object sender, EventArgs e)
		{

			Map map = this.GetSelectedMap();
			if (map.GameModes != null)
			{
				List<GameMode> gms = new List<GameMode>();
				foreach (Mode mode in map.GameModes)
				{
					GameMode gm = new GameMode(mode);
					if (!gms.Contains(gm))
					{
						gms.Add(new GameMode(mode));
					}
				}
				this.Bind(comboBox_gameModes, gms, "Name", "Mode");
			}
			else
			{
				this.Bind(comboBox_gameModes, ModesList, "Name", "Mode");
			}

		}

		private Map GetSelectedMap()
		{
			if (radio_clientMap.Checked)
			{
				return (ClientMap)((MapClient)comboBox_clientMaps.SelectedItem).Map;
			}
			else if (radio_oldMapWorkshop.Checked)
			{
				return (WorkshopMap)((MapClient)comboBox_oldMapWorkshops.SelectedItem).Map;
			}
			else if (radio_workshopMap.Checked)
			{
				long fileId = 0;
				if (!string.IsNullOrEmpty(textBox_workshopMap.Text))
				{
					Convert.ToInt64(textBox_workshopMap.Text);
				}
				return new WorkshopMap("Custom Workshop Map", fileId, null);
			}
			return null;
		}

		private void button_execute_Click(object sender, EventArgs e)
		{
			serverProcess.StandardInput.WriteLine(textBox_command.Text);
			serverProcess.StandardInput.Flush();
			textBox_command.Text = string.Empty;
		}
	}
}
