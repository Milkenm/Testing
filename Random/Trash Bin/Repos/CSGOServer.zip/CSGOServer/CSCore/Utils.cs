﻿using System.Diagnostics;
using System.Windows.Forms;

using CSCore.Enum;
using CSCore.Modes;

using static CSCore.Modes.Modes;

namespace CSCore
{
	public static class Utils
	{
		public static void OpenLink(string link)
		{
			Process.Start(link);
		}

		public static void TogglePassword(TextBox tb, Button b)
		{
			// PASSWORD IS HIDDEN \\
			if (tb.PasswordChar == '●')
			{
				tb.PasswordChar = '\0';
				b.Text = "●";
			}
			// PASSWORD VISIBLE \\
			else if (tb.PasswordChar == '\0')
			{
				tb.PasswordChar = '●';
				b.Text = "👁️";
			}
		}
	}
}
