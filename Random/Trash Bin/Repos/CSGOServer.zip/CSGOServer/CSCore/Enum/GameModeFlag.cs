﻿namespace CSCore.Enum
{
	public enum GameModeFlag
	{
		Default = 0,
		TeamVsTeam = 4,
		ShortMath_FreeForAll = 32,
	}
}
