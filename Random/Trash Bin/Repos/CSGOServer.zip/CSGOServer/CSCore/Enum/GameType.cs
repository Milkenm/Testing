﻿namespace CSCore.Enum
{
	public enum GameType
	{
		Classic = 0,
		GunGame = 1,
		Training = 2,
		Custom = 3,
		Cooperative = 4,
		Skirmish = 5,
		FreeForAll = 6,
	}
}
