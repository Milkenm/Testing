﻿namespace CSCore.Enum
{
	public enum SkirmishId
	{
		Default = 0,
		StabStabZap = 1,        // INTENDED FOR: CASUAL
		FreeForAll = 2,         // INTENDED FOR: DEATHMATCH
		FlyingScoutsman = 3,    // INTENDED FOR: CASUAL
		TriggerDiscipline = 4,  // INTENDED FOR: CASUAL
		BoomHeadshot = 6,       // INTENDED FOR: DEATHMATCH
		HunterGatherers = 7,    // INTENDED FOR: DEATHMATCH
		HeavyAssaultSuit = 8,   // INTENDED FOR: CASUAL
		ArmsRace = 10,          // INTENDED FOR: ARMS RACE
		Demolition = 11,        // INTENDED FOR: DEMOLITION
		Retakes = 12,           // INTENDED FOR: RETAKES
	}
}
