﻿namespace CSCore.Enum
{
	public enum GameMode
	{
		Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone = 1,
		Competitive_Demolition_CoopStrike = 2,
		Wingman_Deathmatch = 3,
		WeaponsExpert = 4,
	}
}
