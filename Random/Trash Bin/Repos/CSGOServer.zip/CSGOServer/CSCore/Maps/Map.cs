﻿using System.Collections.Generic;

using CSCore.Modes;

namespace CSCore.Maps
{
	public class Map
	{
		public Map(string name, List<Mode> mapTypes)
		{
			this.Name = name;
			this.GameModes = mapTypes;
		}

		public string Name { get; }
		public List<Mode> GameModes { get; }
	}

	public class ClientMap : Map
	{
		public ClientMap(string name, string bspName, List<Mode> mapTypes) : base(name, mapTypes)
		{
			this.BspName = bspName;
		}

		public string BspName { get; }
	}

	public class WorkshopMap : Map
	{
		public WorkshopMap(string name, long fileId, List<Mode> mapTypes) : base(name, mapTypes)
		{
			this.FileId = fileId;
		}

		public long FileId { get; }
	}
}
