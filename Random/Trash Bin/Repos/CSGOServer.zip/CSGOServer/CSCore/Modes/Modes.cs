﻿
using System.Collections.Generic;

using CSCore.Enum;

namespace CSCore.Modes
{
	public static class Modes
	{
		// CLASSIC \\
		public static readonly Mode Casual = new Mode("Casual", GameType.Classic, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone);
		public static readonly Mode Competitive = new Mode("Competitive", GameType.Classic, GameMode.Competitive_Demolition_CoopStrike);
		public static readonly Mode Wingman = new Mode("Wingman", GameType.Classic, GameMode.Wingman_Deathmatch);
		public static readonly Mode WeaponsExpert = new Mode("Weapons Expert", GameType.Classic, GameMode.WeaponsExpert);

		// GUN GAME \\
		public static readonly Mode ArmsRace = new Mode("Arms Race", GameType.GunGame, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone);
		public static readonly Mode Demolition = new Mode("Demolition", GameType.GunGame, GameMode.Competitive_Demolition_CoopStrike);
		public static readonly Mode Deathmatch = new Mode("Deathmatch", GameType.GunGame, GameMode.Wingman_Deathmatch);

		// TRAINING \\
		public static readonly Mode Training = new Mode("Training", GameType.Training, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone);

		// CUSTOM \\
		public static readonly Mode Custom = new Mode("Custom", GameType.Custom, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone);

		// COOPERATIVE \\
		public static readonly Mode Guardian = new Mode("Guardian", GameType.Cooperative, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone);
		public static readonly Mode CoopStrike = new Mode("Co-op Strike", GameType.Cooperative, GameMode.Competitive_Demolition_CoopStrike);

		// SKIRMISH \\
		public static readonly Mode WarGames = new Mode("War Games", GameType.Skirmish, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone);
		public static readonly Mode FlyingScoutsman = new Mode("Flying Scoutsman", GameType.Classic, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone, GameModeFlag.Default, SkirmishId.FlyingScoutsman);
		public static readonly Mode Retakes = new Mode("Retakes", GameType.Classic, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone, GameModeFlag.Default, SkirmishId.Retakes);
		public static readonly Mode StabStabZap = new Mode("Stab Stab Zap", GameType.Classic, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone, GameModeFlag.Default, SkirmishId.StabStabZap);
		public static readonly Mode FreeForAll = new Mode("Free For All", GameType.GunGame, GameMode.Wingman_Deathmatch, GameModeFlag.Default, SkirmishId.FreeForAll);
		public static readonly Mode TriggerDiscipline = new Mode("Trigger Discipline", GameType.Classic, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone, GameModeFlag.Default, SkirmishId.TriggerDiscipline);
		public static readonly Mode BoomHeadshot = new Mode("Boom! Headshot!", GameType.GunGame, GameMode.Wingman_Deathmatch, GameModeFlag.Default, SkirmishId.BoomHeadshot);
		public static readonly Mode HunterGatherers = new Mode("Hunter-Gatherers", GameType.GunGame, GameMode.Wingman_Deathmatch, GameModeFlag.Default, SkirmishId.HunterGatherers);
		public static readonly Mode HeavyAssaultSuit = new Mode("Heavy Assault Suit", GameType.Classic, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone, GameModeFlag.Default, SkirmishId.HeavyAssaultSuit);

		// FREE FOR ALL \\
		public static readonly Mode DangerZone = new Mode("Danger Zone", GameType.FreeForAll, GameMode.Casual_ArmsRace_Training_Custom_Guardian_WarGames_DangerZone);

		// RANDOM \\ // TODO: Set actual modes
		public static readonly Mode MapVoting = new Mode("Map Voting", GameType.FreeForAll, GameMode.WeaponsExpert);
		public static readonly Mode Scrimmage = new Mode("Scrimmage", GameType.GunGame, GameMode.WeaponsExpert);
	}
}
