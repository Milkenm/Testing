﻿using CSCore.Enum;

namespace CSCore.Modes
{
	public class Mode
	{
		public Mode(string name, GameType gameType, GameMode gameMode, GameModeFlag gameModeFlag, SkirmishId skirmishId)
		{
			this.Name = name;
			this.GameType = gameType;
			this.GameMode = gameMode;
			this.GameModeFlag = gameModeFlag;
			this.SkirmishId = skirmishId;
		}

		public Mode(string name, GameType gameType, GameMode gameMode, GameModeFlag gameModeFlag) : this(name, gameType, gameMode, gameModeFlag, SkirmishId.Default) { }

		public Mode(string name, GameType gameType, GameMode gameMode) : this(name, gameType, gameMode, GameModeFlag.Default, SkirmishId.Default) { }

		public string Name { get; }
		public GameType GameType { get; }
		public GameMode GameMode { get; }
		public GameModeFlag GameModeFlag { get; }
		public SkirmishId SkirmishId { get; }
	}
}
