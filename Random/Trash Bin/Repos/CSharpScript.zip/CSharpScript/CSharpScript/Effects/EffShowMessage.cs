﻿using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CSharpScript.Effects
{
	public class EffShowMessage : Effect
	{
		public EffShowMessage()
		{
			Pattern = "^show message \"(?<message>[^\"]+)\"$";
		}

		public override void Run(GroupCollection values)
		{
			MessageBox.Show(values["message"].Value);
		}
	}
}
