﻿using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CSharpScript.Effects
{
	public class EffShowMessageWithTitle : Effect
	{
		public EffShowMessageWithTitle()
		{
			Pattern = "^show message \"(?<message>[^\"]+)\" with title \"(?<title>[^\"]+)\"$";
		}

		public override void Run(GroupCollection values)
		{
			MessageBox.Show(values["message"].Value, values["title"].Value);
		}
	}
}
