﻿using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CSharpScript.Effects
{
	public class EffDeleteVariable : Effect
	{
		public EffDeleteVariable()
		{
			Pattern = "^delete variable {(?<variable>[^{} ]+)}$";
		}

		public override void Run(GroupCollection values)
		{
			MessageBox.Show("DeleteVariable");
		}
	}
}
