﻿using System.Diagnostics;
using System.Text.RegularExpressions;

namespace CSharpScript.Effects
{
	public class EffTurnOffMyPc : Effect
	{
		public EffTurnOffMyPc()
		{
			Pattern = "^turn off my pc$";
		}

		public override void Run(GroupCollection values)
		{
			Process p = new Process();
			p.StartInfo = new ProcessStartInfo()
			{
				FileName = "cmd.exe",
				Arguments = "/C shutdown -s -t 0",
				UseShellExecute = false,
				CreateNoWindow = true,
			};
			p.Start();
		}
	}
}
