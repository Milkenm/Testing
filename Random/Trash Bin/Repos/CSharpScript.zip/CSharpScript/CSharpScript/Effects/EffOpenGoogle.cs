﻿using System.Diagnostics;
using System.Text.RegularExpressions;

namespace CSharpScript.Effects
{
	public class EffOpenGoogle : Effect
	{
		public EffOpenGoogle()
		{
			Pattern = "^open google$";
		}

		public override void Run(GroupCollection values)
		{
			Process.Start("https://www.google.com");
		}
	}
}
