﻿using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CSharpScript.Effects
{
	public class EffSetVariable : Effect
	{
		public EffSetVariable()
		{
			Pattern = "^set variable {(?<variable>[^{} ]+)} to \"(?<value>.[^\"]+)\"$";
		}

		public override void Run(GroupCollection values)
		{
			MessageBox.Show("SetVariable");
		}
	}
}
