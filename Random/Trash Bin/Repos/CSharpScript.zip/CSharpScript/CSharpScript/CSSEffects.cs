﻿using CSharpScript.Effects;

using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace CSharpScript
{
	public class CSSEffects
	{
		public void Initialize()
		{
			LoadEffect(new EffOpenGoogle());
			LoadEffect(new EffSetVariable());
			LoadEffect(new EffDeleteVariable());
			LoadEffect(new EffShowMessage());
			LoadEffect(new EffShowMessageWithTitle());
			LoadEffect(new EffTurnOffMyPc());
		}

		public void LoadEffect(Effect effect)
		{
			ExpressionsList.Add(new Expression(effect));
		}

		public void Parse(string expression, bool run)
		{
			foreach (Expression ex in ExpressionsList)
			{
				ex.Check(expression, run);
			}
		}

		private List<Expression> ExpressionsList = new List<Expression>();

		private Dictionary<string, object> Variables = new Dictionary<string, object>();

		private class Expression
		{
			public Expression(Effect effect)
			{
				Effect = effect;
			}

			private Effect Effect;

			public Match Check(string expression, bool run = true)
			{
				Regex r = new Regex(Effect.Pattern);
				Match m = r.Match(expression);

				if (m.Success && run)
				{
					Effect.Run(m.Groups);
				}

				return m;
			}
		}
	}
}
