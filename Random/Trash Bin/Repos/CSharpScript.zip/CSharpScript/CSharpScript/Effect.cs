﻿using System.Text.RegularExpressions;

namespace CSharpScript
{
	public class Effect
	{
		public string Pattern { get; set; }
		public virtual void Run(GroupCollection values) { }
	}
}
