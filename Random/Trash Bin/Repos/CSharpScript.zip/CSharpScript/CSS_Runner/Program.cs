﻿using CSharpScript;

using System;
using System.IO;
using System.Runtime.InteropServices;

namespace CSS_Runner
{
	internal class Program
	{
		private static CSSEffects effects = new CSSEffects();

		private static void Main(string[] args)
		{
			effects.Initialize();

			if (args.Length > 0)
			{
				if (File.Exists(args[0]))
				{
					string[] lines = File.ReadAllLines(args[0]);
					foreach (string line in lines)
					{
						Console.WriteLine(line);
						effects.Parse(line, true);
					}
				}
			}

			Console.ReadLine();
		}
	}
}
