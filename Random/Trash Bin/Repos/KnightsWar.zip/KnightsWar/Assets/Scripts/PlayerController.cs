﻿using UnityEngine;

public class PlayerController : MonoBehaviour
{
	public float _MovementSpeed;
	public GameObject _WeaponObject;
	public Sprite _WeaponSpriteRight; // Sprite da arma virada para a direita
	public Sprite _WeaponSpriteLeft; // Sprite da arma virada para a esquerda

	private Animator _PlayerAnimator;
	private SpriteRenderer _PlayerSpriteRenderer;
	private Rigidbody2D _Rigidbody2d;
	private Vector2 _Movement;
	private SpriteRenderer _WeaponSpriteRenderer;

	public enum Direction
	{
		Right,
		Left,
	}





	private void Start()
	{
		_PlayerAnimator = GetComponent<Animator>();
		_PlayerSpriteRenderer = GetComponent<SpriteRenderer>();
		_Rigidbody2d = GetComponent<Rigidbody2D>();
		_WeaponSpriteRenderer = _WeaponObject.GetComponent<SpriteRenderer>();
		_WeaponSpriteRenderer.sprite = _WeaponSpriteRight;
	}

	private void Update()
	{
		// UPDATE PLAYER
		_Movement.x = Input.GetAxisRaw("Horizontal");
		_Movement.y = Input.GetAxisRaw("Vertical");

		// UPDATE WEAPON
		Vector2 _PointAt = Camera.main.ScreenToWorldPoint(Input.mousePosition);

		float _AngleRad = Mathf.Atan2(_PointAt.y - _WeaponObject.transform.position.y, _PointAt.x - _WeaponObject.transform.position.x);
		float _AngleDeg = 180 / Mathf.PI * _AngleRad;

		_WeaponObject.transform.rotation = Quaternion.Euler(0, 0, _AngleDeg);

		// THE PLAYER IS LOOKING LEFT
		if ((_AngleDeg > 90 || _AngleDeg < -90))
		{
			Flip(Direction.Left);
		}
		// THE PLAYER IS LOOKING RIGHT
		else
		{
			Flip(Direction.Right);
		}
	}

	private void FixedUpdate()
	{
		// PLAYER MOVEMENT
		if (_Movement != new Vector2(0, 0))
		{
			StartCoroutine(ExampleCoroutine());
			_Rigidbody2d.MovePosition(_Rigidbody2d.position + _Movement * _MovementSpeed * Time.fixedDeltaTime);
			_PlayerAnimator.SetBool("Moving", true);
		}
		else
		{
			_PlayerAnimator.SetBool("Moving", false);
		}
	}

	IEnumerator ExampleCoroutine()
	{
		yield return new WaitForSeconds(5);
	}

	// MAKES THE PLAYER AND WEAPON FACE THE CORRECT POSITION
	private void Flip(Direction _Direction)
	{
		// LOOKING LEFT
		if (_Direction == Direction.Left)
		{
			_PlayerSpriteRenderer.flipX = true;
			_WeaponSpriteRenderer.sprite = _WeaponSpriteLeft;
			_WeaponObject.transform.localPosition = new Vector2(0.07f, -0.13f);
		}
		// LOOKING RIGHT
		else
		{
			_PlayerSpriteRenderer.flipX = false;
			_WeaponSpriteRenderer.sprite = _WeaponSpriteRight;
			_WeaponObject.transform.localPosition = new Vector2(-0.07f, -0.13f);
		}
	}
}