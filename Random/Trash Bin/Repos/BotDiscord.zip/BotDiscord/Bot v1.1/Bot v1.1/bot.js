var Discord = require('discord.io');
var logger = require('winston');
var auth = require('./auth.json');

logger.remove(logger.transports.Console);
logger.add(new logger.transports.Console, {
    colorize: true
});

logger.level = 'debug';

var bot = new Discord.Client({
   token: auth.token,
   autorun: true
});
bot.on('ready', function (evt) {
    logger.info('Connected');
    logger.info('Logged in as: ');
    logger.info(bot.username + ' - (' + bot.id + ')');
});
bot.on('message', function (user, userID, channelID, message, evt) {

  
var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
const stream = new XMLHttpRequest();

const url='https://api.twitch.tv/helix/streams/';
stream.open("GET", url);
stream.setRequestHeader("Client-ID", "dtudeklwpfe6yihlbll9nn8do3gb1j");
stream.setRequestHeader("Authorization","Bearer 1505my5q7v54v1qfqvfcucdawyinpw");
stream.send();
stream.onreadystatechange = (e) => {
console.log(stream.responseText + "here")
}
 
    if (message.substring(0, 1) == '?') {
        var args = message.substring(1).split(' ');
        var cmd = args[0];
       
        args = args.splice(1);
        switch(cmd) {
           /* case 'ping':
                bot.sendMessage({
                    to: channelID,
                    message: 'Pong!'
                });*/
            
            case 'moes':
                bot.sendMessage({
                    to: channelID,
                    message: 'toes!',
                });
                console.log("no error UwU")

            case 'respond':
                bot.sendMessage({
                    to: channelID,
                    message: '@Kredik#2521 respond you coward!'
                });
                    
            case 'stream':
                bot.sendMessage({
                    to: channelID,
                    message: stream.responseText
                });

            /*case 'client':
                bot.sendMessage({
                    to: channelID,
                    message: clientId.responseText
                });*/
            break;
         }
     }
});
