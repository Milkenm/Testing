var logger = require('winston');
var auth = require('./auth.json');
var Discord = require('discord.js');

var bot = new Discord.Client();
<<<<<<< HEAD

=======
const resources = require('./requests');
>>>>>>> cd3832bf6d52087a2de871da6273a3eecae25d4a

logger.remove(logger.transports.Console);
logger.add(new logger.transports.Console, {
    colorize: true
});

logger.level = 'debug';

var bot = new Discord.Client({
    token: auth.token,
    autorun: true
});
bot.on('ready', function (evt, channelID) {
    logger.info("Jak bot is running, catch him!");
});


bot.on('message', message => {
    var prefix = '.'
    var msg = message.content;
<<<<<<< HEAD
    if(message.author.bot){
        return;
    }
    //MESSAGE SENDER ID-------------------------------------------------------------------------------------
    /*if(message.author.id==531192916459388940){
        message.channel.send("archie says shut up kaja");
    }
    if(message.author.id==174195412360626176){
        message.channel.send('Archie says:', {
            files: ["./images/stfu.jpg"]
        });
    }*/
    //MESSAGE SENT CONTENT----------------------------------------------------------------------------------
    if(message.content.toLowerCase()=="weezer"){
        message.channel.send("Kaja says: 'Hearing someone saying weezer makes me cum'");
    }
    //MESSAGE SENDING---------------------------------------------------------------------------------------
    if (msg === prefix + 'bald') {
        message.channel.send('He bald', {
            files: ["./images/kek.jpg"]
        });
    }
    else if (msg === prefix + 'moes') {
        message.channel.send("TOES!");
    }
    else if (msg === prefix + 'respond') {
        message.channel.send("<@" + 490333284920983573 + ">"+"RESPOND YOU COWARD!");
    }
    else if (msg === prefix + 'js') {
        message.channel.send("JavaScript go brrrrrrr");
    }
    else if (msg === prefix + 'spoons') {
        message.channel.send("Remember kids, metal spoons don't go in the trash");
    }
    else if (msg === prefix + 'bonk') {
        message.channel.send('', {
            files: ["./videos/bonk.webm"]
        });
    }    
    else if (msg === prefix + 'winning') {
        message.channel.send('', {
            files: ["./videos/winning.webm"]
        });
    }
    else if (msg === prefix + 'wide') {
        message.channel.send('WIDE MOE WIDE MOE', {
            files: ["./images/widemoe.jpg"]
        });
    }
    else if (msg.startsWith( prefix + 'opgg')) {
        var username = message.content.replace(".opgg ","");
        message.channel.send("https://euw.op.gg/summoner/userName=" + username);
    }

});
bot.login('NzMzMzk1NDg3NDk0NzY2NzEy.XxhcBA.6jOEg2-99etO-NpomnYgDz5hI2A');
    

=======
    if (message.author.bot) {
        return;
    }

    if (msg === prefix + 'bald') {
        message.channel.send('He bald', {
            files: ["kek.jpg"]
        });
    } else if (msg === prefix + 'moes') {
        message.channel.send("TOES!");
    } else if (msg === prefix + 'respond') {
        message.channel.send("<@" + 490333284920983573 + ">" + "RESPOND YOU COWARD!");
    } else if (msg === prefix + 'js') {
        message.channel.send("JavaScript go brrrrrrr");
    } else if (msg === prefix + 'spoons') {
        message.channel.send("Remember kids, metal spoons don't go in the trash");
    } else if (msg === prefix + 'bonk') {
        message.channel.send('', {
            files: ["bonk.webm"]
        });
    } else if (msg === prefix + 'wide') {
        message.channel.send('WIDE MOE WIDE MOE', {
            files: ["widemoe.jpg"]
        });
    } else if (msg.startsWith(prefix + 'opgg')) {
        var username = message.content.replace(".opgg ", "");
        message.channel.send("https://euw.op.gg/summoner/userName=" + username);
    } else if (msg.startsWith(prefix) && msg.toLowerCase().includes('corona', 1)) {
        resources.getNoticias().then(response => {
            const noticia = response[Math.floor((Math.random() * Object.keys(response).length) + 0)];
            // message.channel.send("Titulo: " + noticia.tituloNoticia);
            // message.channel.send("Descrição: " + noticia.descricao);
            // message.channel.send("Mais: " + noticia.fullUrl);
            const exampleEmbed = new Discord.MessageEmbed()
                .setColor('#0099ff')
                .setTitle(noticia.tituloNoticia)
                .setURL(noticia.fullUrl)
                .setDescription(noticia.descricao)
                .setImage(noticia.multimediaPrincipal)
                .setTimestamp(noticia.data)
                .setFooter(noticia.rubrica);

            message.channel.send(exampleEmbed);
        });
    } else if (msg.startsWith(prefix) && ((msg.toLowerCase().includes('girl')) || msg.toLowerCase().includes('babe'))) {

        resources.getNsfw(message.channel.nsfw).then(response => {
            const img = response[Math.floor((Math.random() * Object.keys(response).length) + 0)];
            // // message.channel.send("Titulo: " + noticia.tituloNoticia);
            // // message.channel.send("Descrição: " + noticia.descricao);
            // // message.channel.send("Mais: " + noticia.fullUrl);
            const exampleEmbed = new Discord.MessageEmbed()
                .setColor('#FF0000')
                .setTitle(img.title || "")
                .setURL(img.url)
                .setImage(img.image)

            message.channel.send(exampleEmbed);

        });


    }

});
bot.login('NzMzMzk1NDg3NDk0NzY2NzEy.XxhcBA.6jOEg2-99etO-NpomnYgDz5hI2A');
>>>>>>> cd3832bf6d52087a2de871da6273a3eecae25d4a
