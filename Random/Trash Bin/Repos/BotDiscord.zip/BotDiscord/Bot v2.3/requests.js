const fetch = require('node-fetch');
const duck = require('duckduckgo-images-api');

const getNoticias = () => {
    return fetch("https://www.publico.pt/api/list/search?query=coronavirus/ultimas/", {
        method: "GET",
        headers: {}
    }).then(response => {
        if (response.status !== 200 && response.status !== 429) {
            return [];
        }
        return response.json();
    });
}

const getNsfw = (nsfw) => {

    return duck.image_search({
        query: "HOT GIRLS PLAYBOY",
        moderate: !nsfw,
        iterations: 1,
        retries: 3
    }).then(response => {
        return response;
    });
}

const getTempo = async (distrito) => {

    let url = 'http://api.ipma.pt/open-data/distrits-islands.json';
    let response = await fetch(url);
    let distritos = await response.json(); // read response body and parse as JSON
    let encontrouDistrito = false;

    distritos.data.forEach(element => {
        if (element.local.toLowerCase() == distrito) {
            encontrouDistrito = true;
            distrito = element;
        }
    });

    if (!encontrouDistrito) {
        throw new Error("Tens de ir estudar geografia porque o distrito " + distrito + " não foi encontrado...");
    }

    return fetch("http://api.ipma.pt/open-data/forecast/meteorology/cities/daily/" + distrito.globalIdLocal + ".json", {
        method: "GET",
        headers: {}
    }).then(response => {
        if (response.status !== 200 && response.status !== 429) {
            return [];
        }
        return response.json();
    });

}

const getRandomVideoYoutube = async (channel, key) => {
    var fim = false;
    var pageToken = "";
    var res = [];
    while (!fim) {
        let url = `https://www.googleapis.com/youtube/v3/playlistItems?part=snippet%2CcontentDetails&maxResults=50&playlistId=${channel}&key=${key}&pageToken=${pageToken}`;
        let response = await fetch(url);
        let playlist = await response.json(); // read response body and parse as JSON
        if (playlist.error) {
            fim = true;
        } else {
            res = res.concat(playlist.items);
        }
        pageToken = playlist.nextPageToken;
    }

    return res;

    // return fetch(`https://www.googleapis.com/youtube/v3/playlistItems?part=snippet%2CcontentDetails&maxResults=50&playlistId=${channel}&key=${key}`, {
    //     method: "GET",
    //     headers: {}
    // }).then(response => {
    //     if (response.status !== 200 && response.status !== 429) {
    //         return [];
    //     }
    //     return response.json();
    // });
}

module.exports = {
    getNoticias,
    getNsfw,
    getTempo,
    getRandomVideoYoutube
}