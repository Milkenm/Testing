var logger = require('winston');
var auth = require('./auth.json');
var Discord = require('discord.js');

var bot = new Discord.Client();

const resources = require('./requests');
const dateFormat = require('dateformat');
dateFormat.masks.hammerTime = 'Hoje';
dateFormat.i18n = {
    dayNames: [
        'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat',
        'Domingo <:peepo_coolking:715130015108563005>', 'Segunda-Feira <:peepo_omfg:715131508775452762>', 'Terça-Feira <:peepo_revenge:715128191701745674>', 'Quarta-Feira <:peepo_king:641346090905370625>', 'Quinta-Feira <:peepo_shrug:731314904400789514>', 'Sexta-Feira <:peepo_happy:641346090188406784>', 'Sábado <:peepo_amazing:715130311264043091>'
    ],
    monthNames: [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
        'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
    ],
    timeNames: [
        'a', 'p', 'am', 'pm', 'A', 'P', 'AM', 'PM'
    ]
};
const fs = require('fs');

// * const cron = require('node-cron');

logger.remove(logger.transports.Console);
logger.add(new logger.transports.Console, {
    colorize: true
});

logger.level = 'debug';

var bot = new Discord.Client({
    token: auth.token,
    autorun: true
});

bot.on('ready', function (evt, channelID) {
    logger.info("Jak bot is running, catch him!");
});


bot.on('message', message => {
    var prefix = '.'
    var msg = message.content;

    if (message.author.bot) {
        return;
    }

    if (msg === prefix + 'bald') {
        message.channel.send('He bald', {
            files: ["kek.jpg"]
        });
    } else if (msg === prefix + 'moes') {
        message.channel.send("TOES!");
    } else if (msg === prefix + 'respond') {
        message.channel.send("<@" + 490333284920983573 + ">" + "RESPOND YOU COWARD!");
    } else if (msg === prefix + 'js') {
        message.channel.send("JavaScript go brrrrrrr");
    } else if (msg === prefix + 'spoons') {
        message.channel.send("Remember kids, metal spoons don't go in the trash");
    } else if (msg === prefix + 'bonk') {
        message.channel.send('', {
            files: ["bonk.webm"]
        });
    } else if (msg === prefix + 'wide') {
        message.channel.send('WIDE MOE WIDE MOE', {
            files: ["widemoe.jpg"]
        });
    } else if (msg.startsWith(prefix + 'opgg')) {
        var username = message.content.replace(".opgg ", "");
        message.channel.send("https://euw.op.gg/summoner/userName=" + username);
    } else if (msg.startsWith(prefix) && msg.toLowerCase().includes('corona', 1)) {
        resources.getNoticias().then(response => {
            const noticia = response[Math.floor((Math.random() * Object.keys(response).length) + 0)];
            // message.channel.send("Titulo: " + noticia.tituloNoticia);
            // message.channel.send("Descrição: " + noticia.descricao);
            // message.channel.send("Mais: " + noticia.fullUrl);
            const exampleEmbed = new Discord.MessageEmbed()
                .setColor('#0099ff')
                .setTitle(noticia.tituloNoticia)
                .setURL(noticia.fullUrl)
                .setDescription(noticia.descricao)
                .setImage(noticia.multimediaPrincipal)
                .setTimestamp(noticia.data)
                .setFooter(noticia.rubrica);

            message.channel.send(exampleEmbed);
        });
    } else if (msg.startsWith(prefix) && ((msg.toLowerCase().includes('girl')) || msg.toLowerCase().includes('babe'))) {

        resources.getNsfw(message.channel.nsfw).then(response => {
            const img = response[Math.floor((Math.random() * Object.keys(response).length) + 0)];
            // // message.channel.send("Titulo: " + noticia.tituloNoticia);
            // // message.channel.send("Descrição: " + noticia.descricao);
            // // message.channel.send("Mais: " + noticia.fullUrl);
            const exampleEmbed = new Discord.MessageEmbed()
                .setColor('#FF0000')
                .setTitle(img.title || "")
                .setURL(img.url)
                .setImage(img.image)

            message.channel.send(exampleEmbed);

        });


    } else if (msg.toLowerCase().startsWith(prefix + "tempo para")) {
        const distrito = msg.trim().substring((msg.indexOf('para') + 5));

        resources.getTempo(distrito.toLowerCase()).then(response => {

            const embed = {
                "title": `⛅ Meteorologia para ${distrito}`,
                "description": "Próximos 5 dias",
                "color": 13632027,
                "timestamp": new Date(),
                "footer": {
                    "icon_url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png",
                    "text": "© Bald Bot | Criado por Jak 👨‍🦲 | Celo 🐱‍💻 | Ted 🧸"
                },
                "thumbnail": {
                    "url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png"
                },
                "author": {
                    "name": "Bald Bot Discord",
                    "icon_url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png"
                },
                "fields": [{
                        "name": "-------------------------------------------------------------------------------",
                        "value": "-"
                    }, {
                        "name": `📅 ${dateFormat(response.data[0].forecastDate, "dd/mm/yyyy, dddd '(Hoje)'")}`,
                        "value": `🌡️ Max: ${response.data[0].tMax}ºC | Min: ${response.data[0].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "----------------------------------------------------------------------------"
                    },
                    {
                        "name": `📅 ${dateFormat(response.data[1].forecastDate, "dd/mm/yyyy, dddd")}`,
                        "value": `🌡️ Max: ${response.data[1].tMax}ºC | Min: ${response.data[1].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "----------------------------------------------------------------------------"
                    },
                    {
                        "name": `📅 ${dateFormat(response.data[2].forecastDate, "dd/mm/yyyy, dddd")}`,
                        "value": `🌡️ Max: ${response.data[2].tMax}ºC | Min: ${response.data[2].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "----------------------------------------------------------------------------"
                    },
                    {
                        "name": `📅 ${dateFormat(response.data[3].forecastDate, "dd/mm/yyyy, dddd")}`,
                        "value": `🌡️ Max: ${response.data[3].tMax}ºC | Min: ${response.data[3].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "----------------------------------------------------------------------------"
                    },
                    {
                        "name": `📅 ${dateFormat(response.data[4].forecastDate, "dd/mm/yyyy, dddd")}`,
                        "value": `🌡️ Max: ${response.data[4].tMax}ºC | Min: ${response.data[4].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "-"
                    }
                ]
            };
            message.channel.send({
                embed
            });

            // message.channel.send({
            //     embed: exampleEmbed
            // });


        }).catch(err => {

            message.channel.send(message.author.username + ": " + err.message);

        });

    } else if (msg.toLowerCase().startsWith(prefix + "make me happy")) {
        const listsId = ['PL2satA_B-xnSAxmFXHgb1tsaVJ_Pfhrg2', 'PL_90hJucBAcPmFxcbTea81OKGkQevH2F9', 'PLQZgI7en5XEgM0L1_ZcKmEzxW1sCOVZwP'];
        const randList = listsId[Math.floor((Math.random() * listsId.length) + 0)];

        message.channel.send("https://i.pinimg.com/originals/30/72/55/3072558f02be09d1a156ddfb01bd4be4.gif").then(messageInfo => {

            resources.getRandomVideoYoutube(randList, auth.google_api_token).then(res => {
                const video = res[Math.floor((Math.random() * res.length) + 0)];

                message.channel.send(`-play https://www.youtube.com/watch?v=${video.snippet.resourceId.videoId}`);

                setTimeout(() => {
                    message.channel.messages.cache.get(messageInfo.id).delete();
                }, 900);

            }).catch(err => {
                console.log(err);
            });

        });





    } else if (msg.toLowerCase().startsWith(prefix) && msg.toLowerCase().includes('ideia')) {
        var ideias = require('./ideias.json');

        if (msg.toLowerCase().includes("nova")) {
            let value = msg.substring(msg.indexOf("ideia:") + 7);
            if (value.trim().length > 0 && value.trim().length > 3) {
                var igual = false;
                ideias.forEach(element => {
                    if (element.name == value) {
                        igual = true;
                    }
                });
                if (!igual) {
                    // // Cria uma nova ideia e adiciona
                    ideias.push({
                        "name": value,
                        "value": "--------------------------------------------------------"
                    });

                    fs.writeFileSync('./ideias.json', JSON.stringify(ideias));
                    message.channel.send('https://gph.is/2WJdfIb');
                } else {
                    message.channel.send("HOOOO génio, essa ideia já foi registada...");
                }
            } else {
                message.channel.send('http://gph.is/2vTTjUH');
            }

        } else if (msg.toLowerCase().includes("remove")) {
            if (message.author.id === '629779019805622273' && message.author.username.includes('Celinho')) {
                let value = msg.substring(msg.indexOf("ideia:") + 7);

                var removeu = false;

                ideias.forEach((element, index) => {
                    if (element.name.trim() == value.trim()) {
                        ideias.splice(index);
                        fs.writeFileSync('./ideias.json', JSON.stringify(ideias));
                        removeu = true;
                    }
                });

                if (!removeu) {
                    message.channel.send('http://gph.is/2eaV2hX');
                } else {
                    message.channel.send('http://gph.is/2eqrVG3');
                }

            } else {
                // withou permission
                message.channel.send('http://gph.is/2IhGeez');

            }
        } else {
            if (ideias.length > 0) {
                const embed = {
                    "title": "Ideias registadas",
                    "description": "...",
                    "color": 13632027,
                    "timestamp": new Date(),
                    "footer": {
                        "icon_url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png",
                        "text": "© Bald Bot | Criado por Jak 👨‍🦲 | Celo 🐱‍💻 | Ted 🧸"
                    },
                    "thumbnail": {
                        "url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png"
                    },
                    "author": {
                        "name": "Bald Bot Discord",
                        "icon_url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png"
                    },
                    "fields": ideias
                };
                message.channel.send({
                    embed
                });
            } else {
                message.channel.send('http://gph.is/2eaV2hX');
            }
        }


    } else if (msg.toLowerCase().startsWith(prefix)) { // Show all commands

        const exampleEmbed = {
            color: 0x0099ff,
            title: "Comandos disponiveis",
            //url: 'https://discord.js.org',
            // author: {
            //     name: 'Some name',
            //     icon_url: 'https://i.imgur.com/wSTFkRM.png',
            //     url: 'https://discord.js.org',
            // },
            description: `${message.author.username} andas perdido, aí andas andas, pois andaaaasssss`,
            // thumbnail: {
            //     url: '...',
            // },
            fields: [{
                    name: "<.moes>",
                    value: "TOES"
                }, {
                    name: "<.respond>",
                    value: "Respond command"
                }, {
                    name: "<.js>",
                    value: "Some JavaScript string"
                }, {
                    name: "<.spoons>",
                    value: "Random spoon string"
                }, {
                    name: "<.bonk>",
                    value: "Funny video"
                },
                {
                    name: "<.wide>",
                    value: "Wide image"
                }, {
                    name: "<.opgg>",
                    value: "League of Leggends"
                }, {
                    name: "<.corona>",
                    value: "Noticias sobre corona"
                }, {
                    name: "<.girl || .babe>",
                    value: "Some Juice"
                }, {
                    name: "<.tempo para [distrito]>",
                    value: "Meteorologia para 5 dias desse distrito"
                }, {
                    name: "<.make me happy>",
                    value: "Random funny video"
                },
                {
                    name: "<.mostrar ideias>",
                    value: "Mostra todas as ideias"
                },
                {
                    name: "<.nova ideia: [descrição]>",
                    value: "Adiciona nova ideia"
                },
                {
                    name: "<.remove ideia: [descrição]>",
                    value: "Remove ideia"
                }

            ],
            // image: {
            //     url: 'https://i.imgur.com/wSTFkRM.png',
            // },
            // timestamp: new Date(),
            // footer: {
            //     icon_url: 'https://i.imgur.com/wSTFkRM.png',
            // },

        };

        // console.log(message.channel.members);

        message.channel.send({
            embed: exampleEmbed
        });

    }

});
bot.login('NzMzMzk1NDg3NDk0NzY2NzEy.XxhcBA.6jOEg2-99etO-NpomnYgDz5hI2A');