var logger = require('winston');
var auth = require('./auth.json');
var Discord = require('discord.js');

var bot = new Discord.Client();

const resources = require('./requests');
const dateFormat = require('dateformat');
dateFormat.i18n = {
    dayNames: [
        'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat',
        'Domingo <:peepo_coolking:715130015108563005>', 'Segunda <:peepo_omfg:715131508775452762>', 'Terça <:peepo_revenge:715128191701745674>', 'Quarta <:peepo_king:641346090905370625>', 'Quinta <:peepo_shrug:731314904400789514>', 'Sexta <:peepo_happy:641346090188406784>', 'Sábado <:peepo_amazing:715130311264043091>'
    ],
    monthNames: [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
        'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
    ],
    timeNames: [
        'a', 'p', 'am', 'pm', 'A', 'P', 'AM', 'PM'
    ]
};

const cron = require('node-cron');

logger.remove(logger.transports.Console);
logger.add(new logger.transports.Console, {
    colorize: true
});

logger.level = 'debug';

var bot = new Discord.Client({
    token: auth.token,
    autorun: true
});
bot.on('ready', function (evt, channelID) {
    logger.info("Jak bot is running, catch him!");
});


bot.on('message', message => {
    var prefix = '.'
    var msg = message.content;
    if (message.author.bot) {
        return;
    }

    if (msg === prefix + 'bald') {
        message.channel.send('He bald', {
            files: ["kek.jpg"]
        });
    } else if (msg === prefix + 'moes') {
        message.channel.send("TOES!");
    } else if (msg === prefix + 'respond') {
        message.channel.send("<@" + 490333284920983573 + ">" + "RESPOND YOU COWARD!");
    } else if (msg === prefix + 'js') {
        message.channel.send("JavaScript go brrrrrrr");
    } else if (msg === prefix + 'spoons') {
        message.channel.send("Remember kids, metal spoons don't go in the trash");
    } else if (msg === prefix + 'bonk') {
        message.channel.send('', {
            files: ["bonk.webm"]
        });
    } else if (msg === prefix + 'wide') {
        message.channel.send('WIDE MOE WIDE MOE', {
            files: ["widemoe.jpg"]
        });
    } else if (msg.startsWith(prefix + 'opgg')) {
        var username = message.content.replace(".opgg ", "");
        message.channel.send("https://euw.op.gg/summoner/userName=" + username);
    } else if (msg.startsWith(prefix) && msg.toLowerCase().includes('corona', 1)) {
        resources.getNoticias().then(response => {
            const noticia = response[Math.floor((Math.random() * Object.keys(response).length) + 0)];
            // message.channel.send("Titulo: " + noticia.tituloNoticia);
            // message.channel.send("Descrição: " + noticia.descricao);
            // message.channel.send("Mais: " + noticia.fullUrl);
            const exampleEmbed = new Discord.MessageEmbed()
                .setColor('#0099ff')
                .setTitle(noticia.tituloNoticia)
                .setURL(noticia.fullUrl)
                .setDescription(noticia.descricao)
                .setImage(noticia.multimediaPrincipal)
                .setTimestamp(noticia.data)
                .setFooter(noticia.rubrica);

            message.channel.send(exampleEmbed);
        });
    } else if (msg.startsWith(prefix) && ((msg.toLowerCase().includes('girl')) || msg.toLowerCase().includes('babe'))) {

        resources.getNsfw(message.channel.nsfw).then(response => {
            const img = response[Math.floor((Math.random() * Object.keys(response).length) + 0)];
            // // message.channel.send("Titulo: " + noticia.tituloNoticia);
            // // message.channel.send("Descrição: " + noticia.descricao);
            // // message.channel.send("Mais: " + noticia.fullUrl);
            const exampleEmbed = new Discord.MessageEmbed()
                .setColor('#FF0000')
                .setTitle(img.title || "")
                .setURL(img.url)
                .setImage(img.image)

            message.channel.send(exampleEmbed);

        });


    } else if (msg.toLowerCase().startsWith(prefix + "tempo para")) {
        const distrito = msg.trim().substring((msg.indexOf('para') + 5));

        resources.getTempo(distrito.toLowerCase()).then(response => {


            // console.log(response.data[numeroDia]);
            const exampleEmbed = {
                color: 0x0099ff,
                title: 'Meteorologia para: ' + distrito,
                //url: 'https://discord.js.org',
                // author: {
                //     name: 'Some name',
                //     icon_url: 'https://i.imgur.com/wSTFkRM.png',
                //     url: 'https://discord.js.org',
                // },
                description: 'Para 5 dias',
                // thumbnail: {
                //     url: '...',
                // },
                fields: [{
                    name: dateFormat(response.data[0].forecastDate, "dd/mm/yyyy, dddd"),
                    value: ('Max: ' + response.data[0].tMax + "ºC    Min: " + response.data[0].tMin + "ºC")
                }, {
                    name: dateFormat(response.data[1].forecastDate, "dd/mm/yyyy, dddd"),
                    value: ('Max: ' + response.data[1].tMax + "ºC    Min: " + response.data[1].tMin + "ºC"),
                    inline: false,
                }, {
                    name: dateFormat(response.data[2].forecastDate, "dd/mm/yyyy, dddd"),
                    value: ('Max: ' + response.data[2].tMax + "ºC    Min: " + response.data[2].tMin + "ºC"),
                    inline: false
                }, {
                    name: dateFormat(response.data[3].forecastDate, "dd/mm/yyyy, dddd"),
                    value: ('Max: ' + response.data[3].tMax + "ºC    Min: " + response.data[3].tMin + "ºC"),
                    inline: false
                }, {
                    name: dateFormat(response.data[4].forecastDate, "dd/mm/yyyy, dddd"),
                    value: ('Max: ' + response.data[4].tMax + "ºC    Min: " + response.data[4].tMin + "ºC"),
                    inline: false
                }],
                // image: {
                //     url: 'https://i.imgur.com/wSTFkRM.png',
                // },
                // timestamp: new Date(),
                // footer: {
                //     icon_url: 'https://i.imgur.com/wSTFkRM.png',
                // },
            };

            message.channel.send({
                embed: exampleEmbed
            });


        }).catch(err => {

            message.channel.send(message.author.username +": "+err.message);

        });

    }

});
bot.login('NzMzMzk1NDg3NDk0NzY2NzEy.XxhcBA.6jOEg2-99etO-NpomnYgDz5hI2A');