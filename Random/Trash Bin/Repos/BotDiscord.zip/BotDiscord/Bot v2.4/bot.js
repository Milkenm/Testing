// * Bot --------------------------------
const logger = require('winston');
const auth = require('./auth.json');
const Discord = require('discord.js');
const resources = require('./requests');
const dateFormat = require('dateformat');
const fs = require('fs');
// const cron = require('node-cron');
dateFormat.masks.hammerTime = 'Hoje';
dateFormat.i18n = {
    dayNames: [
        'Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat',
        'Domingo <:peepo_coolking:715130015108563005>', 'Segunda-Feira <:peepo_omfg:715131508775452762>', 'Terça-Feira <:peepo_revenge:715128191701745674>', 'Quarta-Feira <:peepo_king:641346090905370625>', 'Quinta-Feira <:peepo_shrug:731314904400789514>', 'Sexta-Feira <:peepo_happy:641346090188406784>', 'Sábado <:peepo_amazing:715130311264043091>'
    ],
    monthNames: [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
        'January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'
    ],
    timeNames: [
        'a', 'p', 'am', 'pm', 'A', 'P', 'AM', 'PM'
    ]
};
const bot = new Discord.Client({
    token: auth.token,
    autorun: true
});
var comandos = require('./public/command_history.json');
var ideias = require('./public/ideias.json');
// !! Bot --------------------------------
// * Server ------------------------------
const express = require('express');
const app = express();
const server = require('http').Server(app);
const cors = require('cors');
const options = {};
const io = require('socket.io')(server, options);
const PORT = process.env.PORT || 4000;

app.use(express.json());
app.use(express.static(__dirname));
app.use(cors(), (req, res, next) => {
    res.setHeader("Access-Control-Allow-Origin", "*");
    next();
});
io.on('connection', socket => {
    console.log(`New connection`);
    socket.on('disconnect', data => {
        console.log(data);
    });
});

const router = require('./Components/router')(comandos, ideias);
app.use('/get', router);

// !! Server ------------------------------

logger.remove(logger.transports.Console);
logger.add(new logger.transports.Console, {
    colorize: true
});

logger.level = 'debug';

bot.on('ready', function (evt, channelID) {
    logger.info("Jak bot is running, catch him!");
});

function setCommand(data) {
    comandos.push({
        info: data.info,
        author: data.author,
        timestamp: dateFormat(new Date(), "dd/mm/yyyy, HH:MM:ss")
    });
    fs.writeFileSync('./public/command_history.json', JSON.stringify(comandos));
    console.log(`Comando executado: <${comandos[comandos.length-1].author}>`);
    io.sockets.emit('teste', comandos[comandos.length - 1]);
}

bot.on('message', message => {
    var prefix = '.'
    var msg = message.content;

    if (message.author.bot) {
        return;
    }

    if (msg === prefix + 'bald') {
        message.channel.send('He bald', {
            files: ["kek.jpg"]
        });

        setCommand({
            info: msg,
            author: message.author.username
        });

    } else if (msg === prefix + 'moes') {
        message.channel.send("TOES!");
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg === prefix + 'respond') {
        message.channel.send("<@" + 490333284920983573 + ">" + "RESPOND YOU COWARD!");
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg === prefix + 'js') {
        message.channel.send("JavaScript go brrrrrrr");
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg === prefix + 'spoons') {
        message.channel.send("Remember kids, metal spoons don't go in the trash");
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg === prefix + 'bonk') {
        message.channel.send('', {
            files: ["bonk.webm"]
        });
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg === prefix + 'wide') {
        message.channel.send('WIDE MOE WIDE MOE', {
            files: ["widemoe.jpg"]
        });
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg.startsWith(prefix + 'opgg')) {
        var username = message.content.replace(".opgg ", "");
        message.channel.send("https://euw.op.gg/summoner/userName=" + username);
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg.startsWith(prefix) && msg.toLowerCase().includes('corona', 1)) {
        resources.getNoticias().then(response => {
            const noticia = response[Math.floor((Math.random() * Object.keys(response).length) + 0)];
            // message.channel.send("Titulo: " + noticia.tituloNoticia);
            // message.channel.send("Descrição: " + noticia.descricao);
            // message.channel.send("Mais: " + noticia.fullUrl);
            const exampleEmbed = new Discord.MessageEmbed()
                .setColor('#0099ff')
                .setTitle(noticia.tituloNoticia)
                .setURL(noticia.fullUrl)
                .setDescription(noticia.descricao)
                .setImage(noticia.multimediaPrincipal)
                .setTimestamp(noticia.data)
                .setFooter(noticia.rubrica);

            message.channel.send(exampleEmbed);
        });
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg.startsWith(prefix) && ((msg.toLowerCase().includes('girl')) || msg.toLowerCase().includes('babe'))) {

        resources.getNsfw(message.channel.nsfw).then(response => {
            const img = response[Math.floor((Math.random() * Object.keys(response).length) + 0)];
            // // message.channel.send("Titulo: " + noticia.tituloNoticia);
            // // message.channel.send("Descrição: " + noticia.descricao);
            // // message.channel.send("Mais: " + noticia.fullUrl);
            const exampleEmbed = new Discord.MessageEmbed()
                .setColor('#FF0000')
                .setTitle(img.title || "")
                .setURL(img.url)
                .setImage(img.image)

            message.channel.send(exampleEmbed);

        });
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg.toLowerCase().startsWith(prefix + "tempo para")) {
        const distrito = msg.trim().substring((msg.indexOf('para') + 5));

        resources.getTempo(distrito.toLowerCase()).then(response => {

            const embed = {
                "title": `⛅ Meteorologia para ${distrito}`,
                "description": "Próximos 5 dias",
                "color": 13632027,
                "timestamp": new Date(),
                "footer": {
                    "icon_url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png",
                    "text": "© Bald Bot | Criado por Jak 👨‍🦲 | Celo 🐱‍💻 | Ted 🧸"
                },
                "thumbnail": {
                    "url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png"
                },
                "author": {
                    "name": "Bald Bot Discord",
                    "icon_url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png"
                },
                "fields": [{
                        "name": "-------------------------------------------------------------------------------",
                        "value": "-"
                    }, {
                        "name": `📅 ${dateFormat(response.data[0].forecastDate, "dd/mm/yyyy, dddd '(Hoje)'")}`,
                        "value": `🌡️ Max: ${response.data[0].tMax}ºC | Min: ${response.data[0].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "----------------------------------------------------------------------------"
                    },
                    {
                        "name": `📅 ${dateFormat(response.data[1].forecastDate, "dd/mm/yyyy, dddd")}`,
                        "value": `🌡️ Max: ${response.data[1].tMax}ºC | Min: ${response.data[1].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "----------------------------------------------------------------------------"
                    },
                    {
                        "name": `📅 ${dateFormat(response.data[2].forecastDate, "dd/mm/yyyy, dddd")}`,
                        "value": `🌡️ Max: ${response.data[2].tMax}ºC | Min: ${response.data[2].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "----------------------------------------------------------------------------"
                    },
                    {
                        "name": `📅 ${dateFormat(response.data[3].forecastDate, "dd/mm/yyyy, dddd")}`,
                        "value": `🌡️ Max: ${response.data[3].tMax}ºC | Min: ${response.data[3].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "----------------------------------------------------------------------------"
                    },
                    {
                        "name": `📅 ${dateFormat(response.data[4].forecastDate, "dd/mm/yyyy, dddd")}`,
                        "value": `🌡️ Max: ${response.data[4].tMax}ºC | Min: ${response.data[4].tMin}ºC`
                    },
                    {
                        "name": "-------------------------------------------------------------------------------",
                        "value": "-"
                    }
                ]
            };
            message.channel.send({
                embed
            });

            // message.channel.send({
            //     embed: exampleEmbed
            // });


        }).catch(err => {

            message.channel.send(message.author.username + ": " + err.message);

        });

        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg.toLowerCase().startsWith(prefix + "make me happy")) {
        const listsId = ['PL2satA_B-xnSAxmFXHgb1tsaVJ_Pfhrg2', 'PL_90hJucBAcPmFxcbTea81OKGkQevH2F9', 'PLQZgI7en5XEgM0L1_ZcKmEzxW1sCOVZwP'];
        const randList = listsId[Math.floor((Math.random() * listsId.length) + 0)];

        message.channel.send("https://i.pinimg.com/originals/30/72/55/3072558f02be09d1a156ddfb01bd4be4.gif").then(messageInfo => {

            resources.getRandomVideoYoutube(randList, auth.google_api_token).then(res => {
                const video = res[Math.floor((Math.random() * res.length) + 0)];

                message.channel.send(`https://www.youtube.com/watch?v=${video.snippet.resourceId.videoId}`);

                setTimeout(() => {
                    message.channel.messages.cache.get(messageInfo.id).delete();
                }, 900);

            }).catch(err => {
                console.log(err);
            });

        });
        setCommand({
            info: msg,
            author: message.author.username
        });
    } else if (msg.toLowerCase().startsWith(prefix) && msg.toLowerCase().includes('ideia')) {
        if (msg.toLowerCase().includes("nova") && msg.toLowerCase().includes(":")) {
            let value = msg.substring(msg.indexOf("ideia:") + 7);

            if (value.trim().length > 0 && value.trim().length > 3) {
                var igual = false;
                ideias.forEach(element => {

                    if (element.name.substring(element.name.indexOf(parseInt(element.name.match(/^\d+|\d+\b|\d+(?=\w)/g)[0])) + 1).trim().toLowerCase() == value.toLocaleLowerCase()) {
                        igual = true;
                    }
                });
                if (!igual) {
                    //  Cria uma nova ideia e adiciona
                    ideias.push({
                        "name": `#${ideias.length} ${value}`,
                        "value": "--------------------------------------------------------"
                    });

                    fs.writeFileSync('./public/ideias.json', JSON.stringify(ideias));
                    message.channel.send('https://gph.is/2WJdfIb');
                } else {
                    message.channel.send("HOOOO génio, essa ideia já foi registada...");
                }
            } else {
                message.channel.send('http://gph.is/2vTTjUH');
            }

        } else if (msg.toLowerCase().includes("remove") && msg.toLowerCase().includes(":")) {
            if (message.author.id === '629779019805622273' && message.author.username.includes('Celinho')) {
                let value = parseInt(msg.substring(msg.indexOf("ideia:") + 7));

                if (value <= ideias.length) {
                    ideias.splice(value, 1);
                    fs.writeFileSync('./public/ideias.json', JSON.stringify(ideias));
                    removeu = true;
                }


                if (!removeu) {
                    message.channel.send('http://gph.is/2eaV2hX');
                } else {
                    message.channel.send('http://gph.is/2eqrVG3');
                }

            } else {
                // withou permission
                message.channel.send('http://gph.is/2IhGeez');

            }
        } else {
            if (ideias.length > 0) {
                const embed = {
                    "title": "Ideias registadas",
                    "description": "...",
                    "color": 13632027,
                    "timestamp": new Date(),
                    "footer": {
                        "icon_url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png",
                        "text": "© Bald Bot | Criado por Jak 👨‍🦲 | Celo 🐱‍💻 | Ted 🧸"
                    },
                    "thumbnail": {
                        "url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png"
                    },
                    "author": {
                        "name": "Bald Bot Discord",
                        "icon_url": "https://media.discordapp.net/attachments/642325979653734410/738368273896439820/mybest_capture_2020-07-30_125810.png"
                    },
                    "fields": ideias
                };
                message.channel.send({
                    embed
                });

            } else {
                message.channel.send('http://gph.is/2eaV2hX');
            }
        }

        setCommand({
            info: msg,
            author: message.author.username
        });

    } else if (msg.toLowerCase().startsWith(prefix + "help")) { // Show all commands

        const exampleEmbed = {
            color: 0x0099ff,
            title: "Comandos disponiveis",
            //url: 'https://discord.js.org',
            // author: {
            //     name: 'Some name',
            //     icon_url: 'https://i.imgur.com/wSTFkRM.png',
            //     url: 'https://discord.js.org',
            // },
            description: `${message.author.username} andas perdido, aí andas andas, pois andaaaasssss`,
            // thumbnail: {
            //     url: '...',
            // },
            fields: [{
                    name: "<.moes>",
                    value: "TOES"
                }, {
                    name: "<.respond>",
                    value: "Respond command"
                }, {
                    name: "<.js>",
                    value: "Some JavaScript string"
                }, {
                    name: "<.spoons>",
                    value: "Random spoon string"
                }, {
                    name: "<.bonk>",
                    value: "Funny video"
                },
                {
                    name: "<.wide>",
                    value: "Wide image"
                }, {
                    name: "<.opgg>",
                    value: "League of Leggends"
                }, {
                    name: "<.corona>",
                    value: "Noticias sobre corona"
                }, {
                    name: "<.girl || .babe>",
                    value: "Some Juice"
                }, {
                    name: "<.tempo para [distrito]>",
                    value: "Meteorologia para 5 dias desse distrito"
                }, {
                    name: "<.make me happy>",
                    value: "Random funny video"
                },
                {
                    name: "<.mostrar ideias>",
                    value: "Mostra todas as ideias"
                },
                {
                    name: "<.nova ideia: [descrição]>",
                    value: "Adiciona nova ideia"
                },
                {
                    name: "<.remove ideia: [descrição]>",
                    value: "Remove ideia"
                }

            ],
            // image: {
            //     url: 'https://i.imgur.com/wSTFkRM.png',
            // },
            // timestamp: new Date(),
            // footer: {
            //     icon_url: 'https://i.imgur.com/wSTFkRM.png',
            // },

        };

        // console.log(message.channel.members);

        message.channel.send({
            embed: exampleEmbed
        });
        setCommand({
            info: msg,
            author: message.author.username
        });
    }

});

bot.login(auth.token);

server.listen(PORT, () => {
    console.log(`Server running: 127.0.0.1:${PORT}`)
});