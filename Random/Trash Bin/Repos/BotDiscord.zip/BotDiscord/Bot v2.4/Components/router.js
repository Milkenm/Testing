module.exports = (Commands,Ideias) => {
    const Router = require("express").Router();

    Router.get('/commands', (req, res) => {
        res.status(200).send(Commands);
    });

    Router.get('/ideias', (req, res) => {
        res.status(200).send(Ideias);
    });

    return Router;
};