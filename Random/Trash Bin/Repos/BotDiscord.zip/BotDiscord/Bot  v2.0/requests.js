const axios = require('axios');

const getUser = async (pag, user) => {
    // Variável que guarda o user
    var userTest = [];

    await axios({
        method: 'GET',
        // vai buscar o user com a url query (em desenvolvimento)
        url: "https://api.twitch.tv/helix/streams/metadata?after=" + pag + "&user_name=" + user,
        headers: {
            "Client-ID": "dtudeklwpfe6yihlbll9nn8do3gb1j",
            "Authorization": "Bearer 1505my5q7v54v1qfqvfcucdawyinpw"
        }
    }).then(res => {
        // Se encontou, adiciona ao array de users
        res.data.data.forEach(element => {
            userTest.push(element);
        });

    }).catch(err => {
        // Se não, mostra o erro
        console.log(err);
    });

    // retorna em forma de objeto o user encontrado ou não
    return {
        user: userTest,
    };

}

exports.getUser = getUser;