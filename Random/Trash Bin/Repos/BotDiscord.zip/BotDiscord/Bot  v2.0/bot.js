var Discord = require('discord.io');
var logger = require('winston');
var auth = require('./auth.json');
var Discord2 = require('discord.js');
var bot = new Discord2.Client();


logger.remove(logger.transports.Console);
logger.add(new logger.transports.Console, {
    colorize: true
});

logger.level = 'debug';

var bot = new Discord2.Client({
    token: auth.token,
    autorun: true
});
bot.on('ready', function (evt) {
    logger.info("Running");
});

console.log("Oof")

bot.on('message', message => {
    var prefix = '.'
    var msg = message.content;

    if (msg === prefix + 'bald') {
        message.channel.send('He bald', {
            files: ["kek.jpg"]
        });
    }
    else if (msg === prefix + 'moes') {
        message.channel.send("TOES!");
    }
    else if (msg === prefix + 'respond') {
        message.channel.send("<@" + 490333284920983573 + ">"+"RESPOND YOU COWARD!");
    }
    else if (msg === prefix + 'js') {
        message.channel.send("JavaScript go brrrrrrr");
    }
    else if (msg === prefix + 'spoons') {
        message.channel.send("Remember kids, metal spoons don't go in the trash");
    }
    else if (msg === prefix + 'bonk') {
        message.channel.send('', {
            files: ["bonk.webm"]
        });
    }    
    else if (msg === prefix + 'wide') {
        message.channel.send('WIDE MOE WIDE MOE', {
            files: ["widemoe.jpg"]
        });    
    }
    
});

bot.login('NzMzMzk1NDg3NDk0NzY2NzEy.XxhcBA.6jOEg2-99etO-NpomnYgDz5hI2A');

