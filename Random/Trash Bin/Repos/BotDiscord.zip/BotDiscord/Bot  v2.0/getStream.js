const axios = require('axios');
const getStream = async () => {
    await axios({
        method: 'GET',
        url: "https://api.twitch.tv/kraken/streams/86277097",
        headers: {
            "Client-ID": "dtudeklwpfe6yihlbll9nn8do3gb1j",
            "Authorization": "Bearer 1505my5q7v54v1qfqvfcucdawyinpw"
        }
    }).then(res => {
        
        res.data.data.forEach(element => {
            console.log("FUNFOU");
        });

    }).catch(err => {
        // Se não, mostra o erro
        console.log(err);
    });

    // retorna em forma de objeto o user encontrado ou não
    return {
        user: userTest,
    };

}
exports.getStream=getStream