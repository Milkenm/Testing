﻿using System;
using System.Web.UI;

namespace T_ASP_2
{
	public partial class Autor : Page
	{
		protected void btnPesquisarLivroAutor_Click(object sender, EventArgs e)
		{
			// O atributo SelectCommand do SqlDataSource contém a instrução SELECT que vai ser executada pelo DataSource para obter os dados da BD
			SqlDataSource1.SelectCommand = "SELECT LIVROS.TITULO, LIVROS.IDLIVRO FROM LIVROS INNER JOIN AUTORLIVRO ON LIVROS.IDLIVRO = AUTORLIVRO.IDLIVRO WHERE AUTORLIVRO.IDAUTOR=" + txbCodigoAutor.Text;

			// O método DataBind permite obter dados da BD e atualizá-los. O método Eval apenas permite obter os dados da BD (pg 429 - livro asp.net Murach)
			SqlDataSource1.DataBind();
		}

		protected void btnLimparCodigoAutor_Click(object sender, EventArgs e)
		{
			txbCodigoAutor.Text = "";

			// O atributo SelectCommand do SqlDataSource contém a instrução SELECT que vai ser executada pelo DataSource para obter os dados da BD
			SqlDataSource1.SelectCommand = "SELECT distinct LIVROS.TITULO, LIVROS.IDLIVRO FROM LIVROS INNER JOIN AUTORLIVRO ON LIVROS.IDLIVRO = AUTORLIVRO.IDLIVRO";

			// O método DataBind permite obter dados da BD e atualizá-los. O método Eval apenas permite obter os dados da BD (pg 429 - livro asp.net Murach)
			SqlDataSource1.DataBind();
		}
	}
}