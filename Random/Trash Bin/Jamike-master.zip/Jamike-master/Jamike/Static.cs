﻿namespace Jamike
{
				internal static class Static
				{
								internal static Main MainForm;
				}
}