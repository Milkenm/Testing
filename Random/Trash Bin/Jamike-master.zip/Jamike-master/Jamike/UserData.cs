﻿using Newtonsoft.Json;
using System.Collections.Generic;

namespace Jamike
{
				public static class UserData
				{
								private static string TempData;

								public static void SaveData(UsersList user)
								{
												TempData = JsonConvert.SerializeObject(user);
								}

								public static UsersList GetData()
								{
												return JsonConvert.DeserializeObject<UsersList>(TempData);
								}

								public class UsersList
								{
												public List<Utilizador> users;
								}

								public class Utilizador
								{
												public int id;
												public List<Moedas> moedas;
								}

								public class Moedas
								{
												public string moeda;
												public int quantidade;
								}
				}
}