﻿using ScriptsLib.nDatabases;
using System;
using System.Windows.Forms;

namespace Jamike
{
				internal static class Program
				{
								[STAThread]
								private static void Main()
								{
												Application.EnableVisualStyles();
												Application.SetCompatibleTextRenderingDefault(false);

												AccessDatabase._DatabasePath = Application.StartupPath + @"\JamikeDB.mdb";
												Static.MainForm = new Main();

												Application.Run(Static.MainForm);
								}
				}
}