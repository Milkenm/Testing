﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

using ScriptsLib.nDatabases;

namespace Jamike
{
	public partial class AdicionarTransacao : Form
	{
		private static decimal total;
		private static decimal init2Euros, init1Euro, init50Centimos, init20Centimos, init10Centimos, init5Centimos, init2Centimos, init1Centimo;

		public AdicionarTransacao()
		{
			InitializeComponent();
		}

		private void FormLoad(object sender, EventArgs e)
		{
			List<string> pessoas = AccessDatabase.Select("Pessoas", "Nome");

			if (pessoas != null && pessoas.Count > 0)
			{
				foreach (string pessoa in pessoas)
				{
					cb_pessoa.Items.Add(pessoa);
				}
			}

			init2Euros = Convert.ToDecimal(Static.MainForm.txt_quantidade2Euros.Text);
			init1Euro = Convert.ToDecimal(Static.MainForm.txt_quantidade1Euro.Text);
			init50Centimos = Convert.ToDecimal(Static.MainForm.txt_quantidade50Centimos.Text);
			init20Centimos = Convert.ToDecimal(Static.MainForm.txt_quantidade20Centimos.Text);
			init20Centimos = Convert.ToDecimal(Static.MainForm.txt_quantidade20Centimos.Text);
			init10Centimos = Convert.ToDecimal(Static.MainForm.txt_quantidade10Centimos.Text);
			init5Centimos = Convert.ToDecimal(Static.MainForm.txt_quantidade5Centimos.Text);
			init2Centimos = Convert.ToDecimal(Static.MainForm.txt_quantidade2Centimos.Text);
			init1Centimo = Convert.ToDecimal(Static.MainForm.txt_quantidade1Centimo.Text);

			num_2Euros.Value = init2Euros;
			num_1Euro.Value = init1Euro;
			num_50Centimos.Value = init50Centimos;
			num_20Centimos.Value = init20Centimos;
			num_10Centimos.Value = init10Centimos;
			num_5Centimos.Value = init5Centimos;
			num_2Centimos.Value = init2Centimos;
			num_1Centimo.Value = init1Centimo;
		}

		private void CriarTransacao(object sender, EventArgs e)
		{
			try
			{
				if (!string.IsNullOrEmpty(cb_pessoa.Text) && txt_total.Text != "0.00 €")
				{
					AccessDatabase.InsertInto("Moedas", "2Euros,1Euro,50Centimos,20Centimos,10Centimos,5Centimos,2Centimos,1Centimo", $"{num_2Euros.Value - init2Euros},{num_1Euro.Value - init1Euro},{num_50Centimos.Value - init50Centimos},{num_20Centimos.Value - init20Centimos},{num_10Centimos.Value - init10Centimos},{num_5Centimos.Value - init5Centimos},{num_2Centimos.Value - init2Centimos},{num_1Centimo.Value - init1Centimo}").GetAwaiter();
					Thread.Sleep(500);
					int idMoedas = Convert.ToInt32(AccessDatabase.Select("Moedas", "MAX(ID)")[0]);
					int idPessoa = Convert.ToInt32(AccessDatabase.Select("Pessoas", "ID", $"Nome = '{cb_pessoa.Text}'")[0]);
					AccessDatabase.InsertInto("Transacoes", "Pessoa,Montante,Moedas", $"{idPessoa},'{total}',{idMoedas}");

					MessageBox.Show("Transação adicionada.");
					Static.MainForm.Atualizar(null, null);
					Close();
				}
				else
				{
					MessageBox.Show("Erro ao criar a nova transação.\nInsere todos os valores necessários e tenta novamente.");
				}
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void AtualizarTotal(object sender, EventArgs e)
		{
			decimal conta2Euros = (num_2Euros.Value - init2Euros) * 2;
			decimal conta1Euro = (num_1Euro.Value - init1Euro);
			decimal conta50Centimos = (num_50Centimos.Value - init50Centimos) * (decimal)0.50;
			decimal conta20Centimos = (num_20Centimos.Value - init20Centimos) * (decimal)0.20;
			decimal conta10Centimos = (num_10Centimos.Value - init10Centimos) * (decimal)0.10;
			decimal conta5Centimos = (num_5Centimos.Value - init5Centimos) * (decimal)0.05;
			decimal conta2Centimos = (num_2Centimos.Value - init2Centimos) * (decimal)0.02;
			decimal conta1Centimo = (num_1Centimo.Value - init1Centimo) * (decimal)0.01;

			txt_total2Euros.Text = conta2Euros.ToString("0.00 €");
			txt_total1Euro.Text = conta1Euro.ToString("0.00 €");
			txt_total50Centimos.Text = conta50Centimos.ToString("0.00 €");
			txt_total20Centimos.Text = conta20Centimos.ToString("0.00 €");
			txt_total10Centimos.Text = conta10Centimos.ToString("0.00 €");
			txt_total5Centimos.Text = conta5Centimos.ToString("0.00 €");
			txt_total2Centimos.Text = conta2Centimos.ToString("0.00 €");
			txt_total1Centimo.Text = conta1Centimo.ToString("0.00 €");

			total = conta2Euros + conta1Euro + conta50Centimos + conta20Centimos + conta10Centimos + conta5Centimos + conta2Centimos + conta1Centimo;
			txt_total.Text = total.ToString("0.00 €");
		}
	}
}