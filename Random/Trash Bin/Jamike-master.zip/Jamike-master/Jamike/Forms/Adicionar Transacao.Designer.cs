﻿namespace Jamike
{
	partial class AdicionarTransacao
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
												System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdicionarTransacao));
												this.cb_pessoa = new System.Windows.Forms.ComboBox();
												this.b_adicionar = new System.Windows.Forms.Button();
												this.num_valor = new System.Windows.Forms.NumericUpDown();
												this.l_pessoa = new System.Windows.Forms.Label();
												this.l_valor = new System.Windows.Forms.Label();
												((System.ComponentModel.ISupportInitialize)(this.num_valor)).BeginInit();
												this.SuspendLayout();
												// 
												// cb_pessoa
												// 
												this.cb_pessoa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
												this.cb_pessoa.FormattingEnabled = true;
												this.cb_pessoa.Location = new System.Drawing.Point(79, 15);
												this.cb_pessoa.Name = "cb_pessoa";
												this.cb_pessoa.Size = new System.Drawing.Size(200, 21);
												this.cb_pessoa.Sorted = true;
												this.cb_pessoa.TabIndex = 0;
												// 
												// b_adicionar
												// 
												this.b_adicionar.BackColor = System.Drawing.SystemColors.Info;
												this.b_adicionar.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_adicionar.Location = new System.Drawing.Point(201, 80);
												this.b_adicionar.Name = "b_adicionar";
												this.b_adicionar.Size = new System.Drawing.Size(78, 21);
												this.b_adicionar.TabIndex = 31;
												this.b_adicionar.Text = "Adicionar";
												this.b_adicionar.UseVisualStyleBackColor = false;
												this.b_adicionar.Click += new System.EventHandler(this.CriarTransacao);
												// 
												// num_valor
												// 
												this.num_valor.Location = new System.Drawing.Point(79, 42);
												this.num_valor.Name = "num_valor";
												this.num_valor.Size = new System.Drawing.Size(200, 20);
												this.num_valor.TabIndex = 32;
												// 
												// l_pessoa
												// 
												this.l_pessoa.AutoSize = true;
												this.l_pessoa.Location = new System.Drawing.Point(25, 18);
												this.l_pessoa.Name = "l_pessoa";
												this.l_pessoa.Size = new System.Drawing.Size(48, 13);
												this.l_pessoa.TabIndex = 33;
												this.l_pessoa.Text = "Pessoa :";
												// 
												// l_valor
												// 
												this.l_valor.AutoSize = true;
												this.l_valor.Location = new System.Drawing.Point(36, 44);
												this.l_valor.Name = "l_valor";
												this.l_valor.Size = new System.Drawing.Size(37, 13);
												this.l_valor.TabIndex = 34;
												this.l_valor.Text = "Valor :";
												// 
												// AdicionarTransacao
												// 
												this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
												this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
												this.ClientSize = new System.Drawing.Size(304, 116);
												this.Controls.Add(this.l_pessoa);
												this.Controls.Add(this.cb_pessoa);
												this.Controls.Add(this.l_valor);
												this.Controls.Add(this.num_valor);
												this.Controls.Add(this.b_adicionar);
												this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
												this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
												this.Name = "AdicionarTransacao";
												this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
												this.Text = "Jamike - Adicionar Transação";
												this.Load += new System.EventHandler(this.FormLoad);
												((System.ComponentModel.ISupportInitialize)(this.num_valor)).EndInit();
												this.ResumeLayout(false);
												this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.ComboBox cb_pessoa;
		private System.Windows.Forms.Button b_adicionar;
								private System.Windows.Forms.NumericUpDown num_valor;
								private System.Windows.Forms.Label l_pessoa;
								private System.Windows.Forms.Label l_valor;
				}
}