﻿using System;
using System.Collections.Generic;
using System.Threading;
using System.Windows.Forms;

using ScriptsLib.nDatabases;

namespace Jamike
{
	public partial class AdicionarPessoa : Form
	{
		public AdicionarPessoa()
		{
			InitializeComponent();
		}

		private void Adicionar(object sender, EventArgs e)
		{
			List<string> pessoas = AccessDatabase.Select("Pessoas", "ID", $"Nome = '{txt_nome.Text}'");
			if (pessoas == null || pessoas.Count == 0)
			{
				AccessDatabase.InsertInto("Pessoas", "Nome", $"'{txt_nome.Text}'").GetAwaiter();
				Thread.Sleep(500);
				Static.MainForm.Atualizar(null, null);
				Close();
			}
			else
			{
				MessageBox.Show("Já existe uma pessoa com esse nome na base de dados!");
			}
		}

		private void ValidateTextBox(object sender, EventArgs e)
		{
			b_adicionarPessoa.Enabled = txt_nome.Text.Length >= 2 && txt_nome.Text.ToCharArray()[0] != ' ' && !string.IsNullOrEmpty(txt_nome.Text) && !string.IsNullOrWhiteSpace(txt_nome.Text);
		}

		private void AcceptTextBoxEnterPress(object sender, KeyEventArgs e)
		{
			if (e.KeyCode == Keys.Enter)
			{
				b_adicionarPessoa.PerformClick();
			}
		}
	}
}