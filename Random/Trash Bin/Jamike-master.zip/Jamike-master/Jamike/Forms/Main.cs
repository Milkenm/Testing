﻿using ScriptsLib.Controls.Tweaks;
using ScriptsLib.nDatabases;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace Jamike
{
				public partial class Main : Form
				{
								private static decimal total;

								public Main()
								{
												InitializeComponent();
								}

								public void Atualizar(object sender, EventArgs e)
								{
												UserData.UsersList usersList = new UserData.UsersList();

												List<string> dbUsers = AccessDatabase.Select("Pessoas", "ID");
												if (dbUsers != null && dbUsers.Count > 0)
												{
																// CONTAINS USERS IN THE LIST
																foreach (string idUser in dbUsers)
																{
																				UserData.Utilizador user = new UserData.Utilizador();
																				user.id = Convert.ToInt32(idUser);

																				UserData.Moedas moedas1c = new UserData.Moedas();
																				moedas1c.moeda = "001";
																				moedas1c.quantidade = // quantidade de moedas de 1c que o utilizador depositou... TODO
				}
												}

												return;
												try
												{
																// LIMPA OS DADOS ANTIGOS
																total = 0;
																lv_pessoas.Items.Clear();

																txt_quantidade2Euros.Text = "0";
																txt_quantidade1Euro.Text = "0";
																txt_quantidade50Centimos.Text = "0";
																txt_quantidade20Centimos.Text = "0";
																txt_quantidade10Centimos.Text = "0";
																txt_quantidade5Centimos.Text = "0";
																txt_quantidade2Centimos.Text = "0";
																txt_quantidade1Centimo.Text = "0";

																List<string> pessoas = AccessDatabase.Select("Pessoas", "ID");
																if (pessoas != null && pessoas.Count > 0)
																{
																				foreach (string idPessoa in pessoas)
																				{
																								decimal moedas2Euros = 0;
																								decimal moedas1Euro = 0;
																								decimal moedas50Centimos = 0;
																								decimal moedas20Centimos = 0;
																								decimal moedas10Centimos = 0;
																								decimal moedas5Centimos = 0;
																								decimal moedas2Centimos = 0;
																								decimal moedas1Centimo = 0;

																								decimal depositos = 0;
																								decimal debitos = 0;

																								List<string> transacoes = AccessDatabase.Select("Transacoes", "ID", $"Pessoa = {idPessoa}");
																								if (transacoes != null && transacoes.Count > 0)
																								{
																												foreach (string idTransacao in transacoes)
																												{
																																int idMoedas = Convert.ToInt32(AccessDatabase.Select("Transacoes", "Moedas", $"ID = {idTransacao}")[0]);

																																decimal montante = Convert.ToDecimal(AccessDatabase.Select("Transacoes", "Montante", $"ID = {idTransacao}")[0]);
																																if (montante >= 0)
																																{
																																				depositos = depositos + montante;
																																}
																																else
																																{
																																				debitos = debitos + montante;
																																}

																																moedas2Euros = moedas2Euros + Convert.ToDecimal(AccessDatabase.Select("Moedas", "2Euros", $"ID = {idMoedas}")[0]);
																																moedas1Euro = moedas1Euro + Convert.ToDecimal(AccessDatabase.Select("Moedas", "1Euro", $"ID = {idMoedas}")[0]);
																																moedas50Centimos = moedas50Centimos + Convert.ToDecimal(AccessDatabase.Select("Moedas", "50Centimos", $"ID = {idMoedas}")[0]);
																																moedas20Centimos = moedas20Centimos + Convert.ToDecimal(AccessDatabase.Select("Moedas", "20Centimos", $"ID = {idMoedas}")[0]);
																																moedas10Centimos = moedas10Centimos + Convert.ToDecimal(AccessDatabase.Select("Moedas", "10Centimos", $"ID = {idMoedas}")[0]);
																																moedas5Centimos = moedas5Centimos + Convert.ToDecimal(AccessDatabase.Select("Moedas", "5Centimos", $"ID = {idMoedas}")[0]);
																																moedas2Centimos = moedas2Centimos + Convert.ToDecimal(AccessDatabase.Select("Moedas", "2Centimos", $"ID = {idMoedas}")[0]);
																																moedas1Centimo = moedas1Centimo + Convert.ToDecimal(AccessDatabase.Select("Moedas", "1Centimo", $"ID = {idMoedas}")[0]);
																												}
																								}
																								txt_quantidade2Euros.Text = (Convert.ToInt32(txt_quantidade2Euros.Text) + moedas2Euros).ToString();
																								txt_quantidade1Euro.Text = (Convert.ToInt32(txt_quantidade1Euro.Text) + moedas1Euro).ToString();
																								txt_quantidade50Centimos.Text = (Convert.ToInt32(txt_quantidade50Centimos.Text) + moedas50Centimos).ToString();
																								txt_quantidade20Centimos.Text = (Convert.ToInt32(txt_quantidade20Centimos.Text) + moedas20Centimos).ToString();
																								txt_quantidade10Centimos.Text = (Convert.ToInt32(txt_quantidade10Centimos.Text) + moedas10Centimos).ToString();
																								txt_quantidade5Centimos.Text = (Convert.ToInt32(txt_quantidade5Centimos.Text) + moedas5Centimos).ToString();
																								txt_quantidade2Centimos.Text = (Convert.ToInt32(txt_quantidade2Centimos.Text) + moedas2Centimos).ToString();
																								txt_quantidade1Centimo.Text = (Convert.ToInt32(txt_quantidade1Centimo.Text) + moedas1Centimo).ToString();

																								decimal total2Euros = moedas2Euros * 2;
																								decimal total1Euro = moedas1Euro;
																								decimal total50Centimos = moedas50Centimos * (decimal)0.50;
																								decimal total20Centimos = moedas20Centimos * (decimal)0.20;
																								decimal total10Centimos = moedas10Centimos * (decimal)0.10;
																								decimal total5Centimos = moedas5Centimos * (decimal)0.05;
																								decimal total2Centimos = moedas2Centimos * (decimal)0.02;
																								decimal total1Centimo = moedas1Centimo * (decimal)0.01;

																								decimal totalPessoa = total2Euros + total1Euro + total50Centimos + total20Centimos + total10Centimos + total5Centimos + total2Centimos + total1Centimo;
																								total = total + totalPessoa;

																								string[] stringPessoa = new string[5];

																								stringPessoa[1] = AccessDatabase.Select("Pessoas", "Nome", $"ID = {idPessoa}")[0];
																								stringPessoa[2] = totalPessoa.ToString("0.00 €");
																								stringPessoa[3] = depositos.ToString("0.00 €");
																								stringPessoa[4] = debitos.ToString("0.00 €");

																								lv_pessoas.Items.Add(new ListViewItem(stringPessoa));
																				}
																}
																txt_total.Text = total.ToString("0.00 €");
																txt_2Euros.Text = (Convert.ToDecimal(txt_quantidade2Euros.Text) * 2).ToString("0.00 €");
																txt_1Euro.Text = Convert.ToDecimal(txt_quantidade1Euro.Text).ToString("0.00 €");
																txt_50Centimos.Text = (Convert.ToDecimal(txt_quantidade50Centimos.Text) * (decimal)0.50).ToString("0.00 €");
																txt_20Centimos.Text = (Convert.ToDecimal(txt_quantidade20Centimos.Text) * (decimal)0.20).ToString("0.00 €");
																txt_10Centimos.Text = (Convert.ToDecimal(txt_quantidade10Centimos.Text) * (decimal)0.10).ToString("0.00 €");
																txt_5Centimos.Text = (Convert.ToDecimal(txt_quantidade5Centimos.Text) * (decimal)0.05).ToString("0.00 €");
																txt_2Centimos.Text = (Convert.ToDecimal(txt_quantidade2Centimos.Text) * (decimal)0.02).ToString("0.00 €");
																txt_1Centimo.Text = (Convert.ToDecimal(txt_quantidade1Centimo.Text) * (decimal)0.01).ToString("0.00 €");
												}
												catch (Exception ex)
												{
																Console.WriteLine(ex.Message);
												}
								}

								private void AbrirFormNovaPessoa(object sender, EventArgs e)
								{
												if (!SlForm.IsFormOpen("AdicionarPessoa"))
												{
																new AdicionarPessoa().Show();
												}
												else
												{
																SlForm.BringFormToFront("AdicionarPessoa");
												}
								}

								private void AbrirFormNovaTransacao(object sender, EventArgs e)
								{
												if (!SlForm.IsFormOpen("AdicionarTransacao"))
												{
																new AdicionarTransacao().Show();
												}
												else
												{
																SlForm.BringFormToFront("AdicionarTransacao");
												}
								}

								private void VerDetalhes(object sender, EventArgs e)
								{
												ListView.SelectedIndexCollection indices = lv_pessoas.SelectedIndices;
												if (indices.Count > 0)
												{
																MessageBox.Show(indices[0].ToString());
												}
								}
				}
}