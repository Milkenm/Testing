﻿namespace Jamike
{
	partial class AdicionarPessoa
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AdicionarPessoa));
			this.txt_nome = new System.Windows.Forms.TextBox();
			this.l_nome = new System.Windows.Forms.Label();
			this.b_adicionarPessoa = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// txt_nome
			// 
			this.txt_nome.Location = new System.Drawing.Point(59, 9);
			this.txt_nome.MaxLength = 30;
			this.txt_nome.Name = "txt_nome";
			this.txt_nome.Size = new System.Drawing.Size(298, 20);
			this.txt_nome.TabIndex = 1;
			this.txt_nome.TextChanged += new System.EventHandler(this.ValidateTextBox);
			this.txt_nome.KeyDown += new System.Windows.Forms.KeyEventHandler(this.AcceptTextBoxEnterPress);
			// 
			// l_nome
			// 
			this.l_nome.AutoSize = true;
			this.l_nome.Location = new System.Drawing.Point(12, 12);
			this.l_nome.Name = "l_nome";
			this.l_nome.Size = new System.Drawing.Size(41, 13);
			this.l_nome.TabIndex = 0;
			this.l_nome.Text = "Nome :";
			// 
			// b_adicionarPessoa
			// 
			this.b_adicionarPessoa.BackColor = System.Drawing.SystemColors.Info;
			this.b_adicionarPessoa.Enabled = false;
			this.b_adicionarPessoa.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.b_adicionarPessoa.Location = new System.Drawing.Point(282, 35);
			this.b_adicionarPessoa.Name = "b_adicionarPessoa";
			this.b_adicionarPessoa.Size = new System.Drawing.Size(75, 22);
			this.b_adicionarPessoa.TabIndex = 2;
			this.b_adicionarPessoa.Text = "Adicionar";
			this.b_adicionarPessoa.UseVisualStyleBackColor = false;
			this.b_adicionarPessoa.Click += new System.EventHandler(this.Adicionar);
			// 
			// AdicionarPessoa
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(368, 66);
			this.Controls.Add(this.l_nome);
			this.Controls.Add(this.txt_nome);
			this.Controls.Add(this.b_adicionarPessoa);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "AdicionarPessoa";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "JM";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.TextBox txt_nome;
		private System.Windows.Forms.Label l_nome;
		private System.Windows.Forms.Button b_adicionarPessoa;
	}
}