﻿namespace Jamike
{
	partial class Main
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
												System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Main));
												this.txt_total = new System.Windows.Forms.TextBox();
												this.l_total = new System.Windows.Forms.Label();
												this.b_verDetalhes = new System.Windows.Forms.Button();
												this.lv_pessoas = new System.Windows.Forms.ListView();
												this.lv_pessoas_bug = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
												this.lv_pessoas_pessoa = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
												this.lv_pessoas_saldo = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
												this.lv_pessoas_depositado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
												this.lb_pessoas_debitado = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
												this.p_total = new System.Windows.Forms.Panel();
												this.menu = new System.Windows.Forms.MenuStrip();
												this.menu_transacoes = new System.Windows.Forms.ToolStripMenuItem();
												this.menu_transacoes_novaTransacao = new System.Windows.Forms.ToolStripMenuItem();
												this.menu_transacoes_verTransacoes = new System.Windows.Forms.ToolStripMenuItem();
												this.menu_pessoas = new System.Windows.Forms.ToolStripMenuItem();
												this.menu_pessoas_novaPessoa = new System.Windows.Forms.ToolStripMenuItem();
												this.menu_pessoas_verPessoas = new System.Windows.Forms.ToolStripMenuItem();
												this.p_total.SuspendLayout();
												this.menu.SuspendLayout();
												this.SuspendLayout();
												// 
												// txt_total
												// 
												this.txt_total.Location = new System.Drawing.Point(46, 2);
												this.txt_total.Name = "txt_total";
												this.txt_total.ReadOnly = true;
												this.txt_total.Size = new System.Drawing.Size(154, 20);
												this.txt_total.TabIndex = 0;
												this.txt_total.TabStop = false;
												this.txt_total.Text = "0.00 €";
												// 
												// l_total
												// 
												this.l_total.AutoSize = true;
												this.l_total.Location = new System.Drawing.Point(3, 5);
												this.l_total.Name = "l_total";
												this.l_total.Size = new System.Drawing.Size(37, 13);
												this.l_total.TabIndex = 1;
												this.l_total.Text = "Total :";
												// 
												// b_verDetalhes
												// 
												this.b_verDetalhes.BackColor = System.Drawing.SystemColors.Info;
												this.b_verDetalhes.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
												this.b_verDetalhes.Location = new System.Drawing.Point(205, 226);
												this.b_verDetalhes.Name = "b_verDetalhes";
												this.b_verDetalhes.Size = new System.Drawing.Size(119, 26);
												this.b_verDetalhes.TabIndex = 2;
												this.b_verDetalhes.Text = "Ver Detalhes";
												this.b_verDetalhes.UseVisualStyleBackColor = false;
												this.b_verDetalhes.Click += new System.EventHandler(this.VerDetalhes);
												// 
												// lv_pessoas
												// 
												this.lv_pessoas.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.lv_pessoas_bug,
            this.lv_pessoas_pessoa,
            this.lv_pessoas_saldo,
            this.lv_pessoas_depositado,
            this.lb_pessoas_debitado});
												this.lv_pessoas.HideSelection = false;
												this.lv_pessoas.Location = new System.Drawing.Point(0, 25);
												this.lv_pessoas.Name = "lv_pessoas";
												this.lv_pessoas.ShowItemToolTips = true;
												this.lv_pessoas.Size = new System.Drawing.Size(324, 200);
												this.lv_pessoas.TabIndex = 3;
												this.lv_pessoas.TabStop = false;
												this.lv_pessoas.UseCompatibleStateImageBehavior = false;
												this.lv_pessoas.View = System.Windows.Forms.View.Details;
												// 
												// lv_pessoas_bug
												// 
												this.lv_pessoas_bug.DisplayIndex = 4;
												this.lv_pessoas_bug.Text = "Bug";
												this.lv_pessoas_bug.Width = 1;
												// 
												// lv_pessoas_pessoa
												// 
												this.lv_pessoas_pessoa.DisplayIndex = 0;
												this.lv_pessoas_pessoa.Text = "Pessoa";
												this.lv_pessoas_pessoa.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
												this.lv_pessoas_pessoa.Width = 109;
												// 
												// lv_pessoas_saldo
												// 
												this.lv_pessoas_saldo.DisplayIndex = 1;
												this.lv_pessoas_saldo.Text = "Saldo";
												this.lv_pessoas_saldo.Width = 70;
												// 
												// lv_pessoas_depositado
												// 
												this.lv_pessoas_depositado.DisplayIndex = 2;
												this.lv_pessoas_depositado.Text = "Depositado";
												this.lv_pessoas_depositado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
												this.lv_pessoas_depositado.Width = 70;
												// 
												// lb_pessoas_debitado
												// 
												this.lb_pessoas_debitado.DisplayIndex = 3;
												this.lb_pessoas_debitado.Text = "Debitado";
												this.lb_pessoas_debitado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
												this.lb_pessoas_debitado.Width = 70;
												// 
												// p_total
												// 
												this.p_total.BackColor = System.Drawing.SystemColors.Info;
												this.p_total.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
												this.p_total.Controls.Add(this.txt_total);
												this.p_total.Controls.Add(this.l_total);
												this.p_total.Location = new System.Drawing.Point(0, 226);
												this.p_total.Name = "p_total";
												this.p_total.Size = new System.Drawing.Size(204, 26);
												this.p_total.TabIndex = 1;
												// 
												// menu
												// 
												this.menu.BackColor = System.Drawing.SystemColors.Info;
												this.menu.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_transacoes,
            this.menu_pessoas});
												this.menu.Location = new System.Drawing.Point(0, 0);
												this.menu.Name = "menu";
												this.menu.Size = new System.Drawing.Size(324, 24);
												this.menu.TabIndex = 0;
												this.menu.Text = "menuStrip1";
												// 
												// menu_transacoes
												// 
												this.menu_transacoes.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_transacoes_novaTransacao,
            this.menu_transacoes_verTransacoes});
												this.menu_transacoes.Name = "menu_transacoes";
												this.menu_transacoes.Size = new System.Drawing.Size(77, 20);
												this.menu_transacoes.Text = "Transações";
												// 
												// menu_transacoes_novaTransacao
												// 
												this.menu_transacoes_novaTransacao.Name = "menu_transacoes_novaTransacao";
												this.menu_transacoes_novaTransacao.Size = new System.Drawing.Size(165, 22);
												this.menu_transacoes_novaTransacao.Text = "Nova transação...";
												this.menu_transacoes_novaTransacao.Click += new System.EventHandler(this.AbrirFormNovaTransacao);
												// 
												// menu_transacoes_verTransacoes
												// 
												this.menu_transacoes_verTransacoes.Name = "menu_transacoes_verTransacoes";
												this.menu_transacoes_verTransacoes.Size = new System.Drawing.Size(165, 22);
												this.menu_transacoes_verTransacoes.Text = "Ver transações...";
												// 
												// menu_pessoas
												// 
												this.menu_pessoas.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menu_pessoas_novaPessoa,
            this.menu_pessoas_verPessoas});
												this.menu_pessoas.Name = "menu_pessoas";
												this.menu_pessoas.Size = new System.Drawing.Size(60, 20);
												this.menu_pessoas.Text = "Pessoas";
												// 
												// menu_pessoas_novaPessoa
												// 
												this.menu_pessoas_novaPessoa.Name = "menu_pessoas_novaPessoa";
												this.menu_pessoas_novaPessoa.Size = new System.Drawing.Size(150, 22);
												this.menu_pessoas_novaPessoa.Text = "Nova pessoa...";
												this.menu_pessoas_novaPessoa.Click += new System.EventHandler(this.AbrirFormNovaPessoa);
												// 
												// menu_pessoas_verPessoas
												// 
												this.menu_pessoas_verPessoas.Name = "menu_pessoas_verPessoas";
												this.menu_pessoas_verPessoas.Size = new System.Drawing.Size(150, 22);
												this.menu_pessoas_verPessoas.Text = "Ver pessoas...";
												// 
												// Main
												// 
												this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
												this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
												this.BackColor = System.Drawing.SystemColors.Control;
												this.ClientSize = new System.Drawing.Size(324, 252);
												this.Controls.Add(this.menu);
												this.Controls.Add(this.p_total);
												this.Controls.Add(this.lv_pessoas);
												this.Controls.Add(this.b_verDetalhes);
												this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
												this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
												this.MainMenuStrip = this.menu;
												this.MaximizeBox = false;
												this.Name = "Main";
												this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
												this.Text = "Jamike";
												this.Load += new System.EventHandler(this.Atualizar);
												this.p_total.ResumeLayout(false);
												this.p_total.PerformLayout();
												this.menu.ResumeLayout(false);
												this.menu.PerformLayout();
												this.ResumeLayout(false);
												this.PerformLayout();

		}

		#endregion
		internal System.Windows.Forms.ListView lv_pessoas;
		internal System.Windows.Forms.ColumnHeader lv_pessoas_pessoa;
		internal System.Windows.Forms.ColumnHeader lv_pessoas_saldo;
		internal System.Windows.Forms.TextBox txt_total;
		internal System.Windows.Forms.Label l_total;
		internal System.Windows.Forms.Button b_verDetalhes;
		internal System.Windows.Forms.Panel p_total;
		internal System.Windows.Forms.ColumnHeader lv_pessoas_depositado;
		internal System.Windows.Forms.ColumnHeader lb_pessoas_debitado;
		internal System.Windows.Forms.MenuStrip menu;
		internal System.Windows.Forms.ToolStripMenuItem menu_transacoes;
		internal System.Windows.Forms.ToolStripMenuItem menu_pessoas;
		internal System.Windows.Forms.ToolStripMenuItem menu_transacoes_novaTransacao;
		internal System.Windows.Forms.ToolStripMenuItem menu_transacoes_verTransacoes;
		internal System.Windows.Forms.ToolStripMenuItem menu_pessoas_novaPessoa;
		internal System.Windows.Forms.ToolStripMenuItem menu_pessoas_verPessoas;
		internal System.Windows.Forms.ColumnHeader lv_pessoas_bug;
	}
}

