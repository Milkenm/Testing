﻿namespace ScreenShare.Share
{
	partial class Share
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			this.timer_refresh = new System.Windows.Forms.Timer(this.components);
			this.pictureBox_screen = new System.Windows.Forms.PictureBox();
			this.textBox_ip = new System.Windows.Forms.TextBox();
			this.button_share = new System.Windows.Forms.Button();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_screen)).BeginInit();
			this.SuspendLayout();
			// 
			// timer_refresh
			// 
			this.timer_refresh.Interval = 500;
			this.timer_refresh.Tick += new System.EventHandler(this.timer_refresh_Tick);
			// 
			// pictureBox_screen
			// 
			this.pictureBox_screen.Location = new System.Drawing.Point(12, 12);
			this.pictureBox_screen.Name = "pictureBox_screen";
			this.pictureBox_screen.Size = new System.Drawing.Size(720, 405);
			this.pictureBox_screen.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.pictureBox_screen.TabIndex = 0;
			this.pictureBox_screen.TabStop = false;
			// 
			// textBox_ip
			// 
			this.textBox_ip.Location = new System.Drawing.Point(12, 423);
			this.textBox_ip.Name = "textBox_ip";
			this.textBox_ip.Size = new System.Drawing.Size(571, 20);
			this.textBox_ip.TabIndex = 1;
			// 
			// button_share
			// 
			this.button_share.Location = new System.Drawing.Point(589, 422);
			this.button_share.Name = "button_share";
			this.button_share.Size = new System.Drawing.Size(143, 22);
			this.button_share.TabIndex = 2;
			this.button_share.Text = "Share";
			this.button_share.UseVisualStyleBackColor = true;
			this.button_share.Click += new System.EventHandler(this.button_share_Click);
			// 
			// Share
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(746, 449);
			this.Controls.Add(this.button_share);
			this.Controls.Add(this.textBox_ip);
			this.Controls.Add(this.pictureBox_screen);
			this.Name = "Share";
			this.Text = "Share";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox_screen)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Timer timer_refresh;
		private System.Windows.Forms.PictureBox pictureBox_screen;
		private System.Windows.Forms.TextBox textBox_ip;
		private System.Windows.Forms.Button button_share;
	}
}