﻿using System;
using System.Drawing;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScreenShare.Share
{
	public partial class Share : Form
	{
		public Share()
		{
			InitializeComponent();

			StartServer();
		}

		private void timer_refresh_Tick(object sender, EventArgs e)
		{
			Bitmap bmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
			using (Graphics g = Graphics.FromImage(bmp))
			{
				g.CopyFromScreen(0, 0, 0, 0, Screen.PrimaryScreen.Bounds.Size);
			}

			byte[] imageBytes = ObjectToByteArray(bmp);
			object imageFromBytes = ByteArrayToObject(imageBytes);
			

			

			try
			{
				SendUdpPacket("127.0.0.1", 1000, bmp);
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		void StartServer()
		{
			new Task(new Action(() =>
			{
				while (true)
				{
					object data = WaitUdpPacket(1000);
					this.Invoke(new Action(() =>
					{
						pictureBox_screen.Image = (Image)data;
					}));
				}
			})).Start();
		}

		public void SendUdpPacket(string _RemoteHost, int _RemotePort, object _Message)
		{
			try
			{
				// Create a UDP client.
				UdpClient _Client = new UdpClient(_RemoteHost, _RemotePort);

				// Convert the message...
				var _Data = ObjectToByteArray(_Message);
				// ...and then send it.
				_Client.Send(_Data, _Data.Length);

				// Close everything.
				_Client.Close();
			}
			catch (Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		public object WaitUdpPacket(int _LocalPort)
		{
			UdpClient _Client = new UdpClient(_LocalPort, AddressFamily.InterNetwork);
			IPEndPoint _EndPoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), _LocalPort);
			
			var _Received = _Client.Receive(ref _EndPoint);
			object _Message = ByteArrayToObject(_Received);

			_Client.Close();

			return _Message;
		}

		private byte[] ObjectToByteArray(object obj)
		{
			BinaryFormatter bf = new BinaryFormatter();
			using (MemoryStream ms = new MemoryStream())
			{
				bf.Serialize(ms, obj);
				return ms.ToArray();
			}
		}

		// Convert a byte array to an Object
		private object ByteArrayToObject(byte[] arrBytes)
		{
			MemoryStream memStream = new MemoryStream();
			BinaryFormatter binForm = new BinaryFormatter();
			memStream.Write(arrBytes, 0, arrBytes.Length);
			memStream.Seek(0, SeekOrigin.Begin);

			return binForm.Deserialize(memStream);
		}

		private void button_share_Click(object sender, EventArgs e)
		{
			if (button_share.Text == "Share")
			{
				button_share.Text = "Stop sharing";
				timer_refresh.Start();
			}
			else
			{
				button_share.Text = "Share";
				timer_refresh.Stop();
			}
		}
	}
}
