﻿namespace ScreenShare
{
	partial class Main
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.button_share = new System.Windows.Forms.Button();
			this.button_control = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// button_share
			// 
			this.button_share.Font = new System.Drawing.Font("Segoe UI", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button_share.Location = new System.Drawing.Point(37, 27);
			this.button_share.Name = "button_share";
			this.button_share.Size = new System.Drawing.Size(129, 41);
			this.button_share.TabIndex = 0;
			this.button_share.Text = "Share";
			this.button_share.UseVisualStyleBackColor = true;
			this.button_share.Click += new System.EventHandler(this.button_share_Click);
			// 
			// button_control
			// 
			this.button_control.Font = new System.Drawing.Font("Segoe UI", 11.25F);
			this.button_control.Location = new System.Drawing.Point(37, 84);
			this.button_control.Name = "button_control";
			this.button_control.Size = new System.Drawing.Size(129, 41);
			this.button_control.TabIndex = 1;
			this.button_control.Text = "Control";
			this.button_control.UseVisualStyleBackColor = true;
			// 
			// Main
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(202, 153);
			this.Controls.Add(this.button_control);
			this.Controls.Add(this.button_share);
			this.Name = "Main";
			this.Text = "ScreenShare";
			this.ResumeLayout(false);

		}

		#endregion

		private System.Windows.Forms.Button button_share;
		private System.Windows.Forms.Button button_control;
	}
}

