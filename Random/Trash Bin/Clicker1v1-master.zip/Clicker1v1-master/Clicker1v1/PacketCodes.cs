﻿namespace Clicker1v1
{
    internal static partial class Uni
    {
        // Users
        internal static string PCHostTag = "[HOST]";
        internal static string PCGuestTag = "[GUEST]";
        // Type
        internal static string PCAskInfo = "[AskInfo]";
        internal static string PCSendInfo = "[SendInfo]";
        // Info
        internal static string PCJoin = "[Join]";
        internal static string PCPlayerName = "[PlayerName]";
        internal static string PCScore = "[Score]";
        internal static string PCGame = "[Game]";



        // Packet Syntax:
        // [<user>]-[<type>]-[<info>]-<message>

        // Random Stuff:
        // Packet.Split('-')

        // Examples:
        // [GUEST]-[AskInfo]-[Join]-<guestnickname> -- Ask the HOST if GUEST can join.
        // [HOST]-[SendInfo]-[Join]-true -- The GUEST can join the game.
        // [GUEST]-[SendInfo]-[PlayerName]-Guest -- The GUEST sends its username to HOST.
        // [HOST]-[SendInfo]-[Game]-s -- Inform GUEST that the game has started.
        // [GUEST]-[SendInfo]-[Score]-100 -- GUEST told HOST that it had a score of 100.
    }
}