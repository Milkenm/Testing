﻿#region Usings
using System;
using System.Windows.Forms;
using static ScriptsLib.nNetwork.Packets;
using static Clicker1v1.Uni;
using System.Threading.Tasks;
#endregion Usings



namespace Clicker1v1
{
    public partial class HostGame : Form
    {
        public HostGame()
        {
            InitializeComponent();
        }


        private void button_startGame_Click(object sender, EventArgs e)
        {
            SendUdpPacket(textBox_guestIp.Text, GamePort, $"{PCHostTag}-{PCSendInfo}-{PCGame}-s");
            GuestIP = textBox_guestIp.Text;

            GameForm.Show();
            this.Hide();
        }

        private void HostGame_Load(object sender, EventArgs e)
        {
            IsHost = true;

            textBox_hostIp.Text = GetSelfIP();

            new Task(new Action(() =>
            {
                while (true)
                {
                    string[] _Packet = WaitUdpPacket(GamePort).Split('-');

                    if (_Packet[0] == PCGuestTag && _Packet[1] == PCSendInfo && _Packet[2] == PCJoin)
                    {
                        textBox_guestIp.Text = _Packet[3];
                    }
                }
            })).Start();
        }

        private void button_back_Click(object sender, EventArgs e)
        {
            MenuForm.Show();
            this.Hide();
        }
    }
}
