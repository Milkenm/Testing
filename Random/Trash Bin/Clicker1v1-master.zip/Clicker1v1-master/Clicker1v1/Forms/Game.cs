﻿#region Usings
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using static ScriptsLib.nNetwork.Packets;
using System.Threading.Tasks;
using static Clicker1v1.Uni;
using System.Windows.Forms;
#endregion Usings



namespace Clicker1v1
{
    public partial class Game : Form
    {
        static int _LocalScore = 0;
        static int _GuestScore = 0;

        public Game()
        {
            InitializeComponent();


        }

        private void pictureBox_click_Click(object sender, EventArgs e)
        {
            _LocalScore++;
            label_hostScore.Text = "Your score: " + _LocalScore;
            SendUdpPacket(GuestIP, GamePort, $"{PCHostTag}-{PCSendInfo}-{PCScore}-{_LocalScore}");
        }

        void GetGuestScore()
        {
            while (true)
            {
                string[] _Packet = WaitUdpPacket(GamePort).Split('-');

                if (_Packet[1] == PCSendInfo && _Packet[2] == PCScore)
                {
                    _GuestScore = Convert.ToInt32(_Packet[3]);
                    label_guestScore.Text = "Guest score: " + _GuestScore;
                }
            }
        }
    }
}
