﻿namespace Clicker1v1
{
    partial class HostGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(HostGame));
            this.label_hostIp = new System.Windows.Forms.Label();
            this.textBox_hostIp = new System.Windows.Forms.TextBox();
            this.label_guestIp = new System.Windows.Forms.Label();
            this.textBox_guestIp = new System.Windows.Forms.TextBox();
            this.button_startGame = new System.Windows.Forms.Button();
            this.button_back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label_hostIp
            // 
            this.label_hostIp.AutoSize = true;
            this.label_hostIp.BackColor = System.Drawing.Color.Transparent;
            this.label_hostIp.ForeColor = System.Drawing.SystemColors.Control;
            this.label_hostIp.Location = new System.Drawing.Point(147, 107);
            this.label_hostIp.Name = "label_hostIp";
            this.label_hostIp.Size = new System.Drawing.Size(49, 13);
            this.label_hostIp.TabIndex = 12;
            this.label_hostIp.Text = "Local IP:";
            // 
            // textBox_hostIp
            // 
            this.textBox_hostIp.Location = new System.Drawing.Point(202, 104);
            this.textBox_hostIp.Name = "textBox_hostIp";
            this.textBox_hostIp.ReadOnly = true;
            this.textBox_hostIp.Size = new System.Drawing.Size(185, 20);
            this.textBox_hostIp.TabIndex = 13;
            // 
            // label_guestIp
            // 
            this.label_guestIp.AutoSize = true;
            this.label_guestIp.BackColor = System.Drawing.Color.Transparent;
            this.label_guestIp.ForeColor = System.Drawing.SystemColors.Control;
            this.label_guestIp.Location = new System.Drawing.Point(145, 146);
            this.label_guestIp.Name = "label_guestIp";
            this.label_guestIp.Size = new System.Drawing.Size(51, 13);
            this.label_guestIp.TabIndex = 14;
            this.label_guestIp.Text = "Guest IP:";
            // 
            // textBox_guestIp
            // 
            this.textBox_guestIp.Location = new System.Drawing.Point(202, 143);
            this.textBox_guestIp.Name = "textBox_guestIp";
            this.textBox_guestIp.ReadOnly = true;
            this.textBox_guestIp.Size = new System.Drawing.Size(185, 20);
            this.textBox_guestIp.TabIndex = 15;
            // 
            // button_startGame
            // 
            this.button_startGame.Location = new System.Drawing.Point(312, 169);
            this.button_startGame.Name = "button_startGame";
            this.button_startGame.Size = new System.Drawing.Size(75, 23);
            this.button_startGame.TabIndex = 16;
            this.button_startGame.Text = "Start Game";
            this.button_startGame.UseVisualStyleBackColor = true;
            this.button_startGame.Click += new System.EventHandler(this.button_startGame_Click);
            // 
            // button_back
            // 
            this.button_back.Location = new System.Drawing.Point(0, 274);
            this.button_back.Name = "button_back";
            this.button_back.Size = new System.Drawing.Size(75, 23);
            this.button_back.TabIndex = 17;
            this.button_back.Text = "<- Back";
            this.button_back.UseVisualStyleBackColor = true;
            this.button_back.Click += new System.EventHandler(this.button_back_Click);
            // 
            // HostGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Clicker1v1.Properties.Resources.BackgroundGradient;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(532, 297);
            this.Controls.Add(this.button_back);
            this.Controls.Add(this.button_startGame);
            this.Controls.Add(this.textBox_guestIp);
            this.Controls.Add(this.label_guestIp);
            this.Controls.Add(this.textBox_hostIp);
            this.Controls.Add(this.label_hostIp);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "HostGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HostGame";
            this.Load += new System.EventHandler(this.HostGame_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label_hostIp;
        private System.Windows.Forms.TextBox textBox_hostIp;
        private System.Windows.Forms.Label label_guestIp;
        private System.Windows.Forms.TextBox textBox_guestIp;
        private System.Windows.Forms.Button button_startGame;
        private System.Windows.Forms.Button button_back;
    }
}