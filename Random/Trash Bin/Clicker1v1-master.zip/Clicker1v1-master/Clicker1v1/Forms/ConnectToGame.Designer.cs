﻿namespace Clicker1v1
{
    partial class ConnectToGame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ConnectToGame));
            this.button_connect = new System.Windows.Forms.Button();
            this.textBox_hostIp = new System.Windows.Forms.TextBox();
            this.label_hostIp = new System.Windows.Forms.Label();
            this.button_back = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button_connect
            // 
            this.button_connect.Location = new System.Drawing.Point(309, 150);
            this.button_connect.Name = "button_connect";
            this.button_connect.Size = new System.Drawing.Size(75, 23);
            this.button_connect.TabIndex = 11;
            this.button_connect.Text = "Connect";
            this.button_connect.UseVisualStyleBackColor = true;
            this.button_connect.Click += new System.EventHandler(this.button_connect_Click);
            // 
            // textBox_hostIp
            // 
            this.textBox_hostIp.Location = new System.Drawing.Point(199, 124);
            this.textBox_hostIp.Name = "textBox_hostIp";
            this.textBox_hostIp.Size = new System.Drawing.Size(185, 20);
            this.textBox_hostIp.TabIndex = 15;
            // 
            // label_hostIp
            // 
            this.label_hostIp.AutoSize = true;
            this.label_hostIp.BackColor = System.Drawing.Color.Transparent;
            this.label_hostIp.ForeColor = System.Drawing.SystemColors.Control;
            this.label_hostIp.Location = new System.Drawing.Point(148, 127);
            this.label_hostIp.Name = "label_hostIp";
            this.label_hostIp.Size = new System.Drawing.Size(45, 13);
            this.label_hostIp.TabIndex = 14;
            this.label_hostIp.Text = "Host IP:";
            // 
            // button_back
            // 
            this.button_back.Location = new System.Drawing.Point(0, 274);
            this.button_back.Name = "button_back";
            this.button_back.Size = new System.Drawing.Size(75, 23);
            this.button_back.TabIndex = 16;
            this.button_back.Text = "<- Back";
            this.button_back.UseVisualStyleBackColor = true;
            this.button_back.Click += new System.EventHandler(this.button_back_Click);
            // 
            // ConnectToGame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Clicker1v1.Properties.Resources.BackgroundGradient;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(532, 297);
            this.Controls.Add(this.button_back);
            this.Controls.Add(this.textBox_hostIp);
            this.Controls.Add(this.label_hostIp);
            this.Controls.Add(this.button_connect);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "ConnectToGame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ConnectToGame";
            this.Load += new System.EventHandler(this.ConnectToGame_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Button button_connect;
        private System.Windows.Forms.TextBox textBox_hostIp;
        private System.Windows.Forms.Label label_hostIp;
        private System.Windows.Forms.Button button_back;
    }
}