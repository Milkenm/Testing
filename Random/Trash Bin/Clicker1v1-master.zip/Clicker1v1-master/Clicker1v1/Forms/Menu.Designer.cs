﻿namespace Clicker1v1
{
    partial class Menu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Menu));
            this.button_connectToGame = new System.Windows.Forms.Button();
            this.button_hostGame = new System.Windows.Forms.Button();
            this.pictureBox_icon = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_icon)).BeginInit();
            this.SuspendLayout();
            // 
            // button_connectToGame
            // 
            this.button_connectToGame.Location = new System.Drawing.Point(269, 196);
            this.button_connectToGame.Name = "button_connectToGame";
            this.button_connectToGame.Size = new System.Drawing.Size(152, 64);
            this.button_connectToGame.TabIndex = 1;
            this.button_connectToGame.Text = "Connect to Game";
            this.button_connectToGame.UseVisualStyleBackColor = true;
            this.button_connectToGame.Click += new System.EventHandler(this.button_findGame_Click);
            // 
            // button_hostGame
            // 
            this.button_hostGame.Cursor = System.Windows.Forms.Cursors.Default;
            this.button_hostGame.Location = new System.Drawing.Point(111, 196);
            this.button_hostGame.Name = "button_hostGame";
            this.button_hostGame.Size = new System.Drawing.Size(152, 64);
            this.button_hostGame.TabIndex = 0;
            this.button_hostGame.Text = "Host Game";
            this.button_hostGame.UseVisualStyleBackColor = true;
            this.button_hostGame.Click += new System.EventHandler(this.button_hostGame_Click);
            // 
            // pictureBox_icon
            // 
            this.pictureBox_icon.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox_icon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.pictureBox_icon.Image = global::Clicker1v1.Properties.Resources.Clicker1v1IconPng;
            this.pictureBox_icon.Location = new System.Drawing.Point(202, 37);
            this.pictureBox_icon.Name = "pictureBox_icon";
            this.pictureBox_icon.Size = new System.Drawing.Size(128, 128);
            this.pictureBox_icon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_icon.TabIndex = 2;
            this.pictureBox_icon.TabStop = false;
            // 
            // Menu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Clicker1v1.Properties.Resources.BackgroundGradient;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(532, 297);
            this.Controls.Add(this.pictureBox_icon);
            this.Controls.Add(this.button_hostGame);
            this.Controls.Add(this.button_connectToGame);
            this.DoubleBuffered = true;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Menu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Clicker1v1";
            this.Load += new System.EventHandler(this.Menu_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_icon)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button_connectToGame;
        private System.Windows.Forms.Button button_hostGame;
        private System.Windows.Forms.PictureBox pictureBox_icon;
    }
}

