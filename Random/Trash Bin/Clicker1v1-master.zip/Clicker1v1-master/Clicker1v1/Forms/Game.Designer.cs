﻿namespace Clicker1v1
{
    partial class Game
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Game));
            this.pictureBox_click = new System.Windows.Forms.PictureBox();
            this.label_hostScore = new System.Windows.Forms.Label();
            this.label_guestScore = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_click)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox_click
            // 
            this.pictureBox_click.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox_click.Image = global::Clicker1v1.Properties.Resources.ClickHere;
            this.pictureBox_click.Location = new System.Drawing.Point(166, 48);
            this.pictureBox_click.Name = "pictureBox_click";
            this.pictureBox_click.Size = new System.Drawing.Size(200, 200);
            this.pictureBox_click.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox_click.TabIndex = 0;
            this.pictureBox_click.TabStop = false;
            this.pictureBox_click.Click += new System.EventHandler(this.pictureBox_click_Click);
            // 
            // label_hostScore
            // 
            this.label_hostScore.AutoSize = true;
            this.label_hostScore.BackColor = System.Drawing.Color.Transparent;
            this.label_hostScore.ForeColor = System.Drawing.SystemColors.Control;
            this.label_hostScore.Location = new System.Drawing.Point(12, 9);
            this.label_hostScore.Name = "label_hostScore";
            this.label_hostScore.Size = new System.Drawing.Size(72, 13);
            this.label_hostScore.TabIndex = 1;
            this.label_hostScore.Text = "Your Score: 0";
            // 
            // label_guestScore
            // 
            this.label_guestScore.AutoSize = true;
            this.label_guestScore.BackColor = System.Drawing.Color.Transparent;
            this.label_guestScore.ForeColor = System.Drawing.SystemColors.Control;
            this.label_guestScore.Location = new System.Drawing.Point(12, 31);
            this.label_guestScore.Name = "label_guestScore";
            this.label_guestScore.Size = new System.Drawing.Size(78, 13);
            this.label_guestScore.TabIndex = 2;
            this.label_guestScore.Text = "Guest Score: 0";
            // 
            // Game
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Clicker1v1.Properties.Resources.BackgroundGradient;
            this.ClientSize = new System.Drawing.Size(532, 297);
            this.Controls.Add(this.label_guestScore);
            this.Controls.Add(this.label_hostScore);
            this.Controls.Add(this.pictureBox_click);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Game";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_click)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox_click;
        private System.Windows.Forms.Label label_hostScore;
        private System.Windows.Forms.Label label_guestScore;
    }
}