﻿#region Usings
using System;
using System.Windows.Forms;
using static ScriptsLib.nNetwork.Packets;
using static Clicker1v1.Uni;
using System.Threading.Tasks;
using System.Threading;
using System.Reactive.Concurrency;
using System.Reactive.Threading.Tasks;
using System.Reactive.Linq;
#endregion Usings

// # = #
// https://stackoverflow.com/questions/4238345/asynchronously-wait-for-taskt-to-complete-with-timeout
// # = #

namespace Clicker1v1
{
    public partial class ConnectToGame : Form
    {
        public ConnectToGame()
        {
            InitializeComponent();
        }

        private void button_connect_Click(object sender, EventArgs e)
        {
            try
            {
                Connect();
            }
            catch (Exception _Exception) { MessageBox.Show(_Exception.Message); }
        }

        private void button_back_Click(object sender, EventArgs e)
        {
            MenuForm.Show();
            this.Hide();
        }

        private void ConnectToGame_Load(object sender, EventArgs e)
        {
            IsHost = false;
        }

        async void Connect()
        {
            SendUdpPacket(textBox_hostIp.Text, GamePort, $"{PCGuestTag}-{PCAskInfo}-{PCJoin}-{LocalIP}");



            new Task(new Action(() =>
            {
                Task t = Task.Run(() =>
                {
                    int a = 0;

                    while (true)
                    {
                        a++;


                        Console.WriteLine(a);
                    }
                });
                TimeSpan ts = TimeSpan.FromMilliseconds(2000);

                if (!t.Wait(ts))
                {
                    t.Dispose();
                    Console.WriteLine("The timeout interval elapsed.");
                }
            })).Start();



        }
    }
}
