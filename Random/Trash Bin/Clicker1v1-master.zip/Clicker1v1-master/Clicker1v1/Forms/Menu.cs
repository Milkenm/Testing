﻿#region Usings
using System;
using System.Net.NetworkInformation;
using System.Windows.Forms;
using static Clicker1v1.Uni;
#endregion Usings



namespace Clicker1v1
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();

            MenuForm = this;
            ConnectToGameForm = new ConnectToGame();
            HostGameForm = new HostGame();
            GameForm = new Game();
        }


        private void button_findGame_Click(object sender, EventArgs e)
        {
            ConnectToGameForm.Show();
            this.Hide();
        }

        
        private void Menu_Load(object sender, EventArgs e)
        {
            LocalIP = GetSelfIP();
        }

        private void button_hostGame_Click(object sender, EventArgs e)
        {
            HostGameForm.Show();
            this.Hide();
        }
    }
}