﻿#region Usings
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
#endregion Usings



namespace Clicker1v1
{
    internal static partial class Uni
    {
        // Forms
        internal static Menu MenuForm;
        internal static ConnectToGame ConnectToGameForm;
        internal static HostGame HostGameForm;
        internal static Game GameForm;

        // Random Values
        internal static int GamePort = 2019;

        // Random Vars
        internal static string LocalIP;
        internal static string GuestIP;
        internal static bool IsHost;
    }
}
