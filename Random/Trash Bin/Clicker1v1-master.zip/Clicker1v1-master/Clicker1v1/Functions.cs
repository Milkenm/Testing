﻿#region Usings
using System.Net.NetworkInformation;
#endregion Usings



namespace Clicker1v1
{
    internal static partial class Uni
    {
        internal static string GetSelfIP()
        {
            string _SelfIP = null;

            foreach (NetworkInterface _Network in NetworkInterface.GetAllNetworkInterfaces())
            {
                if (_Network.OperationalStatus == OperationalStatus.Up)
                {
                    foreach (GatewayIPAddressInformation _IPInfo in _Network.GetIPProperties().GatewayAddresses)
                    {
                        _SelfIP = _IPInfo.Address.ToString();
                    }
                }
            }

            return _SelfIP;
        }
    }
}
